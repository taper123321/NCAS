// Solar v.1.01 NW 23/10/2020 pour Graph 90 d'apres https://nsi.xyz/solar, Jil Saint-Martin et Emmy Vadon

sw:=384;sh:=216;font_h:=10;
systeme := [["Soleil","centre du syteme solaire",0,1.989e30,696340, 0],
    ["Mercure",88,57,3.285e23,2439.7, 0],
    ["Venus",225,104,4.867e24,6051.8, 0],
    ["Terre",365,150,5.972e24,6371, "Lune"],
    ["Mars",687,220 ,6.39e23 ,3389,5,2],
    ["Jupiter",12,780 ,1.898e27,69911,3],
    ["Saturne",29.1,493,5.683e26,58232,"~ 200"],
    ["Uranus",84.2,9592,8.681e25,25362,27],
    ["Neptune",165.4,4762,1.024e26,24622,14]]:;
rayons:=[22,32,42,52,62,76,92,109];
coord := [[160,116,16], [180,115,6], [185,100,8], [120,105,9], [160,165,9],
    [115,155,15], [200,55,12], [170,25,9], [55,85,8]]:;
couleur1 := [[255,255,0], [251,136,7], [190,183,150], 
    [30,160,173], [245,0,0], [162,125,105], [200,169,133],
    [191,209,232], [0,33,240]]:;
couleur2 := [[235,128,0], [106,73,32], [121,104,83],
    [6,67,29], [101,12,12], [134,56,32], [189,138,80],
    [117,163,224], [5,15,81]]:;
c_blanc:=65535:;

anneau(x0,y0,r,c,E):={
  local j,rt;
  for j in range(2*E) do
    rt := max(0,r-j*0.5);
    draw_circle(x0,y0,floor(rt),c);
  od;
}:;

// degrade(c1,c2,k):=rgb(c1[0]+floor(k*c2[0]),c1[1]+floor(k*c2[1]),c1[2]+floor(k*c2[2])):;
degrade(c1,c2,k):=rgb(c1+floor(k*c2));

cercled(x0,y0,R,c1,c2):={
  local j;
  for j in range(R) do anneau(x0,y0,j,degrade(c1,c2-c1,j/R),1); od;
  set_pixel();
}:;

tirage(n):={
  local j,c,x,y,d,di,Coeff;
  c:=[rgb(235,128,0),rgb(13,89,175),rgb(13,89,175),
      rgb(44,122,211),rgb(207,230,230),rgb(207,230,230)];
  c.append(c[0]);
  Coeff:=1.0/(sw/10.0+.5);
  for j in range(n) do
    x:=randint(0,sw);
    y:=randint(0,sh);
    d:=sqrt((x-sw/2.0)**2+(y-sh/2.0)**2)*Coeff;
    di:=floor(d);
    fill_rect(x,y,2,2,c[di]+floor((d-di)*(c[di+1]-c[di])));
  od;
}:;

solar_systeme_dessine(n, Degrade=1):={
  local cn:=coord[n];
  if Degrade then
    cercled(cn[0], cn[1], cn[2], couleur1[n], couleur2[n]);
  else
    draw_circle(cn[0], cn[1], cn[2], rempli+c_blanc);
  fi;
}:;
 
solar_systeme_texte(n=42, t=0):={ 
  local s;
  fill_rect(0,sh-font_h,sw,font_h+1,c_blanc);
  if n == 42 then
    return draw_string("nsi.xyz/solar par Emmy & Jil ",2,sh-font_h);
  fi;
  s := systeme[n,t];
  if t==1 and n then
    s := "periode de revo: " + s + ((n <=4)?" jours":" ans");
  elif t==2 then
    s := "dis soleil: " + s + " milli" + ((n <= 5 )?"on":"ard") + "s km";
  elif t==3 then
    s := "masse: " + s + " kg";
  elif t==4 then
    s := "rayon: " + str(s) + " km";
  elif t==5 then
    s := "satellites connus: " + str(s);
  fi;
  draw_string(s,2,sh-font_h);
}:;
 
navigation():={
  local Position,avant,texte,key;
  Position := 0;
  texte := 0  ;
  key := 0;
  while key != 5 do
    key := get_key(); 
    if key>=0 and key<=3 then
      if key==0 or key==3 then
        avant := Position;
        Position := min(max(Position+2*(key==3)-1, 0), 8);
        if avant != Position then solar_systeme_dessine(avant); fi;
        solar_systeme_dessine(Position, 0);
      elif key==1 or key==2 then  
        texte := max(min(texte + 2*(key==2) - 1, 5), 0);
      fi;
      solar_systeme_texte(Position,texte);
    fi;
  od;
}:;
      
main():={
  local j,k,ck,c0,c1;
  fill_rect(0,0,sw,sh,0);
  c0:=coord[0,0]; c1:=coord[0,1];
  cercled(c0,c1,197,[0,35,143],[0,0,0])
  cercled(c0,c1,40,couleur2[0],[0,35,143])
  cercled(c0,c1,coord[0,2],couleur1[0],couleur2[0]);
  tirage(250);
  for j in rayons do
    anneau(c0,c1,j,rgb([119,135,135]),1);
  od;
  solar_systeme_texte();
  solar_systeme_dessine(0,0);
  solar_systeme_dessine(0);
  for k in range(1,9) do
    ck:=coord[k];
    cercled(ck[0],ck[1],ck[2],couleur1[k],couleur2[k]);
  od;
  navigation();
}:;

main():;
