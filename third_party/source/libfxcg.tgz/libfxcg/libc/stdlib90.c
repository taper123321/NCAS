//#include <fxcg/heap.h>
#include <ctype.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifndef GINT_MALLOC
const static size_t stackptr=0x18000,stack_mask=0x1ffff;
#endif

// External linkage
int errno;
volatile char ctrl_c,interrupted;

//#define ALLOCSMALL

/* also define GINT_MALLOC in Makefile, does not work with OFF/ON */
/* #define GINT_MALLOC  */
#ifdef GINT_MALLOC
#include <gint/kmalloc.h>
#else
#ifdef ALLOCSMALL
#undef ALLOCSMALL
#endif
#endif

static inline size_t allocround(size_t size){
  return (size < 8) ? 8 : ((size + 3) & ~3);
}

static inline size_t allocmin(size_t a,size_t b){
  return a<b?a:b;
}

#ifdef ALLOCSMALL // does not work...

typedef struct  {
  int i1,i2;
} two_int; // 8

typedef struct  {
  int i1,i2,i3,i4;
} four_int ; // 16

typedef struct  {
  int i1,i2,i3,i4,i5,i6;
} six_int; // 24
  
typedef struct  {
  int i1,i2,i3,i4,i5,i6,i7,i8;
} eight_int; // 32
  
// ALLOCA  constants must be multiples of 2*32
#define ALLOC8 32*32
#define ALLOC16 32*32
#define ALLOC24 24*32 

static unsigned int freeslot8[ALLOC8/32]={
  0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff,
  0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff,
  0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff,
  0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff,
  0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff,
  0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff,
  0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff,
  0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff,
};
static unsigned int freeslot16[ALLOC16/32]={
  0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff,
  0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff,
  0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff,
  0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff,
  0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff,
  0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff,
  0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff,
  0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff,
};
static unsigned int freeslot24[ALLOC24/32]={
  0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff,
  0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff,
  0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff,
  0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff,
  0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff,
  0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff,
};
static two_int slottab8[ALLOC8];
static four_int slottab16[ALLOC16];
static six_int slottab24[ALLOC24];
  
unsigned freeslotpos(unsigned n){
  unsigned r=1;
  if ( (n<<16)==0 ){ 
    r+= 16;
    n>>=16;
  }
  if ( (n<<24)==0 ) {
    r+= 8; 
    n>>=8;
  }
  if ( (n<<28)==0 ) {
    r+= 4;
    n>>=4;
  }
  if ( (n<<30)==0 ) {
    r+= 2;
    n>>=2;
  }
  r -= n&1;
  return r;
}
  
void * slotalloc(size_t size){
  int i,pos;
  if (size<=8){ 
    for (i=0;i<ALLOC8/32;){
      if (!(freeslot8[i] || freeslot8[i+1])){
	i+=2;
	continue;
      }
      if (freeslot8[i]){
	pos=freeslotpos(freeslot8[i]);
	freeslot8[i] &= ~(1<<pos);
	return (void *) (slottab8+i*32+pos);
      }
      i++;
      pos=freeslotpos(freeslot8[i]);
      freeslot8[i] &= ~(1<<pos);
      return (void *) (slottab8+i*32+pos);
    }
    return kmalloc(size,NULL);
  }
  if (size<=16){ 
    for (i=0;i<ALLOC16/32;){
      if (!(freeslot16[i] || freeslot16[i+1])){
	i+=2;
	continue;
      }
      if (freeslot16[i]){
	pos=freeslotpos(freeslot16[i]);
	freeslot16[i] &= ~(1<<pos);
	return (void *) (slottab16+i*32+pos);
      }
      ++i;
      pos=freeslotpos(freeslot16[i]);
      freeslot16[i] &= ~(1<<pos);
      return (void *) (slottab16+i*32+pos);
    }
    return kmalloc(size,NULL);
  }
  if (size<=24){ 
    for (i=0;i<ALLOC24/32;){
      if (!(freeslot24[i] || freeslot24[i+1])){
	i+=2;
	continue;
      }
      if (freeslot24[i]){
	pos=freeslotpos(freeslot24[i]);
	freeslot24[i] &= ~(1<<pos);
	return (void *) (slottab24+i*32+pos);
      }
      i++;
      pos=freeslotpos(freeslot24[i]);
      freeslot24[i] &= ~(1<<pos);
      return (void *) (slottab24+i*32+pos);
    }
    return kmalloc(size,NULL);
  }
  void * p =  kmalloc(size,NULL);  
  return p;
}  
  
void slotfree(void* obj){
  if ( ((size_t)obj >= (size_t) &slottab8[0]) &&
       ((size_t)obj < (size_t) &slottab8[ALLOC8]) ){
    int pos= ((size_t)obj -((size_t) &slottab8[0]))/sizeof(two_int);
    freeslot8[pos/32] |= (1 << (pos%32)); 
    return;
  }
  if ( ((size_t)obj>=(size_t) &slottab16[0] ) &&
       ((size_t)obj<(size_t) &slottab16[ALLOC16] ) ){
    int pos= ((size_t)obj -((size_t) &slottab16[0]))/sizeof(four_int);
    freeslot16[pos/32] |= (1 << (pos%32)); 
    return;
  }
  if ( ((size_t)obj >= (size_t) &slottab24[0]) &&
       ((size_t)obj < (size_t) &slottab24[ALLOC24]) ){
    int pos= ((size_t)obj -((size_t) &slottab24[0]))/sizeof(six_int);
    freeslot24[pos/32] |= (1 << (pos%32)); 
    return;
  }
  kfree(obj);
}
unsigned hamdist(unsigned val){
  size_t res=0;
  if (!val) return res;
  for (int i=0;i<32;++i){
    res += ((val >>i) & 1); 
  }
  return res;
}

size_t slotfreemem(){
  size_t res=0;
  for (int i=0;i<ALLOC8/32;++i){
    res += 8*hamdist(freeslot8[i]);
  }
  for (int i=0;i<ALLOC16/32;++i){
    res += 16*hamdist(freeslot16[i]);
  }
  for (int i=0;i<ALLOC24/32;++i){
    res += 24*hamdist(freeslot24[i]);
  }
  return res;
}
#else // ALLOCSMALL
size_t slotfreemem(){
  return 0;
}
#endif // ALLOCSMALL

#include <fxcg_syscalls.h>
#include <fxcg/display.h>
#include <fxcg/system.h>
static void drawRectangle(int x,int y,int width,int height,int color){
  unsigned short*VRAM = (unsigned short *) GetVRAMAddress();
  VRAM+=(y*384)+x;
  while(height--){
    int i=width;
    while(i--){
      *VRAM++ = color;
    }
    VRAM+=384-width;
  }
}

static void memerr_exit(){
  int textY=24;
  drawRectangle(0, textY+10, LCD_WIDTH_PX, 60, COLOR_WHITE);
  drawRectangle(3,textY+10,380,3, COLOR_BLACK);
  drawRectangle(3,textY+10,3,60, COLOR_BLACK);
  drawRectangle(380,textY+10,3,60, COLOR_BLACK);
  drawRectangle(3,textY+70,380,3, COLOR_BLACK);
  int textX=30;
  PrintMini(&textX,&textY,(unsigned char*)"Memory full",0x02, 0xFFFFFFFF, 0, 0, COLOR_BLACK, COLOR_WHITE, 1, 0); 
  textX=10;
  textY+=25;
  PrintMini(&textX,&textY,(unsigned char*)"Press MENU key",0x02, 0xFFFFFFFF, 0, 0, COLOR_BLACK, COLOR_WHITE, 1, 0); 
  Bdisp_PutDisp_DD();
  SetQuitHandler(0); // no memory, can't save session
  int key;
  for(;;)
    GetKey(&key);
}

void *malloc(size_t sz) {
#ifdef GINT_MALLOC
#ifdef ALLOCSMALL
  return slotalloc(sz);
#else
  void * p=kmalloc(sz, NULL);
  if (sz && !p)
    memerr_exit();
  return p;
#endif
#else
  void * ptr= sys_malloc(sz); // __malloc(size);
  if ( ((size_t) ptr&stack_mask) > stackptr)
    interrupted=ctrl_c=1;
  return ptr;
#endif
}

void *realloc(void *ptr, size_t sz) {
#ifdef GINT_MALLOC
#ifdef ALLOCSMALL
  if (sz==0){
    free(ptr);
    return;
  }
    if ( ((size_t)ptr >= (size_t) &slottab8[0]) &&
	 ((size_t)ptr < (size_t) &slottab8[ALLOC8]) ){
      if (sz<=8) return ptr;
      void * newptr=slotalloc(sz);
      slotfree(ptr);
      if (!newptr) return 0;
      memcpy(newptr, ptr, allocmin(8,sz));
      return newptr;
    }
    if ( ((size_t)ptr >= (size_t) &slottab16[0]) &&
	 ((size_t)ptr < (size_t) &slottab16[ALLOC16]) ){
      if (sz<=16) return ptr;
      void * newptr=slotalloc(sz);
      slotfree(ptr);
      if (!newptr) return 0;
      memcpy(newptr, ptr, allocmin(16,sz));
      return newptr;
    }
    if ( ((size_t)ptr >= (size_t) &slottab24[0]) &&
	 ((size_t)ptr < (size_t) &slottab24[ALLOC24]) ){
      if (sz<=24) return ptr;
      void * newptr=slotalloc(sz);
      slotfree(ptr);
      if (!newptr) return 0;
      memcpy(newptr, ptr, allocmin(24,sz));
      return newptr;
    }
#endif
    void * p=krealloc(ptr, sz);
    if (sz && !p)
      memerr_exit();
    return p;
#else
  ptr=sys_realloc(ptr, sz);	// return __realloc(ptr, newsize);
  if ( ((size_t) ptr&stack_mask) > stackptr)
    interrupted=ctrl_c=1;
  return ptr;
#endif
}

void free(void *ptr) {
#ifdef GINT_MALLOC
#ifdef ALLOCSMALL
  slotfree(ptr);
#else
  kfree(ptr);
#endif
#else
  sys_free(ptr);
#endif
}

struct div_t div(int a,int b){
  struct div_t qr;
  qr.quot=a/b;
  qr.rem=a-qr.quot*b;
  return qr;
}

// TODO annotate this noreturn
void exit(int status) {
    fprintf(stderr, "TERMINATED (%i)", status);
    // We don't have a clean way to exit (right now), so just crash it.
    ((void (*)())1)(); // Unaligned instruction
}

int atexit (void (*__func) (void))  {
  return 0;
}

void abort() {
    fprintf(stderr, "ABORTED");
    // We don't have a clean way to exit (right now), so just crash it.
    ((void (*)())1)(); // Unaligned instruction
}

static char strtol_consume(unsigned char c, int base) {
    c = toupper(c);
    if (!isalnum(c))
        return -1;

    if ((c - '0') < 10)
        c = c - '0';
    else
        c = (c - 'A') + 10;

    if (c >= base)
        return -1;
    else
        return c;
}

long strtol(const char *str, char **str_end, int base) {
  if (!base) base=10;
  long v = 0;
  short v_in;
  // TODO handle {+,-} sign indicators, octal (0), hex (0[Xx]) prefixes
  while (isspace(*str))
    str++;
  int sign=0;
  if (*str=='+')
    ++str;
  if (*str=='-'){
    sign=1;
    ++str;
  }
  while (*str != 0 && (v_in = strtol_consume(*str++, base)) >= 0) {
    long long vc = ((long long)v * base) + v_in;
    if (vc > LONG_MAX || vc<-LONG_MAX){  // Handle overflow
      errno=1;//ERANGE;
      if (str_end){
	while (*str)
	  ++str;
	*str_end=(char *)str;
      }
      return vc>LONG_MAX?LONG_MAX:-LONG_MAX;
    }
    v = (v * base) + v_in;
  }
  if (str_end != NULL)
    *str_end = *str?(char *)str-1:(char *)str;
  return sign?-v:v;
}

double strtod(const char *s, char **str_end) {
    // TODO handle exponential format, hex format, inf, nan
    double r = 0.0;
    int negative = 0;
    if (!isdigit(*s) && *s != '-' && *s != '+' && *s != '.') {
        if (str_end != NULL)
            *str_end = (char *)s;
        return 0;
    }

    switch (*s)
    {
        case '-':
            negative = 1;
            // Deliberate fallthrough
        case '+':
            s++;
            break;
    }

    while (isdigit(*s))
    {
        r *= 10.0;
        r += *s++ - '0';
    }
    if (*s == '.')
    {
        double f = 10.0;
        s++;
        while (isdigit(*s))
        {
            r += (*s - '0')/f;
            f *= 10.0;
            s++;
        }
    }
    if (*s=='e' || *s=='E'){
      ++s;
      int expneg=0;
      if (*s=='-'){
	expneg=1;
	++s;
      }
      int expo=0;
      while (isdigit(*s)){
	expo=10*expo+(*s-'0');
	s++;
      }
      double tmp=1;
      for (int i=0;i<expo;++i){
	tmp*=10.0;
      }
      if (expneg) r=r/tmp; else r=r*tmp;
    }
    if (str_end != NULL)
        *str_end = (char *)s;

    // Portable? Nope. Fast? Yup.
    union {
        double r;
        unsigned long long l;
    } raw;
    raw.r = r;
    raw.l |= (unsigned long long)negative << 63;
    return raw.r;
}

// http://svn.savannah.nongnu.org/viewvc/*checkout*/avr-libc/trunk/avr-libc/libc/stdlib/qsort.c?revision=1944
/*-
 * Copyright (c) 1992, 1993
 *	The Regents of the University of California.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the University nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */
#include <stdlib.h>

typedef int cmp_t(const void *, const void *);
static char *med3(char *, char *, char *, cmp_t *);
static void swapfunc(char *, char *, int);

#define min(a, b)	((a) < (b) ? (a) : (b))

/*
 * Qsort routine from Bentley & McIlroy's "Engineering a Sort Function".
 */
#define swapcode(TYPE, parmi, parmj, n) { 		\
	int i = (n) / sizeof (TYPE); 			\
	register TYPE *pi = (TYPE *) (parmi); 		\
	register TYPE *pj = (TYPE *) (parmj); 		\
	do { 						\
		register TYPE	t = *pi;		\
		*pi++ = *pj;				\
		*pj++ = t;				\
        } while (--i > 0);				\
}

static void
swapfunc(char *a, char *b, int n)
{
	swapcode(char, a, b, n)
}

#define swap(a, b) swapfunc(a, b, es)

#define vecswap(a, b, n) 	if ((n) > 0) swapfunc(a, b, n)

static char *
med3(char *a, char *b, char *c, cmp_t *cmp)
{
	return cmp(a, b) < 0 ?
	       (cmp(b, c) < 0 ? b : (cmp(a, c) < 0 ? c : a ))
              :(cmp(b, c) > 0 ? b : (cmp(a, c) < 0 ? a : c ));
}

void
qsort(void *a, size_t n, size_t es, cmp_t *cmp)
{
	char *pa, *pb, *pc, *pd, *pl, *pm, *pn;
	int d, r, swap_cnt;

loop:
	swap_cnt = 0;
	if (n < 7) {
		for (pm = (char *)a + es; pm < (char *)a + n * es; pm += es)
			for (pl = pm; pl > (char *)a && cmp(pl - es, pl) > 0;
			     pl -= es)
				swap(pl, pl - es);
		return;
	}
	pm = (char *)a + (n / 2) * es;
	if (n > 7) {
		pl = a;
		pn = (char *)a + (n - 1) * es;
		if (n > 40) {
			d = (n / 8) * es;
			pl = med3(pl, pl + d, pl + 2 * d, cmp);
			pm = med3(pm - d, pm, pm + d, cmp);
			pn = med3(pn - 2 * d, pn - d, pn, cmp);
		}
		pm = med3(pl, pm, pn, cmp);
	}
	swap(a, pm);
	pa = pb = (char *)a + es;

	pc = pd = (char *)a + (n - 1) * es;
	for (;;) {
		while (pb <= pc && (r = cmp(pb, a)) <= 0) {
			if (r == 0) {
				swap_cnt = 1;
				swap(pa, pb);
				pa += es;
			}
			pb += es;
		}
		while (pb <= pc && (r = cmp(pc, a)) >= 0) {
			if (r == 0) {
				swap_cnt = 1;
				swap(pc, pd);
				pd -= es;
			}
			pc -= es;
		}
		if (pb > pc)
			break;
		swap(pb, pc);
		swap_cnt = 1;
		pb += es;
		pc -= es;
	}
	if (swap_cnt == 0) {  /* Switch to insertion sort */
		for (pm = (char *)a + es; pm < (char *)a + n * es; pm += es)
			for (pl = pm; pl > (char *)a && cmp(pl - es, pl) > 0;
			     pl -= es)
				swap(pl, pl - es);
		return;
	}

	pn = (char *)a + n * es;
	r = min(pa - (char *)a, pb - pa);
	vecswap(a, pb - r, r);
	r = min(pd - pc, pn - pd - es);
	vecswap(pb, pn - r, r);
	if ((r = pb - pa) > es)
		qsort(a, r / es, es, cmp);
	if ((r = pd - pc) > es) {
		/* Iterate rather than recurse to save stack space */
		a = pn - r;
		n = r / es;
		goto loop;
	}
/*		qsort(pn - r, r / es, es, cmp);*/
}

int abs(int n){
  if (n<0) return -n;
  return n;
}

int rand(){
  static unsigned r=0;
  r = (unsigned) ((1664525*(unsigned long long)(r)+1013904223)%((unsigned)(1)<<31));
  return r;
}

