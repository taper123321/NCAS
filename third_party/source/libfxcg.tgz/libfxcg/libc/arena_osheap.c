//---
// gint:kmalloc:arena_osheap - An arena that uses the OS heap as input
//---

#include <gint/kmalloc.h>
#include <gint/defs/attributes.h>

/* Syscalls relating to the OS heap */
extern void *sys_malloc(size_t size);
extern void *sys_realloc(void *ptr, size_t newsize);
extern void sys_free(void *ptr);
extern volatile char ctrl_c,interrupted; // stdlib.c/.h

const static size_t stackptr=0x18000,stack_mask=0x1ffff;

static void *osheap_malloc(size_t size, GUNUSED void *data)
{
  void * ptr= sys_malloc(size); // __malloc(size);
  if ( ((size_t) ptr&stack_mask) > stackptr)
    interrupted=ctrl_c=true;
  return ptr;
}

static void *osheap_realloc(void *ptr, size_t newsize, GUNUSED void *data)
{
  ptr=sys_realloc(ptr, newsize);	// return __realloc(ptr, newsize);
  if ( ((size_t) ptr&stack_mask) > stackptr)
    interrupted=ctrl_c=true;
  return ptr;
}

static void osheap_free(void *ptr, GUNUSED void *data)
{
  sys_free(ptr); // return __free(ptr);
}

/* This is a global variable, it's pulled by kmalloc.c. This arena is the only
   one allowed to not specify start/end as the values are hard to determine. */
kmalloc_arena_t kmalloc_arena_osheap = {
	.malloc      = osheap_malloc,
	.realloc     = osheap_realloc,
	.free        = osheap_free,
	.name        = "_os",
	.start       = NULL,
	.end         = NULL,
	.data        = NULL,
	.is_default  = 1,
	.stats       = { 0 },
};
