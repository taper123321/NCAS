#include <stdlib.h>

void *memset(void *dest, int c, unsigned int n);

void *sys_calloc(int elements, int elementSize){
    int p = elements*elementSize;
    void *tmp;
    tmp=malloc(p);
    if (tmp==0)
        return 0;

    memset(tmp, 0, p);
    return tmp;
}
