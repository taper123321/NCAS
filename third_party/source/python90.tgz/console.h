/*
  Console Lib for CASIO fx-9860G
  by Mike Smith.
*/

#ifndef CONSOLE_H
#define CONSOLE_H

#include <stdlib.h>
#include <string.h>
#include "calc.h"
#include <string>
#include <vector>
#ifdef TICE
#define LARGEDOUBLE 3e38
#else
#define LARGEDOUBLE 1e307
#endif

  extern int lang;
  extern int xthetat;
extern unsigned char* original_cfg;

  bool isalphanum(char c);
  extern bool clip_pasted;
  const char * paste_clipboard();
const char * select_var();
  void copy_clipboard(const ustl::string & s,bool status=true);
  void delete_clipboard();
  int confirm(const char * msg1,const char * msg2,bool acexit=false);
  bool confirm_overwrite();
  void invalid_varname();
  const char * keytostring(int key,int keyflag,bool py);
  int chartab();
void text_disp_menu(int keyflag);
  
  void print_alpha_shift(int keyflag);
ustl::string print_INT_(int i);
void insert(ustl::string & s,int pos,const char * add);
#ifdef FX
int inputline(const char * msg1,const char * msg2,ustl::string & s,bool numeric,int ypos=35);
#else
int inputline(const char * msg1,const char * msg2,ustl::string & s,bool numeric,int ypos=65);
#endif
  void set_pixel(int xc,int yc,unsigned short color);
  extern int clip_ymin; // 0 or 24
  void draw_line(int x1, int y1, int x2, int y2, int color=0,unsigned short motif=0xffff);
  void draw_circle(int xc,int yc,int r,int color,bool q1=true,bool q2=true,bool q3=true,bool q4=true);
  void draw_arc(int xc,int yc,int rx,int ry,int color,double theta1,double theta2);
  void draw_arc(int xc,int yc,int rx,int ry,int color,double t1, double t2,bool q1,bool q2,bool q3,bool q4);
  void draw_filled_circle(int xc,int yc,int r,int color,bool left=true,bool right=true);
  void draw_rectangle(int x, int y, int width, int height, unsigned short color);
void draw_filled_polygon(ustl::vector< ustl::vector<int> > & L,int xmin=0,int xmax=384,int ymin=0,int ymax=218,int color=0);
  void draw_polygon(ustl::vector< ustl::vector<int> > & L,int color=0);
  void draw_filled_arc(int x,int y,int rx,int ry,int theta1_deg,int theta2_deg,int color=0,int xmin=0,int xmax=384,int ymin=0,int ymax=218,bool segment=false);

void printCentered(const char* text, int y) ;
const char * input_matrix(bool list);
ustl::string help_insert(const char * cmdline,int & back,bool warn);
ustl::string printint(int );
int giacmin(int a,int b);
int giacmax(int a,int b);

#define MAX_FILENAME_SIZE 270
//#define CONSOLESTATEFILE (char*)DATAFOLDER"\\khicas.erd"

#ifdef FX

enum CONSOLE_SCREEN_SPEC{
  LINE_MAX = 32,
  LINE_DISP_MAX = 7,
  COL_DISP_MAX = 21,//21
  EDIT_LINE_MAX = 2048
};
#else
struct DISPBOX {
  int     left;
  int     top;
  int     right;
  int     bottom;
  unsigned char mode;
} ;

enum CONSOLE_SCREEN_SPEC{
  LINE_MAX = 64,
  LINE_DISP_MAX = 9,
  COL_DISP_MAX = 32,//21
  EDIT_LINE_MAX = 2048
};

#endif
struct location{
  int x;
  int y;
};


enum CONSOLE_RETURN_VAL{
  CONSOLE_NEW_LINE_SET = 1,
  CONSOLE_SUCCEEDED = 0,
  CONSOLE_MEM_ERR = -1,
  CONSOLE_ARG_ERR = -2,
  CONSOLE_NO_EVENT = -3
};

enum CONSOLE_CURSOR_DIRECTION{
  CURSOR_UP,
  CURSOR_DOWN,
  CURSOR_LEFT,
  CURSOR_RIGHT,
  CURSOR_SHIFT_LEFT,
  CURSOR_SHIFT_RIGHT,
  CURSOR_ALPHA_UP,
  CURSOR_ALPHA_DOWN,
};

enum CONSOLE_LINE_TYPE{
  LINE_TYPE_INPUT=0,
  LINE_TYPE_OUTPUT=1
};

enum CONSOLE_CASE{
  LOWER_CASE,
  UPPER_CASE
};

struct line{
  unsigned char *str=0;
  short int readonly;
  short int type;
  int start_col;
  int disp_len;
#ifdef TEX
  unsigned char *tex_str;
  unsigned char tex_flag;
  int tex_height, tex_width;
#endif
};
extern struct line * Line;
extern int Start_Line, Last_Line,editline_cursor;

struct FMenu{
  char* name;
  char** str;
  unsigned char count;
};

extern struct location Cursor;

#define MAX_FMENU_ITEMS 8
#define FMENU_TITLE_LENGHT 4

#define is_wchar(c) ((c == 0x7F) || (c == 0xF7) || (c == 0xF9) || (c == 0xE5) || (c == 0xE6) || (c == 0xE7))
#define printf(s) Console_Output((const unsigned char *)s);

int Console_DelStr(unsigned char *str, int end_pos, int n);
int Console_InsStr(unsigned char *dest, const unsigned char *src, int disp_pos);
int Console_GetActualPos(const unsigned char *str, int disp_pos);
int Console_GetDispLen(const unsigned char *str);
int Console_MoveCursor(int direction);
int Console_Input(const unsigned char *str);
int Console_Output(const unsigned char *str);
void Console_Clear_EditLine();
int Console_NewLine(int pre_line_type, int pre_line_readonly);
int Console_Backspace(void);
int Console_GetKey(void);
int Console_Init(void);
int Console_Disp(void);
int Console_FMenu(int key);
extern char menu_f1[16],menu_f2[16],menu_f3[16],menu_f4[16],menu_f5[16],menu_f6[16];
const char * console_menu(int key,unsigned char* cfg,int active_app);
const char * console_menu(int key,int active_app);
void Console_FMenu_Init(void);
const char * Console_Draw_FMenu(int key, struct FMenu* menu,unsigned char * cfg_,int active_app);
char *Console_Make_Entry(const unsigned char* str);
unsigned char *Console_GetLine(void);
unsigned char* Console_GetEditLine();
void Console_Draw_TeX_Popup(unsigned char* str, int width, int height);
void dConsolePut(const char *);
void dConsolePutChar(const char );
void dConsoleRedraw(void);
extern int dconsole_mode;
extern int console_changed; // 1 if something new in history
extern char session_filename[MAX_FILENAME_SIZE+1];
void translate_fkey(unsigned int & input_key);
bool inputdouble(const char * msg1,double & d);
#endif
