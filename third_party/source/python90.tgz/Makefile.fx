CXX	= sh3eb-elf-g++
CC	= sh3eb-elf-gcc
AR	= sh3eb-elf-gcc-ar
RANLIB	= sh3eb-elf-gcc-ranlib

RM	= /bin/rm

#CFLAGS = -Os -mb -m4a-nofpu -mhitachi -flto -fno-strict-aliasing  -fno-exceptions -DHAVE_CONFIG_H -DTIMEOUT -DRELEASE -I. -I../include -I../include/fx
#CXXFLAGS = -Os -mb -m4a-nofpu -mhitachi -std=c++98 -fpermissive -flto -fno-use-cxa-atexit -fno-strict-aliasing -fno-rtti -fno-exceptions -DHAVE_CONFIG_H -DTIMEOUT -DRELEASE -I. -I../include -I../include/ustl -I../include/fx

# make sure GINT_MALLOC is defined in Makefile from stdlib.c if using -DKMALLOC
CFLAGS = -Os -mb -m3 -mhitachi -flto -fno-strict-aliasing  -fno-exceptions -DHAVE_CONFIG_H -DKMALLOC -DFX -DMICROPY_LIB -DTIMEOUT -DRELEASE -I. -I../include -I../include/fx -ffunction-sections -fdata-sections
CXXFLAGS = -Os -g -mb -m3 -mhitachi -std=c++11  -fpermissive -fno-use-cxa-atexit -fno-strict-aliasing -fno-rtti -fno-exceptions -DHAVE_CONFIG_H -DTIMEOUT -DRELEASE -DMICROPY_LIB -DKMALLOC -DFX -I. -I../include -I../include/ustl -I../include/fx -flto -ffunction-sections -fdata-sections

LDFLAGS = -g -static -nostdlib -Taddin.ld  -Wl,--gc-sections

STDLIBS =  -L. -L../lib  -lustl -lsupc++ -lm -lc  -lgcc 

LIBS = -L. -L../lib -Wl,--start-group -lmicropy -lgui -lustl -lm -lc -lgcc -Wl,--end-group

GUI_OBJS = main.o console.o memory.o file.o textGUI.o modules.o casio.o

.PRECIOUS: libcas.a libgui.a

all: micropy.g1a # pour la version console, supprimer le lien iostream -> iostream.new

%.o: %.s
	$(CC) $(CFLAGS) -c $<

%.o: %.cc
	$(CXX) $(CXXFLAGS) -c $<

%.o: %.c
	$(CC) $(CFLAGS) -c $<

%.o: %.cpp
	$(CXX) $(CXXFLAGS) -c $<

libgui.a: $(GUI_OBJS)
	$(RM) -f $@
	$(AR) cru $@ $^
	$(RANLIB) $@

micropy.elf: libgui.a crt0.o syscalls.o menufr.o #catalogfr.o main.o
	$(CXX) $(LDFLAGS) crt0.o syscalls.o menufr.o $(LIBS) -o $@

micropy.g1a: micropy.elf
	sh3eb-elf-objcopy -R .comment -R .bss -O binary micropy.elf micropy.bin
	g1a-wrapper  micropy.bin -o micropy.g1a #-i micropy.bmp -v 1.5.1
	sh3eb-elf-nm micropy.elf > testelf
	sh3eb-elf-objdump -C -t micropy.elf | sort > dump_t
	/bin/cp micropy.g1a /shared/tmp

clean:
	$(RM) -f *.o *.elf *.bin libgui.a 
