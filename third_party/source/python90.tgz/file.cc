#if defined FX || defined FXCG // Casio
#include <string>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <alloca.h>
#include "menuGUI.h"
#include "file.h"
#include "calc.h"
#include "main.h"
#include "console.h"
#include "textGUI.h"
#include "qrcodegen.h"

#ifdef FXCG
int Bfile_CreateFile(const unsigned short* filename, int size) {
  return Bfile_CreateEntry_OS(filename,CREATEMODE_FILE,&size);
}
#endif

int get_filename(char * filename,const char * extension){
  handle_f5();
  ustl::string str;
  int res=inputline(lang?"EXIT/chaine vide: annulation":"EXIT or empty string: cancel",lang?"Nom de fichier:":"Filename:",str,false);
  if (res==KEY_CTRL_EXIT || str.empty())
    return 0;
  strcpy(filename,"\\\\fls0\\");
  strcpy(filename+7,str.c_str());
  int s=strlen(filename);
  if (strcmp(filename+s-3,extension))
    strcpy(filename+s,extension);
  // if file already exists, warn, otherwise create
  unsigned short pFile[MAX_FILENAME_SIZE+1];
  Bfile_StrToName_ncpy(pFile, (const unsigned char *)filename, strlen(filename)+1); 
  int hFile = Bfile_OpenFile_OS(pFile, _OPENMODE_READWRITE); // Get handle
  if(hFile < 0){
    save_script(filename,"");
    return 1;
    int size=1,BCEres = Bfile_CreateFile(pFile, size);
    BCEres = Bfile_OpenFile_OS(pFile, _OPENMODE_READWRITE); // Get handle
    //cout << "create " << filename << " " << BCEres << endl;
    if (BCEres<0)
      return 0;
    return 1;
  }
  Bfile_CloseFile_OS(hFile);
  if (confirm(lang?"     Le fichier existe!":"     File exists!",lang?"F1: ecraser,  F6: annuler":"F1:overwrite,  F6: cancel")==KEY_CTRL_F1)
    return 1;
  return 0;
}

int file_exists(const char * filename){
  if (filename && filename[0]!='\\'){
    // print_msg12("Checking \\\\fls0\\",filename); int key; ck_getkey(&key);
    char file[strlen(filename)+16]="\\\\fls0\\";
    strcat(file,filename);
    return file_exists(file);
  }
  unsigned short pFile[MAX_FILENAME_SIZE+1];
  Bfile_StrToName_ncpy(pFile, (const unsigned char *)filename, strlen(filename)+1);
  int hf = Bfile_OpenFile_OS(pFile, _OPENMODE_READWRITE); // Get handle
  // cout << hf << endl << "f:" << filename << endl; Console_Disp();
  if (hf < 0){
    // cout << "file does not exists -2\n";
    return 0; // nothing to load
  }
  Bfile_CloseFile_OS(hf);
  return 1;
}

int casio_fileBrowser(char* filename, const char* filter, const char* title) {
  // returns 1 when user selects a file, 0 when aborts (exit)
  int res = 1;
  char browserbasepath[MAX_FILENAME_SIZE+1] = "\\\\fls0\\";  
  while(res) {
    strcpy(filename, (char*)"");
    res = fileBrowserSub(browserbasepath, filename, filter, title);
    if(res==2) return 1; // user selected a file
  }
  return 0;
}

// FIXME!!!
int matchmask(const char * mask,const char * filename){
  if (strlen(mask)==4 && mask[0]=='*' && mask[1]=='.'){
    int s=strlen(filename);
    if (s<4) return 0;
    return filename[s-3]=='.' && filename[s-2]==mask[2] && filename[s-1]==mask[3];
  }
  return 1;
}

int compareFileStructs(File* f1, File* f2, int type) {
  if(f1->isfolder < f2->isfolder) return 1;
  else if(f1->isfolder > f2->isfolder) return -1;
  switch(type) {
    case 1:
      return strcmp( f1->filename, f2->filename );
    case 2:
      return -strcmp( f1->filename, f2->filename );
    case 3:
      return f1->size-f2->size;
    case 4:
    default:
      return f2->size-f1->size;
  }
}

void insertSortFileMenuArray(File* data, MenuItem* mdata, int size) {
  int sort = 1;//GetSetting(SETTING_FILE_MANAGER_SORT);
  if(!sort) return;
  int i, j;
  File temp;
  MenuItem mtemp;

  for(i = 1; i < size; i++) {
    temp = data[i];
    mtemp = mdata[i];
    for (j = i - 1; j >= 0 && compareFileStructs(&data[j], &temp, sort) > 0; j--) {
      data[j + 1] = data[j];
      mdata[j + 1] = mdata[j];
    }
    data[j + 1] = temp;
    mdata[j + 1] = mtemp;
  }
  // update menu text pointers (these are still pointing to the old text locations):
  for(i = 0; i < size; i++) mdata[i].text = data[i].visname;
}

bool end_with(const char * buffer,const char * end){
  int i=strlen(buffer);
  //return i<=10;
  int j=strlen(end);
  if (i<5 || j<4) return false;
  for (int k=-4;k<0;k++){
    if (buffer[i+k]!=end[j+k]) return false;
  }
  return true;
}

int GetFiles(File* files, MenuItem* menuitems, const char* basepath, int* count, const char* filter) {
  // searches storage memory for folders and files, puts their count in int* count
  // if File* files is NULL, function will only count files. If it is not null, MenuItem* menuitems will also be updated
  // this function always returns status codes defined on fileProvider.hpp
  // basepath should start with \\fls0\ and should always have a slash (\) at the end
  // filter is the filter for the files to list
  unsigned short path[MAX_FILENAME_SIZE+1], found[MAX_FILENAME_SIZE+1];
  char buffer[MAX_FILENAME_SIZE+1];

  // make the buffer
  strcpy(buffer, basepath);
  strcat(buffer, "*");
  
  *count = 0;
  file_type_t fileinfo;
  int findhandle;
  //confirm("GetFiles",basepath);
  Bfile_StrToName_ncpy(path, (const unsigned char *) buffer, MAX_FILENAME_SIZE+1);
  int ret = Bfile_FindFirst(path, &findhandle, found, &fileinfo);
  Bfile_StrToName_ncpy(path, (const unsigned char *)filter, MAX_FILENAME_SIZE+1);
  while (!ret) {
    Bfile_NameToStr_ncpy((unsigned char *)buffer, found, MAX_FILENAME_SIZE+1);
    if(!(strcmp((char*)buffer, "..") == 0 || strcmp((char*)buffer, ".") == 0 || strcmp((char*)buffer, "@MainMem") == 0)
      && (fileinfo.fsize == 0 ||
	  //end_with(buffer,filter)
	  //Bfile_Name_MatchMask((const short int*)found, (const short int*)path)
	  matchmask(filter, buffer)
	  ))
    {
      if(files != NULL) {
        strncpy(files[*count].visname, (char*)buffer, 40);
        strcpy(files[*count].filename, basepath); 
        strcat(files[*count].filename, (char*)buffer);
        //confirm(files[*count].filename,"");
        files[*count].size = fileinfo.fsize;
        files[*count].isfolder = menuitems[*count].isfolder = !fileinfo.fsize;
#if FILEICON
        if(fileinfo.fsize == 0) menuitems[*count].icon = FILE_ICON_FOLDER; // it would be a folder icon anyway, because isfolder is true
        else menuitems[*count].icon = fileIconFromName((char*)buffer);
#endif
        menuitems[*count].isselected = 0; //clear selection. this means selection is cleared when changing directory (doesn't happen with native file manager)
        // because usually alloca is used to declare space for MenuItem*, the space is not cleared. which means we need to explicitly set each field:
        menuitems[*count].text = files[*count].visname;
        menuitems[*count].color=_BLACK;
        menuitems[*count].type=MENUITEM_NORMAL;
        menuitems[*count].value=MENUITEM_VALUE_NONE;
      }
      *count=*count+1;
    }
    if (*count==MAX_ITEMS_IN_DIR) {
      Bfile_FindClose(findhandle);
      //confirm("loop close","sort");
      if (files != NULL && menuitems != NULL) insertSortFileMenuArray(files, menuitems, *count);
      return GETFILES_MAX_FILES_REACHED; // Don't find more files, the array is full. 
    } else ret = Bfile_FindNext(findhandle, found, &fileinfo);
  }
  Bfile_FindClose(findhandle);
  //confirm("close","sort");
  if (*count > 1 && files != NULL && menuitems != NULL) insertSortFileMenuArray(files, menuitems, *count);
  return GETFILES_SUCCESS;
}

void nameFromFilename(char* filename, char* name) {
  //this function takes a full filename like \\fls0\Folder\file.123
  //and puts file.123 in name.
  strcpy(name, (char*)"");
  int i=strlen(filename)-1;
  while (i>=0 && filename[i] != '\\')
          i--;
  if (filename[i] == '\\') {
    strcpy(name, filename+i+1);
  }
}

#ifdef FX
// monochrom Casio
int fileBrowserSub(char* browserbasepath, char* filename, const char* filter, const char* title) {
  Menu menu;
  
  // first get file count so we know how much to alloc
  GetFiles(NULL, NULL, browserbasepath, &menu.numitems, filter);
  MenuItem* menuitems = NULL;
  File* files = NULL;
  if(menu.numitems > 0) {
    menuitems = (MenuItem*)alloca(menu.numitems*sizeof(MenuItem));
    files = (File*)alloca(menu.numitems*sizeof(File));
    // populate arrays
    GetFiles(files, menuitems, browserbasepath, &menu.numitems, filter);
    menu.items = menuitems;
  }
  
  char titleBuffer[120];
  char titleBufferBuf[120];
  int smemfree=16384;
  unsigned short smemMedia[10]={'\\','\\','f','l','s','0',0};
  // Bfile_GetMediaFree_OS( smemMedia, &smemfree ); // inexistant syscall
  
  char friendlypath[MAX_FILENAME_SIZE];
  strcpy(friendlypath, browserbasepath+6);
  friendlypath[strlen(friendlypath)-1] = '\0'; //remove ending slash like OS does
  // test to see if friendlypath is too big
  int jump4=0;
  while(1) {
    int temptextX=7*4+10; // px length of menu title + 10, like menuGUI goes.
    int temptextY=0;
    temptextX += strlen(friendlypath)*4; // PrintMini(temptextX, temptextY, friendlypath, 0, 0xFFFFFFFF, 0, 0, _BLACK, _WHITE, 0, 0); // fake draw
    if(temptextX>LCD_WIDTH_PX-6) {
      char newfriendlypath[MAX_FILENAME_SIZE];
      shortenDisplayPath(friendlypath, newfriendlypath, (jump4 ? 4 : 1));
      if(strlen(friendlypath) > strlen(newfriendlypath) && strlen(newfriendlypath) > 3) { // check if len > 3 because shortenDisplayPath may return just "..." when the folder name is too big
        // shortenDisplayPath still managed to shorten, copy and continue
        jump4 = 1; //it has been shortened already, so next time jump the first four characters
        strcpy(friendlypath, newfriendlypath);
      } else {
        // shortenDisplayPath can't shorten any more even if it still
        // doesn't fit in the screen, so give up.
        break;
      }
    } else break;
  }
  menu.subtitle = friendlypath;
  menu.type = MENUTYPE_MULTISELECT;
  menu.scrollout=1;
  menu.nodatamsg = (char*)"No Data";
  menu.title = (char *)title; 
  while(1) {
    clear_screen();
    itoa(smemfree, (unsigned char*)titleBuffer);
    //LocalizeMessage1( 340, titleBufferBuf ); //"bytes free"
    strncat((char*)titleBuffer, (char*)titleBufferBuf, 65);
    menu.statusText = (char*)titleBuffer;
    int res = doMenu(&menu, 0);
    switch(res) {
      case MENU_RETURN_EXIT:
        if(!strcmp(browserbasepath,"\\\\fls0\\")) { //check that we aren't already in the root folder
          //we are, return 0 so we exit
          return 0;
        } else {
          int i=strlen(browserbasepath)-2;
          while (i>=0 && browserbasepath[i] != '\\')
                  i--;
          if (browserbasepath[i] == '\\') {
            char tmp[MAX_FILENAME_SIZE] = "";
            memcpy(tmp,browserbasepath,i+1);
            tmp[i+1] = '\0';
            strcpy(browserbasepath, tmp);
          }
          return 1; //reload at new folder
        }
        break;
      case MENU_RETURN_SELECTION:
        if(menuitems[menu.selection-1].isfolder) {
          strcpy(browserbasepath, files[menu.selection-1].filename); //switch to selected folder
          strcat(browserbasepath, "\\");
          return 1; //reload at new folder
        } else {
          strcpy(filename,files[menu.selection-1].filename);
          return 2;
        }
        break;

    }
  }
  return 1;
}

#else
// FXCG 
void buildIconTable(MenuItemIcon* icontable) {
  unsigned int msgno;
  unsigned short folder[7]={'\\','\\','f','l','s','0',0};

  const char *bogusFiles[] = {"t", // for folder
                              "t.g3m",
                              "t.g3e",
                              "t.g3a",
                              "t.g3p",
                              "t.g3b",
                              "t.bmp",
                              "t.txt",
                              "t.csv",
                              "t.abc" //for "unsupported" files
                             };

  for(int i = 0; i < 10; i++)
    SMEM_MapIconToExt( (unsigned char*)bogusFiles[i], (i==0 ? folder : (unsigned short*)"\x000\x000"), &msgno, icontable[i].data );
}

int fileBrowserSub(char* browserbasepath, char* filename, const char* filter, const char* title) {
  Menu menu;
  MenuItemIcon icontable[12];
#ifndef MPM
  buildIconTable(icontable);
#endif
  // confirm("filebrowsersub","0");
  // first get file count so we know how much to alloc
  GetFiles(NULL, NULL, browserbasepath, &menu.numitems, filter);
  MenuItem* menuitems = NULL;
  File* files = NULL;
  if(menu.numitems > 0) {
    //confirm("filebrowsersub","1");
    menuitems = (MenuItem*)alloca(menu.numitems*sizeof(MenuItem));
    files = (File*)alloca(menu.numitems*sizeof(File));
    // populate arrays
    GetFiles(files, menuitems, browserbasepath, &menu.numitems, filter);
    //confirm("filebrowsersub","2");
    menu.items = menuitems;
  }
  
  char titleBuffer[120];
  // char titleBufferBuf[120];
  int smemfree;
  unsigned short smemMedia[10]={'\\','\\','f','l','s','0',0};
  //confirm("filebrowsersub","3");
  Bfile_GetMediaFree_OS( smemMedia, &smemfree );
  //confirm("filebrowsersub","4");
  
  char friendlypath[MAX_FILENAME_SIZE];
  strcpy(friendlypath, browserbasepath+6);
  friendlypath[strlen(friendlypath)-1] = '\0'; //remove ending slash like OS does
  // test to see if friendlypath is too big
  int jump4=0;
  while(1) {
    // confirm("filebrowsersub",friendlypath);
    int temptextX=7*18+10; // px length of menu title + 10, like menuGUI goes.
    int temptextY=0;
    PrintMini(&temptextX, &temptextY, (unsigned char *)friendlypath, 0, 0xFFFFFFFF, 0, 0, COLOR_BLACK, COLOR_WHITE, 0, 0); // fake draw
    if(temptextX>LCD_WIDTH_PX-6) {
      char newfriendlypath[MAX_FILENAME_SIZE];
      shortenDisplayPath(friendlypath, newfriendlypath, (jump4 ? 4 : 1));
      if(strlen(friendlypath) > strlen(newfriendlypath) && strlen(newfriendlypath) > 3) { // check if len > 3 because shortenDisplayPath may return just "..." when the folder name is too big
        // shortenDisplayPath still managed to shorten, copy and continue
        jump4 = 1; //it has been shortened already, so next time jump the first four characters
        strcpy(friendlypath, newfriendlypath);
      } else {
        // shortenDisplayPath can't shorten any more even if it still
        // doesn't fit in the screen, so give up.
        break;
      }
    } else break;
  }
  menu.subtitle = friendlypath;
  menu.type = MENUTYPE_MULTISELECT;
  menu.scrollout=1;
  menu.nodatamsg = (char*)"No Data";
  menu.title = (char *)title;
  while(1) {
    Bdisp_AllClr_VRAM();
    itoa(smemfree, (unsigned char*)titleBuffer);
    strcat(titleBuffer," bytes free");
    // LocalizeMessage1( 340, titleBufferBuf ); //"bytes free"
    // strncat((char*)titleBuffer, (char*)titleBufferBuf, 65);
    menu.statusText = (char*)titleBuffer;
    int res = doMenu(&menu, 0); // icontable);
    switch(res) {
      case MENU_RETURN_EXIT:
        if(!strcmp(browserbasepath,"\\\\fls0\\")) { //check that we aren't already in the root folder
          //we are, return 0 so we exit
          return 0;
        } else {
          int i=strlen(browserbasepath)-2;
          while (i>=0 && browserbasepath[i] != '\\')
                  i--;
          if (browserbasepath[i] == '\\') {
            char tmp[MAX_FILENAME_SIZE] = "";
            memcpy(tmp,browserbasepath,i+1);
            tmp[i+1] = '\0';
            strcpy(browserbasepath, tmp);
          }
          return 1; //reload at new folder
        }
        break;
      case MENU_RETURN_SELECTION:
        if(menuitems[menu.selection-1].isfolder) {
          strcpy(browserbasepath, files[menu.selection-1].filename); //switch to selected folder
          strcat(browserbasepath, "\\");
          return 1; //reload at new folder
        } else {
          strcpy(filename,files[menu.selection-1].filename);
          return 2;
        }
        break;

    }
  }
  return 1;
}

#endif

void shortenDisplayPath(char* longpath, char* shortpath, int jump) {
  //this function takes a long path for display, like \myfolder\long\display\path
  //and shortens it one level, like this: ...\long\display\path
  //putting the result in shortpath
  strcpy(shortpath, (char*)"...");
  int i = jump; // jump the specified amount of characters... by default it jumps the first /
  // but it can also be made to jump e.g. 4 characters, which would jump ".../" (useful for when the text has been through this function already)
  int max = strlen(longpath);
  while (i<max && longpath[i] != '\\')
          i++;
  if (longpath[i] == '\\') {
    strcat(shortpath, longpath+i);
  }
}


bool save_script(const char * filename,const ustl::string & s){
  // cout << "save " << filename << " " << strlen(filename) << endl;
  unsigned short pFile[MAX_FILENAME_SIZE+1];
  // create file in data folder (assumes data folder already exists)
  Bfile_StrToName_ncpy(pFile, (const unsigned char *)filename, strlen(filename)+1);
  // even if it already exists, there's no problem,
  // in the event that our file shrinks, we just let junk be at the end of
  // the file (after two null bytes, of course).
  int hFile = Bfile_OpenFile_OS(pFile, _OPENMODE_READWRITE); // Get handle
  bool open=false;
  if(hFile < 0){
  }
  else {
    size_t old=Bfile_GetFileSize_OS(hFile);
    if (old<=s.size())
      open=true;
    else {
      Bfile_CloseFile_OS(hFile);
      Bfile_DeleteEntry(pFile);
    }
  }
  if (!open){
    // file does not exist yet. try creating it
    // (data folder should exist already, as save_console_state_smem() should have been called before this function)
    size_t size = 1;
    Bfile_CreateFile(pFile, size);
    // now try opening
    hFile = Bfile_OpenFile_OS(pFile, _OPENMODE_READWRITE); // Get handle
    if(hFile < 0) return false; // if it still fails, there's nothing we can do
  }
  Bfile_WriteFile_OS(hFile, s.c_str(), s.size());
  char buf[2]={0,0};
  Bfile_WriteFile_OS(hFile, buf, 2);
  Bfile_CloseFile_OS(hFile);
  return true;
}  

char * c_load_script(const char * filename){
  if (filename[0]!='\\'){
    char file[strlen(filename)+16]="\\\\fls0\\";
    strcat(file,filename);
    return c_load_script(file);
  }
  unsigned short pFile[MAX_FILENAME_SIZE+1];
  Bfile_StrToName_ncpy(pFile, (const unsigned char *)filename, strlen(filename)+1); 
  int hFile = Bfile_OpenFile_OS(pFile, _OPENMODE_READWRITE); // Get handle
  // Check for file existence
  if(hFile < 0) 
    return 0;
  // Returned no error, file exists, open it
  int size = Bfile_GetFileSize_OS(hFile);
  // File exists and has size 'size'
  // Read file into a buffer
  if ((unsigned int)size > MAX_TEXTVIEWER_FILESIZE) {
    Bfile_CloseFile_OS(hFile);
    puts("Stop: script too big");
    return 0; //file too big, return
  }
  unsigned char* asrc = (unsigned char*)malloc(size*sizeof(unsigned char)+5); // 5 more bytes to make sure it fits...
  if (!asrc) return 0;
  memset(asrc, 0, size+5); // Make sure the string is null-terminated this way.
  int rsize = Bfile_ReadFile_OS(hFile, asrc, size, 0);
  Bfile_CloseFile_OS(hFile); //we got file contents, close it
  asrc[rsize]='\0';
  return (char *) asrc;
}

int load_script(const char * filename,ustl::string & s){
  char * asrc=c_load_script(filename);
  if (!asrc)
    return 0;
  s=ustl::string((char *)asrc);
  free(asrc);
  return 1;
}

bool load_console_state_smem(const char * filename){
  unsigned short pFile[MAX_FILENAME_SIZE+1];
  Bfile_StrToName_ncpy(pFile, (const unsigned char *)filename, strlen(filename)+1);
  int hf = Bfile_OpenFile_OS(pFile, _OPENMODE_READWRITE); // Get handle
  if (hf < 0) return false; // nothing to load
  // int Bfile_ReadFile_OS(int HANDLE,void *buf,int size,int readpos);
  // read variables and modes
  int L=0;
  if (Bfile_ReadFile_OS(hf,&L,sizeof(L),-1)!=sizeof(L) || L==0){
    Bfile_CloseFile_OS(hf);
    return false;
  }  
  char BUF[L+4];
  // BUF[1]=BUF[0]='/'; // avoid trying python compat.
  // BUF[2]='\n';
  if (Bfile_ReadFile_OS(hf,BUF,L,-1)!=L){
    Bfile_CloseFile_OS(hf);
    return false;
  }
  BUF[L]=0;
  dconsole_mode=0;
  // try parsing heap size
  int hs=0;
  for (int i=0;i<L;++i){
    char ch=BUF[i];
    if (ch==' ' || ch==';')
      break;
    if (ch<'0' || ch>'9'){
      hs=0;
      break;
    }
    hs*=10;
    hs+=ch-'0';
  }
  if (hs>=32 && hs<=max_heap_size){
    //do_confirm(print_INT_(hs).c_str());
    pythonjs_heap_size=hs*1024;
  }
  // giac::gen g,ge;
  //xcas_mode(contextptr)=python_compat(contextptr)=0;
  //do_run((char*)BUF,g,ge);
  dconsole_mode=1;
  // read script
  if (Bfile_ReadFile_OS(hf,&L,sizeof(L),-1)!=sizeof(L)){
    Bfile_CloseFile_OS(hf);
    return false;
  }
  if (L>0){
    char bufscript[L+1];
    if (Bfile_ReadFile_OS(hf,bufscript,L,-1)!=L){
      Bfile_CloseFile_OS(hf);
      return false;
    }
    bufscript[L]=0;
    if (edptr==0)
      edptr=new textArea;
    if (edptr){
      edptr->elements.clear();
      edptr->clipline=-1;
      edptr->filename="\\\\fls0\\"+remove_path(remove_extension(filename))+".py";
      //cout << "script " << edptr->filename << endl;
      edptr->editable=true;
      edptr->changed=false;
      edptr->python=true;
      edptr->elements.clear();
      edptr->y=7;
      add(edptr,bufscript);
      edptr->line=0;
      //edptr->line=edptr->elements.size()-1;
      edptr->pos=0;
    }    
  }
  // read console state
  // insure parse messages are cleared
  Console_Init();
  Console_Clear_EditLine();
  for (int pos=0;;++pos){
    unsigned short int l,curs;
    unsigned char type,readonly;
    if (Bfile_ReadFile_OS(hf,&l,sizeof(l),-1)!=sizeof(l) || l==0) break;
    if (Bfile_ReadFile_OS(hf,&curs,sizeof(curs),-1)!=sizeof(curs)) break;
    if (Bfile_ReadFile_OS(hf,&type,sizeof(type),-1)!=sizeof(type)) break;
    if (Bfile_ReadFile_OS(hf,&readonly,sizeof(readonly),-1)!=sizeof(readonly)) break;
    char buf[l+1];
    buf[l]=0;
    if (Bfile_ReadFile_OS(hf,buf,l,-1)!=l) break;
    // ok line ready in buf
    while (Line[(Start_Line + Cursor.y)].readonly)
      Console_MoveCursor(CURSOR_DOWN);
    Console_Input((const unsigned char *)buf);
    Console_NewLine(LINE_TYPE_INPUT, 1);
#if 1
    if ((Start_Line + Cursor.y)>0){
      line & cur=Line[(Start_Line + Cursor.y)-1];
      cur.type=type;
      cur.readonly=readonly;
      cur.start_col+=curs;
    }
#endif
  }
  Bfile_CloseFile_OS(hf);
  console_changed=0;
  return true;
}

const int max_lines_saved=50;

// QR code 
static void do_QRdisp(const uint8_t qrcode[]) {
  drawRectangle(0,0,LCD_WIDTH_PX,LCD_HEIGHT_PX,0xffff);
  EnableStatusArea(3);
  int x=0,y=180;
  PrintMiniMini(&x,&y,(unsigned char *)"EXE or EXIT: leave. QR Code generator (c) Project Nayuki.",0,0,0);
  int size = qrcodegen_getSize(qrcode);
  int border = 0;
  int sb=size+border;
  int scale=177/sb;
  // confirm("sb",giac::print_INT_(sb).c_str());
  if (scale){
    for (int y = -border; y < size + border; y++) {
      for (int x = -border; x < size + border; x++) {
        drawRectangle(2+scale*(border+x),2+scale*(border+y),scale,scale,qrcodegen_getModule(qrcode, x, y)?0:0xffff);
      }
    }
  }
  while (1) {
    int key; ck_getkey(&key);
    if (key==KEY_CTRL_OK || key==KEY_CTRL_EXIT)
      break;
  }
  EnableStatusArea(0);
}

bool QRdisp(const char * text){
  // confirm("qrdisp",text);
  enum qrcodegen_Ecc errCorLvl = qrcodegen_Ecc_LOW;  // Error correction level
  
  // Make the QR Code symbol
  uint8_t qrcode[qrcodegen_BUFFER_LEN_MAX];
  uint8_t tempBuffer[qrcodegen_BUFFER_LEN_MAX];
  bool ok = qrcodegen_encodeText(text, tempBuffer, qrcode, errCorLvl,
                                 qrcodegen_VERSION_MIN, qrcodegen_VERSION_MAX, qrcodegen_Mask_AUTO, true);
  if (ok)
    do_QRdisp(qrcode);
  return ok;
}

ustl::string replace_html5(const ustl::string & s){
  ustl::string res;
  size_t ss=s.size(),i;
  for (i=0;i<ss;++i){
    char ch=s[i];
    if ( (ch>='0' && ch<='9') || (ch>='a' && ch<='z') || (ch>='A' && ch<='Z'))
      res += ch;
    else {
      res +='%';
      int t=(ch&0xf0)>>4;
      if (t<10) res += char('0'+t); else res += char('a'+(t-10));
      t=ch&0x0f;
      if (t<10) res += char('0'+t); else res += char('a'+(t-10));
    }
  }
  //std::cerr << s << '\n' << res << '\n';
  return res;
}

void save_console_state_smem(const char * filename,bool dispqr){
  console_changed=0;
  unsigned short pFile[MAX_FILENAME_SIZE+1];
  Bfile_StrToName_ncpy(pFile, (const unsigned char *)filename, strlen(filename)+1);
  ustl::string state(khicas_state());
  int statesize=state.size();
  ustl::string script;
  if (edptr)
    script=merge_area(edptr->elements);
  int scriptsize=script.size();
  // save format: line_size (2), start_col(2), line_type (1), readonly (1), line
  int size=2*sizeof(int)+statesize+scriptsize;
  int start_row=Last_Line-max_lines_saved; 
  if (start_row<0) start_row=0;
  for (int i=start_row;i<=Last_Line;++i){
    size += 2*sizeof(short)+2*sizeof(char)+strlen((const char *)Line[i].str);
  }
  // there's no need to delete and create again, because there's no problem
  // if there's junk at the end of the file.
  int hFile = Bfile_OpenFile_OS(pFile, _OPENMODE_READWRITE); // Get handle
  if(hFile < 0) {
    // could not open file. file might not exist yet, or the data folder might not exist at all.
    // try creating both and try opening again
    // create_data_folder();
    Bfile_CreateFile(pFile, size);
    hFile = Bfile_OpenFile_OS(pFile, _OPENMODE_READWRITE); // Get handle
    if(hFile < 0) return; // if it still fails, there's nothing we can do
  }
  unsigned char BUF[size+2];
  BUF[size]=0; BUF[size+1]=0;
  unsigned char * ptr=BUF;
  // save variables and modes
  memcpy(ptr,&statesize,sizeof(statesize)); ptr+=sizeof(statesize);
  memcpy(ptr,state.c_str(),statesize); ptr+=statesize;
  // save script
  memcpy(ptr,&scriptsize,sizeof(scriptsize)); ptr+=sizeof(scriptsize);
  if (scriptsize)
    memcpy(ptr,script.c_str(),scriptsize); ptr+=scriptsize;
  int pos=1;
  ustl::string qrs=lang?"http://www-fourier.univ-grenoble-alpes.fr/~parisse/xcasfr.html#":"http://www-fourier.univ-grenoble-alpes.fr/~parisse/xcasen.html#";//"https://xcas.univ-grenoble-alpes.fr/xcasjs/#";
  if (dispqr){
    qrs += "micropy=";
    qrs += "0,0,"+replace_html5(script)+'&';
  }
  // save console state
  for (int i=start_row;i<=Last_Line;++i){
    line & cur=Line[i];
    unsigned short l=strlen((const char *)cur.str);
    memcpy(ptr,&l,sizeof(l)); ptr+=sizeof(l);// Bfile_WriteFile_OS(hFile, &l, sizeof(l));
    unsigned short s=cur.start_col;
    memcpy(ptr,&s,sizeof(s)); ptr+=sizeof(s);// Bfile_WriteFile_OS(hFile, &s, sizeof(s));
    unsigned char c=cur.type;
    memcpy(ptr,&c,sizeof(c)); ptr+=sizeof(c); // Bfile_WriteFile_OS(hFile, &c, sizeof(c));
    if (c==0){ // qrcode write input
      ustl::string qrsadd = replace_html5((const char *)cur.str);
      int xpos=(pos%2)*400;
      int ypos=(pos/2)*400;
      ++pos;
      if (dispqr){
        char bufx[16]; sprint_int(bufx,xpos);
        ustl::string spos=bufx;
        spos +=",";
        sprint_int(bufx,ypos);
        spos += bufx;
        spos += ",";
        qrs += "micropy=";
        qrs += spos+qrsadd+'&';
      }
    }
    c=true;//cur.readonly;
    memcpy(ptr,&c,sizeof(c)); ptr+=sizeof(c); // Bfile_WriteFile_OS(hFile, &c, sizeof(c));
    memcpy(ptr,cur.str,l); //ptr+=l;// Bfile_WriteFile_OS(hFile, cur.str, l);
    unsigned char *strend=ptr+l;
    for (;ptr<strend;++ptr){
      if (*ptr==0x9c)
	*ptr='\n';
    }    
  }
  Bfile_WriteFile_OS(hFile, BUF, size+2);
  Bfile_CloseFile_OS(hFile);
  if (dispqr)
    QRdisp(qrs.c_str());
}






#endif // FX || FXCG
