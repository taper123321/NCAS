//#define DBG 0
#include <string>
#include "calc.h"

#include "console.h"
//#include "menu_config.h"
#include "menuGUI.h"
#include "textGUI.h"
#include "file.h"
#include "main.h"
using namespace ustl;
#define EXPR_BUF_SIZE 256
#define GIAC_HISTORY_SIZE 2
#define GIAC_HISTORY_MAX_TAILLE 32

bool freeze=false,freezeturtle=false;
int pythonjs_stack_size=20*1024,pythonjs_heap_size=max_heap_size*1024*.7;
char * pythonjs_static_heap=0;
char * python_heap=0;
extern "C" int mp_token(const char * line);
extern "C" {
#include <fxcg/rtc.h>
  extern int execution_in_progress_py;
  extern volatile int ctrl_c_py;
  //void set_abort_py();
  //void clear_abort_py();
}

void python_free(){
  if (!python_heap) return;
  mp_deinit();
  if (!pythonjs_static_heap){
    if ( ((size_t) python_heap)>1)
      free(python_heap);
  }
  python_heap=0;
}

int python_init(int stack_size,int heap_size){
  python_free();
  // python_heap=micropy_init(8192,16384);
  dConsolePut(("Heap "+print_INT_(heap_size/1024)+"K MicroPython 1.12").c_str());
  Console_NewLine(LINE_TYPE_OUTPUT,1);
  python_heap=micropy_init(stack_size,heap_size);
  //confirm("heap","init");
  if (!python_heap)
    return 0;
  return 1;
}

int micropy_ck_eval(const char *line){
  freeze=false; freezeturtle=false;
  if (python_heap && line[0]==0)
    return 1;
  if (!python_heap){
    python_init(pythonjs_stack_size,pythonjs_heap_size);
  }
  if (!python_heap){
    return RAND_MAX;
  }
  ctrl_c_py=0;
  execution_in_progress_py = 1;
  int res= micropy_eval(line);
  execution_in_progress_py = 0;
  if (ctrl_c_py & 1){
    confirm("Interrupted","F1/F6: ok",""); // insure ON has been removed from keyboard buffer
  }  
  //while (1) { int key; ck_getkey(&key); if (key==KEY_CTRL_EXIT) break; }
  return res;
}

int select_item(const char ** ptr,const char * title,bool askfor1){
  int nitems=0;
  for (const char ** p=ptr;*p;++p)
    ++nitems;
  if (nitems==0 || nitems>=256)
    return -1;
  if (!askfor1 && nitems==1)
    return 0;
  MenuItem smallmenuitems[nitems];
  for (int i=0;i<nitems;++i){
    smallmenuitems[i].text=(char *) ptr[i];
  }
  Menu smallmenu;
  smallmenu.numitems=nitems; 
  smallmenu.items=smallmenuitems;
  smallmenu.height=8;
  smallmenu.scrollbar=1;
  smallmenu.scrollout=1;
  smallmenu.title = (char*) title;
  //MsgBoxPush(5);
  int sres = doMenu(&smallmenu);
  //MsgBoxPop();
  if (sres!=MENU_RETURN_SELECTION && sres!=KEY_CTRL_EXE)
    return -1;
  return smallmenu.selection-1;
}

int process_freeze(){
  if (freezeturtle){
    displaylogo();
    freezeturtle=false;
    return 1;
  }
  if (freeze){
    freeze=false;
    int key;
    ck_getkey(&key);
    return 1;
  }
  return 0;
}    


// extern U ** mem;
// extern unsigned int **free_stack;

#define SYMBOLSSTATEFILE (char*)"\\\\fls0\\lastvar.py"
  

//const char * keywords[]={"do","faire","for","if","return","while"}; // added to lexer_tab_int.h

  const char * python_keywords[] = {   // List of known giac keywords...
    "False",
    "None",
    "True",
    "and",
    "break",
    "continue",
    "def",
    "default",
    "elif",
    "else",
    "except",
    "for",
    "from",
    "global",
    "if",
    "import",
    "not",
    "or",
    "return",
    "throw",
    "try",
    "while",
    "xor",
    "yield",
  };
  const char * const python_builtins[]={
    "NoneType",
    "__call__",
    "__class__",
    "__delitem__",
    "__dir__", 
    "__enter__",
    "__exit__",
    "__getattr__",
    "__getitem__",
    "__hash__",
    "__init__",
    "__int__",
    "__iter__",
    "__len__",
    "__main__",
    "__module__",
    "__name__",
    "__new__",
    "__next__",
    "__qualname__",
    "__repr__",
    "__setitem__",
    "__str__",
    "abs",
    "all",
    "any",
    "append",
    "args",
    "bool",
    "builtins",
    "bytearray",
    "bytecode",
    "bytes",
    "callable",
    "chr",
    "classmethod",
    "complex",
    "dict",
    "dir",
    "divmod",
    "eval",
    "exec",
    "float",
    "format",
    "getattr",
    "globals",
    "hasattr",
    "hash",
    "hex",
    "id",
    "index",
    "input",
    "int",
    "iter",
    "len",
    "list",
    "locals",
    "map",
    "max",
    "min",
    "next",
    "object",
    "oct",
    "pow",
    "print",
    "range",
    "repr",
    "reversed",
    "round",
    "self",
    "set",
    "setattr",
    "sorted",
    "split",
    "str",
    "sum",
    "super",
    "tuple",
    "type",
    "zip",
  };

  int dichotomic_search(const char * const * tab,unsigned tab_size,const char * s){
    int beg=0,end=tab_size,cur,test;
    // string index is always >= begin and < end
    for (;;){
      cur=(beg+end)/2;
      test=strcmp(s,tab[cur]);
      if (!test)
	return cur;
      if (cur==beg)
	return -1;
      if (test>0)
	beg=cur;
      else
	end=cur;
    }
    return -1;
  }

  bool is_python_keyword(const char * s){
    return dichotomic_search(python_keywords,sizeof(python_keywords)/sizeof(char*),s)!=-1;
  }
  
  bool is_python_builtin(const char * s){
    return dichotomic_search(python_builtins,sizeof(python_builtins)/sizeof(char*),s)!=-1;
  }

int find_color(const char * s){
  if (!s) return 0;
  char ch=s[0];
  if (ch=='"')
    return _YELLOW;
  if (!isalpha(s[0]))
    return 0;
  char buf[256];
  const char * ptr=s;
  for (int i=0;i<255 && (isalphanum(*ptr) || *ptr=='_'); ++i){
    ++ptr;
  }
  strncpy(buf,s,ptr-s);
  buf[ptr-s]=0;
  if (strcmp(buf,"def")==0 || strcmp(buf,"import")==0)
    return _BLUE;
  if (is_python_keyword(buf))
    return _BLUE;
  if (is_python_builtin(buf))
    return _CYAN;
  if (micropy_ck_eval("")!=RAND_MAX){
    int token=mp_token(buf);
    if (token) return _RED;
    return 0;
  }
  return 0;
}

ustl::string get_searchitem(ustl::string & replace){
  replace="";
  ustl::string search;
  handle_f5();
  int res=inputline(lang?"EXIT ou chaine vide: annulation":"EXIT or empty string: cancel",lang?"Chercher:":"Search:",search,false);
  if (search.empty() || res==KEY_CTRL_EXIT)
    return "";
  replace="";
  ustl::string tmp=(lang?"EXIT: recherche seule de ":"EXIT: search only ")+search;
  handle_f5();
  res=inputline(tmp.c_str(),lang?"Remplacer par:":"Replace by:",replace,false);
  if (res==KEY_CTRL_EXIT)
    replace="";
  return search;
}

ustl::string * read_file_sptr=0;
const char * read_file(const char * filename){
  if (!filename) return 0;
  if (filename[0]!='\\'){
    char file[strlen(filename)+16]="\\\\fls0\\";
    strcat(file,filename);
    return read_file(file);
  }
  if (!read_file_sptr)
    read_file_sptr=new ustl::string;
  if (!read_file_sptr)
    return 0;
  if (load_script(filename,*read_file_sptr)<=0)
    return 0;
  // confirm("read_file",read_file_sptr->substr(0,15).c_str());
  return read_file_sptr->c_str();
}


// returns 1 if script was run, 0 otherwise
int run_script(const char* filename) {
  char * s=c_load_script(filename);
  if (!s)
    return 0;
  micropy_ck_eval(s);
  free(s);
  process_freeze();
  return 1;
}

int select_script_and_run() {
  char filename[MAX_FILENAME_SIZE+1];
  if(fileBrowser(filename, (char*)"*.py", (char *)"Run script")) 
    return run_script(filename);
  return 0;
}

void erase_script(){
  char filename[MAX_FILENAME_SIZE+1];
  int res=fileBrowser(filename, (char*)"*.py", (char *)"Scripts");
  if (res && do_confirm(lang?"Vraiment effacer":"Really erase?")){
    erase_file(filename);
  }
}

string extract_name(const char * s){
  int l=strlen(s),i,j;
  for (i=l-1;i>=0;--i){
    if (s[i]=='.')
      break;
  }
  if (i<=0)
    return "f";
  for (j=i-1;j>=0;--j){
    if (s[j]=='\\')
      break;
  }
  if (j<0)
    return "f";
  return string(s+j+1).substr(0,i-j-1);
}

void edit_script(const char * fname){
  // clear_abort();
  char fname_[MAX_FILENAME_SIZE+1];
  char * filename=0;
  int res=1;
  if (fname)
    filename=(char *)fname; // safe, it will not be modified
  else {
    res=fileBrowser(fname_, (char*)"*.py", (char *)"Scripts");
    filename=fname_;
  }
  if (res) {
    string s;
    load_script(filename,s);
    if (s.empty()){
      int k=confirm("Program","F1: Tortue, F6: Python",true);
      if (k==-1)
	return;
      if (k==KEY_CTRL_F1)
	s="\nefface;\n ";
      else{
	s=extract_name(filename);
	if (s=="session")
	  s="f";
	s="def "+s+"(x):\n  \n  return x";
      }
    }
    // split s at newlines
    if (edptr==0)
      edptr=new textArea;
    if (!edptr) return;
    edptr->elements.clear();
    edptr->clipline=-1;
    edptr->filename="\\\\fls0\\"+remove_path(remove_extension(filename))+".py";
    //cout << "script " << edptr->filename << endl;
    edptr->editable=true;
    edptr->changed=false;
    edptr->python=true;
    edptr->longlinescut=false;
    edptr->elements.clear();
    edptr->y=7;
    add(edptr,s);
    s.clear();
    edptr->line=0;
    //edptr->line=edptr->elements.size()-1;
    edptr->pos=0;
    int res=doTextArea(edptr);
  }
}

string khicas_state(){
  return print_INT_(pythonjs_heap_size/1024)+" ;";
}

void save_khicas_symbols_smem(const char * filename) {
  // save variables in xcas mode,
  // because at load time the parser will be in xcas mode
  string s(khicas_state());
  save_script(filename,s);
}

string remove_path(const string & st){
  int s=int(st.size()),i;
  for (i=s-1;i>=0;--i){
    if (st[i]=='\\')
      break;
  }
  return st.substr(i+1,s-i-1);
}


string remove_extension(const string & st){
  int s=int(st.size()),i;
  for (i=s-1;i>=0;--i){
    if (st[i]=='.')
      break;
  }
  return st.substr(0,i);
}

void save(const char * fname){
  //clear_abort();
  string filename(remove_path(remove_extension(fname)));
  save_console_state_smem(("\\\\fls0\\"+filename+".xw").c_str(),strcmp(filename,"session")); // call before save_khicas_symbols_smem(), because this calls create_data_folder if necessary!
  // save_khicas_symbols_smem(("\\\\fls0\\"+filename+".xw").c_str());
  if (edptr)
    check_leave(edptr);
}

void save_session(){
  if (strcmp(session_filename,"session") && console_changed){
    ustl::string tmp(session_filename);
    tmp += lang?" a ete modifie!":" was modified!";
    if (confirm(tmp.c_str(),lang?"F1: sauvegarder, F6: tant pis":"F1: save, F6: discard changes")==KEY_CTRL_F1){
      save(session_filename);
      console_changed=0;
    }    
  }
  save("session");
  // this is only called on exit, no need to reinstall the check_execution_abort timer.
  if (edptr && edptr->changed && edptr->filename!="\\\\fls0\\session.py"){
    if (!check_leave(edptr)){
      save_script("\\\\fls0\\lastprg.py",merge_area(edptr->elements));
    }
  }
}

int restore_session(const char * fname){
  string filename(remove_path(remove_extension(fname)));
  if (load_console_state_smem(("\\\\fls0\\"+filename+".xw").c_str()))
    return 1;
  else {
    Bdisp_AllClr_VRAM();  
    os_draw_string_medium_(0, 0,"mPython (c) D. George et al");
    os_draw_string_medium_(0, C18,"UI & some modules");
    os_draw_string_medium_(0,C18*2,"(c) B. Parisse et al");
    os_draw_string_medium_(0,C18*3,"License GPL 2");
    os_draw_string_medium(0,C18*4,SDK_WHITE,SDK_BLACK,"  Some key shortcuts  ",false);
    os_draw_string_medium_(0,C18*5,"-> : run a script");
    os_draw_string_medium_(0,C18*6,"F3: char table");
    os_draw_string_medium_(0,C18*7,"F6 sin more shortcuts");
    int key; ck_getkey(&key);
    return 0;
  }
}

#ifdef TEX
#include "TeX.h"
int tex_flag=1;
extern "C"{
  int* get_tex_flag_address(){
    return &tex_flag;
  }
}

void TeX_init(void){
  Txt_Init(FONT_SYSTEM);
}

void TeX_quit(void){
  Txt_Quit();
}
#endif



bool textedit(char * s){
  if (!s)
    return false;
  int ss=strlen(s);
  if (ss==0){
    *s=' ';
    s[1]=0;
    ss=1;
  }
  textArea ta;
  ta.elements.clear();
  ta.editable=true;
  ta.clipline=-1;
  ta.changed=false;
  ta.filename="\\\\fls0\\temp.py";
  ta.y=7;
  ta.allowEXE=true;
  bool str=s[0]=='"' && s[ss-1]=='"';
  if (str){
    s[ss-1]=0;
    add(&ta,s+1);
  }
  else
    add(&ta,s);
  ta.line=0;
  ta.pos=ta.elements[ta.line].s.size();
  int res=doTextArea(&ta);
  if (res==TEXTAREA_RETURN_EXIT)
    return false;
  string S(merge_area(ta.elements));
  if (str)
    S='"'+S+'"';
  int Ssize=S.size();
  if (Ssize<GEN_PRINT_BUFSIZE){
    strcpy(s,S.c_str());
    for (--Ssize;Ssize>=0;--Ssize){
      if ((unsigned char)s[Ssize]==0x9c || s[Ssize]=='\n')
	s[Ssize]=0;
      if (s[Ssize]!=' ')
	break;
    }
    return true;
  }
  return false;
}

bool stringtodouble(const string & s1,double & d){
  char * ptr=0;
  d=strtod(s1.c_str(),&ptr);
  return ptr!=0;
}

void do_run(const char * s){
  int S=strlen(s);
  char * buf=(char *)malloc(S+1);
  if (!buf){
    do_confirm("Memory full");
    return;
  }
  buf[S]=0;
  for (int i=0;i<S;++i){
    char c=s[i];
    if (c==0x1e || c==char(0x9c))
      buf[i]='\n';
    else {
      if (c==0x0d)
	buf[i]=' ';
      else
	buf[i]=c;
    }
  }
  execution_in_progress_py = 1;
  // set_abort_py();
  int res=micropy_ck_eval(buf);
  free(buf);
  // clear_abort_py();
  execution_in_progress_py = 0;
  if (get_free_memory()<8*1024){
    // FIXME? clear turtle, display msg
  } 
  //Console_Output("Done"); return ;
}

void run(const char * s,int do_logo_graph_eqw){
  if (strlen(s)>=2 && (s[0]=='#' ||
		       (s[0]=='/' && (s[1]=='/' || s[1]=='*'))
		       ))
    return;
  do_run(s);
  process_freeze();
  //return ge; 
}


void stop(const char * s){
}

#ifdef KMALLOC
kmalloc_arena_t static_ram = { 0 },ram3M={0};
#ifdef FXCG
#ifdef GINT_MALLOC
// #define VAR_HEAP
#ifdef VAR_HEAP
__attribute__((aligned(4))) char malloc_heap[240*1024];
#else
/* Unused part of user stack; provided by linker script */
extern char sextra, eextra;
#endif
#endif // KMALLOC

int get_free_memory(){
  kmalloc_gint_stats_t * s;
  s=kmalloc_get_gint_stats(&ram3M);
  if (!s) return 0;
  int res=s->free_memory;
  return res;
}
#else // FXCG
#ifdef FX
int get_free_memory(){
  kmalloc_gint_stats_t * s;
  s=kmalloc_get_gint_stats(&static_ram);
  int res=s?s->free_memory:0;
  return res;
}
#else // FX
int get_free_memory(){
  return freeslotmem();
}
#endif // FX
#endif // FXCG
#endif // KMALLOC

vector<logo_turtle> & turtle_stack();

int main1(){
#ifdef FX
  char const *osv = (const char *)0xa0010020;
  if (!strncmp(osv, "03.", 3) && osv[3] <= '8')
    ; // free memory 0x88050000-0x8807ffff for this OS version was checked
  else {
    char buf1[10],buf[256];
    // sprintf(buf,"%i",availram);
    strncpy(buf1,osv,8);
    buf1[8]=0;
    sprintf(buf,"OS %s not checked",buf1);
    if (confirm(buf,"F1: cancel, F6: continue anyway")!=KEY_CTRL_F6){
      print_msg12("Press MENU to leave","");
      int key;
      for(;;)
	ck_getkey(&key);
      return 0;
    }
  }
#ifdef KMALLOC

  /* À appeler une seule fois au début de l'exécution */
  kmalloc_init();
  
  /* Ajouter une arène sur la RAM inutilisée */
  static_ram.name = "_uram";
  static_ram.is_default = 1; // 0 for system malloc first
  static_ram.start = (void *)  0x88053800; // tab24+6144
  static_ram.end =  (void *) 0x8807f000;
  kmalloc_init_arena(&static_ram, true);
  kmalloc_add_arena(&static_ram);
#endif // KMALLOC
#endif // FX

#ifdef FXCG
  Bdisp_EnableColor(1);
  char color1 = TEXT_COLOR_BLUE;
  char color2 = TEXT_COLOR_GREEN;
  DefineStatusAreaFlags(3, SAF_BATTERY | SAF_TEXT | SAF_GLYPH | SAF_ALPHA_SHIFT, &color1, &color2);
  char const *osv = (const char *)0x80020020;
  if (
#ifdef MPM
      !strncmp(osv, "02.", 3)
#else
      !strncmp(osv, "03.", 3) && osv[3] <= '8'
#endif
      ){ // 3.8 or earlier
    char buf[256];
    // sprintf(buf,"%i",availram);
    strncpy(buf,osv,8);
    buf[8]=0;
    //print_msg12("OS ok version",buf); int key; ck_getkey(&key);
  }
  else {
    char buf1[10],buf[256];
    // sprintf(buf,"%i",availram);
    strncpy(buf1,osv,8);
    buf1[8]=0;
    sprintf(buf,"OS %s not checked",buf1);
    if (confirm(buf,"F1: cancel, F6: continue anyway")!=KEY_CTRL_F6){
      print_msg12("Press MENU to leave","");
      int key;
      for(;;)
	GetKey(&key);
      return 0;
    }
  }
  //do_confirm("main");
  // confirm("main","0");
  bool is_emulator = *(volatile uint32_t *)0xff000044 == 0x00000000;
  uint32_t stack;
  __asm__("mov r15, %0" : "=r"(stack));
  bool prizmoremu=stack<0x8c000000;
#ifdef GINT_MALLOC
  /* À appeler une seule fois au début de l'exécution */
  kmalloc_init();
#if 1
  /* Ajouter une arène sur la RAM inutilisée */
  static_ram.name = "_uram";
  static_ram.is_default = 0; // 0 disable this area, 1 enable
#ifdef VAR_HEAP
  static_ram.start = malloc_heap;
  static_ram.end = malloc_heap+sizeof(malloc_heap);
#else
  //void *malloc_start = &sextra;
  //void *malloc_end = &eextra;
  //int malloc_size = malloc_end - malloc_start;
  static_ram.start = &sextra;
  static_ram.end = &eextra;
#endif
  kmalloc_init_arena(&static_ram, true);
  kmalloc_add_arena(&static_ram);
#endif
  if (prizmoremu) {
    /* Prizm ou émulateur Graph 90+E */
#if 1
    static_ram.is_default = 1; // 0 disable this area, 1 enable
    pythonjs_heap_size=128*1024;
#else
    ram3M.name="_3M";
    ram3M.is_default=1;
    ram3M.start=0x88480000;
    ram3M.end=ram3M.start+0x80000;
    kmalloc_init_arena(&ram3M, true);
    kmalloc_add_arena(&ram3M);
    pythonjs_heap_size=256*1024;
#endif
  }
  else {
    /* Graph 90+E & FXCG50(?) */
    ram3M.name="_3M";
    ram3M.is_default=1;
    ram3M.start=(void*) 0x8c200000;
    ram3M.end=(void*) ( (unsigned)ram3M.start+0x400000);
    kmalloc_init_arena(&ram3M, true);
    kmalloc_add_arena(&ram3M);
    pythonjs_heap_size=3600*1024;    
  }
#endif // GINT_MALLOC
#endif // FXCG
  int i = 0, j = 0;
  
  SetQuitHandler(save_session); // automatically save session when exiting
  // FIXME turtle
  turtle(); 
  turtle_stack(); // required to init turtle
  Console_Init();
  // do_confirm("console init");
  restore_session("session");
#ifdef FXCG
  if (prizmoremu && pythonjs_heap_size>=370*1024)
    pythonjs_heap_size=370*1024;
#endif
  //pythonjs_static_heap=(char *)malloc(pythonjs_heap_size);
  python_init(pythonjs_stack_size,pythonjs_heap_size);
  //do_confirm("after init");
  //load_config();
  Console_Disp();
  init_locale();
  // { statuslinemsg("after console init"); int key; GetKey(&key); }
  //do_confirm("ready");
  //Bkey_SetAllFlags(0x80); // disable catalog syscall 0x0EA1 on the Prizm
  // initialize failed ?
  // if (!(line && free_stack && mem && stack && symtab && binding && arglist && logbuf))		return 0;
  while (1) { 
    unsigned char *expr=Console_GetLine();
    if ( expr==NULL )
      stop("memory error");
#if 1 // def MPM 
    if (strcmp((const char *)expr,"quit")==0){ // expr[0]=='0' && expr[1]==0)
      save_session();      
      break;
    }
#endif
    if (strcmp((const char *)expr,"FD")==0 || ((expr[0]=='R' || expr[0]=='S') && ((expr[1]>='0' && expr[1]<='9') || (expr[1]>='A' && expr[1]<='F')) && expr[2]==0)){
      int size = 0x4000;
      unsigned src=0xfd800000;
      if (expr[0]=='R' || expr[0]=='S'){
        size=0x100000;
        int i=expr[1]>='A'?(expr[1]-'A'+10):(expr[1]-'0');
        if (expr[0]=='S')
          i+=16;
        src=0x80000000+i*size;
      }
      string filename("\\\\fls0\\");
      filename += (char *) expr;
      filename += ".bin";
      Console_Output((const unsigned char *)"Rom/ram dump");
      Console_NewLine(LINE_TYPE_OUTPUT,1);
      Console_Output((const unsigned char *)filename.c_str());
      Console_NewLine(LINE_TYPE_OUTPUT,1);
      unsigned short pFile[64];
      Bfile_StrToName_ncpy(pFile, (const unsigned char *)(filename.c_str()), filename.size()+1); 
      int hFile = Bfile_OpenFile_OS(pFile, _OPENMODE_READWRITE); // Get handle
      if (hFile<0){
        int s=1;
        Bfile_CreateEntry_OS(pFile, CREATEMODE_FILE,&s);
        // now retry opening
        hFile = Bfile_OpenFile_OS(pFile, _OPENMODE_READWRITE); // Get handle
      }
      else {
        size_t old=Bfile_GetFileSize_OS(hFile);
      }
      if(hFile < 0)
        Console_Output((const unsigned char *)"Unable to open file");
      else {
        int rsize = Bfile_WriteFile_OS(hFile, (const void *) src, size); // rsize should be == to size
        Bfile_CloseFile_OS(hFile);
        Console_Output((const unsigned char *)"Written");
      }
      Console_NewLine(LINE_TYPE_OUTPUT,1);
      //ck_getkey(&key);
      Console_Disp();
      continue; 
    }
    if (strcmp((const char *)expr,"restart")==0){
      if (confirm(lang?"Effacer variables?":"Clear variables?",lang?"F1: annul,  F6: confirmer":"F1: cancel,  F6: confirm")!=KEY_CTRL_F6){
        Console_Output((const unsigned char *)" cancelled");
        Console_NewLine(LINE_TYPE_OUTPUT,1);
        //ck_getkey(&key);
        Console_Disp();
        continue;
      }
    }
    // should save in another file
    if (strcmp((const char *)expr,"=>")==0 || strcmp((const char *)expr,"=>\n")==0){
      save_session();
      Console_Output((unsigned char*)"Session saved");
    }
    else 
      run((char *)expr);
    //print_mem_info();
    Console_NewLine(LINE_TYPE_OUTPUT,1);
    //ck_getkey(&key);
    Console_Disp();
  }
#ifndef MPM
  int key; for(;;) ck_getkey(&key);
#endif
  return 1;
}

typedef void (*cxx_constructor)(void);

extern "C" unsigned char datald; // _data_section_start_flash;
extern "C" unsigned char sdata; // _data_section_start_ram;
extern "C" unsigned char edata; // _data_section_end_ram;
extern "C" unsigned char bbss; // bss__section_start_ram;
extern "C" unsigned char ebss; // _bss_section_end_ram;
extern "C" cxx_constructor init_array_start;
extern "C" cxx_constructor init_array_end;

int main(){
#if 0 // def MPM // init already done  in crt0.S
  unsigned char * dest=&sdata,*end=&edata,*src=&datald;
  for (;dest<end;){
    *dest=*src;
    ++dest; ++src;
  }
  dest=&bbss; end=&ebss;
  for (;dest<end;++dest)
    *dest=0;
  Bdisp_AllClr_VRAM(); 
  { int key; GetKey(&key); }
#endif
#if 0 
  void (*boot_os)(void)=0x80020080;
  boot_os();
#endif
  Bdisp_EnableColor(1); // os_fill_rect(0,0,LCD_WIDTH_PX,LCD_HEIGHT_PX,12345); Bdisp_PutDisp_DD();   { int key; GetKey(&key); }
  //confirm("main","0");
  mp_stack_ctrl_init();
  main1();
}

void console_output(const char * s,int l){
  // confirm("console_output",s);
  char buf[l+1];
  strncpy(buf,s,l);
  buf[l]=0;
  dConsolePut(buf);
}

const char * console_input(const char * msg1,const char * msg2,bool numeric,int ypos){
  string str;
  if (!inputline(msg1,msg2,str,numeric,ypos))
    return 0;
  char * ptr=strdup(str.c_str());
  return ptr;
}

int do_confirm(const char * s){
  return confirm(s,(lang?"F1: oui,    F6:annuler":"F1: yes,     F6: cancel"))==KEY_CTRL_F1;
}

int kbd_filter(int key){
  if (key==KEY_CTRL_LEFT) return 0;
  if (key==KEY_CTRL_RIGHT) return 3;
  if (key==KEY_CTRL_UP) return 1;
  if (key==KEY_CTRL_DOWN) return 2;
  if (key==KEY_CTRL_EXE) return 4;
  if (key==KEY_CTRL_EXIT) return 5;
  return key;
}  

int kbd_convert(int r,int c){
  if (r==1 && c==1)
    return KEY_CTRL_AC;
  if (r==2){
    if (c==7) return KEY_CHAR_0;
    if (c==6) return KEY_CHAR_DP;
    if (c==5) return KEY_CHAR_EXPN10;
    if (c==4) return KEY_CHAR_PMINUS;
    if (c==3) return 4; // KEY_CTRL_EXE;
  }
  if (r==3){
    if (c==7) return KEY_CHAR_1;
    if (c==6) return KEY_CHAR_2;
    if (c==5) return KEY_CHAR_3;
    if (c==4) return KEY_CHAR_PLUS;
    if (c==3) return KEY_CHAR_MINUS;
  }
  if (r==4){
    if (c==7) return KEY_CHAR_4;
    if (c==6) return KEY_CHAR_5;
    if (c==5) return KEY_CHAR_6;
    if (c==4) return KEY_CHAR_MULT;
    if (c==3) return KEY_CHAR_DIV;
  }
  if (r==5){
    if (c==7) return KEY_CHAR_FRAC;
    if (c==6) return KEY_CHAR_H;
    if (c==5) return KEY_CHAR_LPAR;
    if (c==4) return KEY_CHAR_RPAR;
    if (c==3) return KEY_CHAR_COMMA;
    if (c==2) return KEY_CHAR_STORE;
  }
  if (r==6){
    if (c==7) return KEY_CTRL_XTT;
    if (c==6) return KEY_CHAR_LOG;
    if (c==5) return KEY_CHAR_LN;
    if (c==4) return KEY_CHAR_SIN;
    if (c==3) return KEY_CHAR_COS;
    if (c==2) return KEY_CHAR_TAN;
  }
  if (r==8){
    if (c==7) return KEY_CTRL_ALPHA;
    if (c==6) return KEY_CHAR_SQUARE;
    if (c==5) return KEY_CHAR_POW;
    if (c==4) return 5; // KEY_CTRL_EXIT;
    if (c==3) return 2; // KEY_CTRL_DOWN;
    if (c==2) return 3; // KEY_CTRL_RIGHT;
  }
  if (r==9){
    if (c==7) return KEY_CTRL_SHIFT;
    if (c==6) return KEY_CTRL_OPTN;
    if (c==5) return KEY_CTRL_VARS;
    if (c==4) return KEY_CTRL_MENU;
    if (c==3) return 0; // KEY_CTRL_LEFT;
    if (c==2) return 1; // KEY_CTRL_UP;
  }
  if (r==10){
    if (c==7) return KEY_CTRL_F1;
    if (c==6) return KEY_CTRL_F2;
    if (c==5) return KEY_CTRL_F3;
    if (c==4) return KEY_CTRL_F4;
    if (c==3) return KEY_CTRL_F5;
    if (c==2) return KEY_CTRL_F6;
  }
  return 0;
}

