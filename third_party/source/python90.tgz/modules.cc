#include "main.h"
#include "modules.h"
#include "console.h"
#include "textGUI.h"
#include <vector>
#include <string>
using namespace ustl;
#ifdef FXCG
int c_yshift=24;
#else
int c_yshift=24;
#endif

void c_draw_rectangle(int x,int y,int w,int h,int c){
  freeze=true;
  y += c_yshift;
  draw_line(x,y,x+w,y,c);
  draw_line(x+w,y,x+w,y+h,c);
  draw_line(x,y+h,x+w,y+h,c);
  draw_line(x,y,x,y+h,c);
}
void c_draw_line(int x0,int y0,int x1,int y1,int c){
  freeze=true;
  y0 += c_yshift;
  y1 += c_yshift;
  draw_line(x0,y0,x1,y1,c);
}
void c_draw_circle(int xc,int yc,int r,int color,bool q1,bool q2,bool q3,bool q4){
  freeze=true;
  yc += c_yshift;
  draw_circle(xc,yc,r,color,q1,q2,q3,q4);
}
void c_draw_filled_circle(int xc,int yc,int r,int color,bool left,bool right){
  freeze=true;
  yc += c_yshift;
  draw_filled_circle(xc,yc,r,color,left,right);
}
void c_convert(int *x,int*y,vector< vector<int> > & v){
  for (int i=0;i<v.size();++i,++x,++y){
    v[i].push_back(*x);
    v[i].push_back(*y+c_yshift);
  }
}
void c_draw_polygon(int * x,int *y ,int n,int color){
  freeze=true;
  vector< vector<int> > v(n);
  c_convert(x,y,v);
  draw_polygon(v,color);
}
void c_draw_filled_polygon(int * x,int *y, int n,int xmin,int xmax,int ymin,int ymax,int color){
  freeze=true;
  vector< vector<int> > v(n);
  c_convert(x,y,v);
  draw_filled_polygon(v,xmin,xmax,ymin,ymax,color);
}
void c_draw_arc(int xc,int yc,int rx,int ry,int color,double theta1, double theta2){
  freeze=true;
  yc += c_yshift;
  draw_arc(xc,yc,rx,ry,color,theta1,theta2);
}
void c_draw_filled_arc(int x,int y,int rx,int ry,int theta1_deg,int theta2_deg,int color,int xmin,int xmax,int ymin,int ymax,bool segment){
  freeze=true;
  y += c_yshift;
  draw_filled_arc(x,y,rx,ry,theta1_deg,theta2_deg,color,xmin,xmax,ymin,ymax,segment);
}
void c_set_pixel(int x,int y,int c){
  freeze=true;
  y += c_yshift;
  os_set_pixel(x,y,c);
}
void c_fill_rect(int x,int y,int w,int h,int c){
  y += c_yshift;
  freeze=true;
  if (w<0){
    w=-w;
    x -= w; 
  }
  if (h<0){
    h=-h;
    y -= h; 
  }
  if (x<0){ w+=x; x=0;}
  if (y<0){ h+=y; y=0;}
  drawRectangle(x,y,w,h,c);
}

int c_draw_string(int x,int y,int c,int bg,const char * s,bool fake){
  freeze=true;
#ifdef FXCG
  PrintMini(&x, &y, (unsigned char *)s, 0, 0xFFFFFFFF, 0, 0, c, bg, fake?0:1, 0);
  return x;
#else
  y += c_yshift;
  Printxy(x,y,s,c==_BLACK?0:1); // os_draw_string(x,y,c,bg,s,fake);
  return x+6*strlen(s);
#endif
}
int c_draw_string_small(int x,int y,int c,int bg,const char * s,bool fake){
  freeze=true;
#ifdef FXCG
  if (c==0xffff){
    int r=bg>>11,g=(bg>>5)&0x3f,b=bg&0x1f;
    int minic=(r<8?1:0)*4+(g<16?1:0)*2+(b<8?1:0);
    PrintMiniMini(&x,&y,s,4,minic,0);
  }
  else {
    int r=c>>11,g=(c>>5)&0x3f,b=c&0x1f;
    int minic=(r>=8?1:0)*4+(g>=16?1:0)*2+(b>=8?1:0);
    PrintMiniMini(&x,&y,s,0,minic,0);
  }
#else
  y += c_yshift;
  Printmini(x,y,s,c==_BLACK?0:1);
#endif
  return x+4*strlen(s); // os_draw_string_small(x,y,c,bg,s,fake);
}
int c_draw_string_medium(int x,int y,int c,int bg,const char * s,bool fake){
  freeze=true;
#ifdef FXCG
  PrintMini(&x, &y, (unsigned char *)s, 0, 0xFFFFFFFF, 0, 0, c, bg, fake?0:1, 0);
  return x;
#else
  y += c_yshift;
  Printxy(x,y,s,c==_BLACK?0:1);
  return x+6*strlen(s);// os_draw_string_medium(x,y,c,bg,s,fake);
#endif
}

const char * caseval(const char * s){
  return s;
}

void c_sprint_double(char * s,double d){
  sprint_double(s,d);
}

/* TURTLE */
double deg2rad_d=M_PI/180;

void turtle_freeze(){
  freezeturtle=true;
}

logo_turtle * turtleptr=0;
  
logo_turtle & turtle(){
  if (!turtleptr)
    turtleptr=new logo_turtle;
  return * turtleptr;
}

vector<logo_turtle> & turtle_stack(){
  static vector<logo_turtle> * ans = 0;
  if (!ans){
    // initialize from python app storage
    ans=new vector<logo_turtle>(1,(*turtleptr));
    
  }
  return *ans;
}

vector<string> * ecrisptr=0;
vector<string> & ecristab(){
  if (!ecrisptr)
    ecrisptr=new vector<string>;
  return * ecrisptr;
}

static void c_turtle_move(int r,int theta2){
  double theta0;
  if ((*turtleptr).direct)
    theta0=(*turtleptr).theta-90;
  else {
    theta0=(*turtleptr).theta+90;
    theta2=-theta2;
  }
  (*turtleptr).x += r*(cos(M_PI/180*(theta2+theta0))-cos(M_PI/180*theta0));
  (*turtleptr).y += r*(sin(M_PI/180*(theta2+theta0))-sin(M_PI/180*theta0));
  (*turtleptr).theta = (*turtleptr).theta+theta2 ;
  if ((*turtleptr).theta<0)
    (*turtleptr).theta += 360;
  if ((*turtleptr).theta>360)
    (*turtleptr).theta -= 360;
}

static void c_update_turtle_state(bool clrstring){
#if defined NUMWORKS && defined DEVICE
  if (!ck_turtle_size()){
    ctrl_c=true; interrupted=true;
    return;
  }
#endif
  if (clrstring)
    (*turtleptr).s=-1;
  (*turtleptr).theta = (*turtleptr).theta - floor((*turtleptr).theta/360)*360;
  if (!turtle_stack().empty()){
    logo_turtle & t=turtle_stack().back();
    if (t.equal_except_nomark(*turtleptr)){
      t.theta=turtleptr->theta;
      t.mark=turtleptr->mark;
      t.visible=turtleptr->visible;
      t.color=turtleptr->color;
    }
    else
      turtle_stack().push_back((*turtleptr));
  }
  else
    turtle_stack().push_back((*turtleptr));    
}

void c_turtle_clear(int clrpos){
  turtle_stack().clear();
  if (clrpos) (*turtleptr) = logo_turtle();
  c_update_turtle_state(true);
}

void c_turtle_forward(double d){
  (*turtleptr).x += d * cos((*turtleptr).theta*deg2rad_d);
  (*turtleptr).y += d * sin((*turtleptr).theta*deg2rad_d) ;
  (*turtleptr).radius = 0;
  c_update_turtle_state(true);
  py_ck_ctrl_c();
}

void c_turtle_left(double d){
  (*turtleptr).theta += d;
  (*turtleptr).radius = 0;
  c_update_turtle_state(true);
  py_ck_ctrl_c();
}

void c_turtle_up(int i){
  if (i)
    (*turtleptr).mark = false;
  else
    (*turtleptr).mark = true;
  c_update_turtle_state(true);
  py_ck_ctrl_c();
}

void c_turtle_goto(double x,double y){
  (*turtleptr).x=x;
  (*turtleptr).y=y;
  (*turtleptr).radius = 0;
  c_update_turtle_state(true);
  py_ck_ctrl_c();
}

void c_turtle_cap(double x){
  (*turtleptr).theta=x;
  (*turtleptr).radius = 0;
  c_update_turtle_state(true);
  py_ck_ctrl_c();
}

int c_turtle_getcap(){
  return (*turtleptr).theta;
}

int c_turtle_crayon(int i){
  if (i==-128)
    return (*turtleptr).turtle_length;
  if (i<0)
    (*turtleptr).turtle_length=-i;
  else
    (*turtleptr).color=i;
  c_update_turtle_state(true);
  py_ck_ctrl_c();
  return 0;
}

int c_find_radius(int & r,int & t1,int & t2,int &direct){
  direct=r>=0;
  if (r<0) r=-r;
  if (r>512) r=512;
  return r | (t1 << 9) | (t2 << 18 );
}

void c_turtle_rond(int r,int t1,int t2){
  int direct;
  int radius=c_find_radius(r,t1,t2,direct);
  (*turtleptr).radius=radius;
  (*turtleptr).direct=direct;
  while (t1<0)
    t1 += 360;
  while (t2<0)
    t2 += 360;
  c_turtle_move(r,t2);
  c_update_turtle_state(true);
  py_ck_ctrl_c();
}

void c_turtle_disque(int r,int t1,int t2,int centre){
  int direct,radius=c_find_radius(r,t1,t2,direct);
  if (centre){
    // saute(r); tourne_gauche(direct?90:-90)
  }
  (*turtleptr).radius=radius;
  (*turtleptr).direct=direct;
  c_turtle_move(r,t2);
  (*turtleptr).radius += 1 << 27;
  c_update_turtle_state(true);
  if (centre){
    // _tourne_droite(direct?90:-90,contextptr); _saute(-r,contextptr);
  }
  py_ck_ctrl_c();
}
int turtle_fillbegin=-1,turtle_fillcolor=_BLACK;


void c_turtle_fill(int i){
  if (i==1){
    turtle_fillbegin=turtle_stack().size();
    return;
  }
  int c=turtleptr->color;
  c_turtle_crayon(turtle_fillcolor);
  int n=turtle_stack().size()- turtle_fillbegin;
  turtle_fillbegin=-1;
  turtleptr->radius=-absint(n);
  c_update_turtle_state(true);
  if (turtle_fillcolor>=0){
    turtleptr->radius=0;
    c_turtle_crayon(c);
  }
  py_ck_ctrl_c();
}

int rgb(int r,int g,int b){
  if (r<0) r=0; if(r>255) r=255;
  if (g<0) g=0; if(g>255) g=255;
  if (b<0) b=0; if(b>255) b=255;
  return (((r*32)/256)<<11) | (((g*64)/256)<<5) | (b*32/256);

}
void c_turtle_fillcolor(double r,double g,double b,int entier){
  if (entier)
    turtle_fillcolor=rgb(int(r),int(g),int(b));
  else
    turtle_fillcolor=rgb(int(r*256),int(g*256),int(b*256));
  py_ck_ctrl_c();
}

void c_turtle_getposition(double * x,double * y){
  *x=turtleptr->x;
  *y=turtleptr->y;
}

void c_turtle_show(int visible){
  (*turtleptr).visible=visible;
  (*turtleptr).radius = 0;
  c_update_turtle_state(true);
}

void c_turtle_towards(double x,double y){
  double x0=turtleptr->x,y0=turtleptr->y;
  double t=atan2(x-x0,y-y0);
  c_turtle_cap(t*180/M_PI);
}

int c_turtle_getcolor(){
  return turtleptr->color;
}

void c_turtle_color(int c){
  turtleptr->color=c;
  (*turtleptr).radius = 0;
  c_update_turtle_state(true);  
}

void c_turtle_fillcolor1(int c){
  turtle_fillcolor=c;
}

void displaylogo(){
  Turtle t={&turtle_stack(),0,0,1,1};
  freeze=true; // avoid clearscreen
  while (1){
    int save_ymin=clip_ymin;
    clip_ymin=0;
    t.draw();
    clip_ymin=save_ymin;
    unsigned int key;
    ck_getkey((int*)&key);
    if (key==KEY_CTRL_EXIT || key==KEY_CTRL_AC || key==KEY_CTRL_MENU || key==KEY_CTRL_EXE || key==KEY_CTRL_VARS)
      break;
    if (key==KEY_CTRL_UP){ t.turtley += 10; }
    if (key==KEY_CTRL_PAGEUP) { t.turtley += 100; }
    if (key==KEY_CTRL_DOWN) { t.turtley -= 10; }
    if (key==KEY_CTRL_PAGEDOWN) { t.turtley -= 100;}
    if (key==KEY_CTRL_LEFT) { t.turtlex -= 10; }
    if (key==KEY_CTRL_RIGHT) { t.turtlex += 10; }
    if (key==KEY_CHAR_PLUS) { t.turtlezoom *= 2;}
    if (key==KEY_CHAR_MINUS){ t.turtlezoom /= 2;  }
  }
  freeze=false; 
}

void fl_arc(int x,int y,int rx,int ry,int theta1_deg,int theta2_deg,int c=_BLACK){
  rx/=2;
  ry/=2;
  // *logptr(contextptr) << "theta " << theta1_deg << " " << theta2_deg << endl;
  if (ry==rx){
    if (theta2_deg-theta1_deg==360){
      draw_circle(x+rx,y+rx,rx,c);
      return;
    }
    if (theta1_deg==0 && theta2_deg==180){
      draw_circle(x+rx,y+rx,rx,c,true,true,false,false);
      return;
    }
    if (theta1_deg==180 && theta2_deg==360){
      draw_circle(x+rx,y+rx,rx,c,false,false,true,true);
      return;
    }
  }
  // *logptr(contextptr) << "draw_arc" << theta1_deg*M_PI/180. << " " << theta2_deg*M_PI/180. << endl;
  draw_arc(x+rx,y+ry,rx,ry,c,theta1_deg*M_PI/180.,theta2_deg*M_PI/180.);
}

void fl_pie(int x,int y,int rx,int ry,int theta1_deg,int theta2_deg,int c=_BLACK,bool segment=false){
  //cout << "fl_pie " << theta1_deg << " " << theta2_deg << " " << c << endl;
  if (!segment && ry==rx){
    if (theta2_deg-theta1_deg>=360){
      rx/=2;
      draw_filled_circle(x+rx,y+rx,rx,c);
      return;
    }
    if (theta1_deg==-90 && theta2_deg==90){
      rx/=2;
      draw_filled_circle(x+rx,y+rx,rx,c,false,true);
      return;
    }
    if (theta1_deg==90 && theta2_deg==270){
      rx/=2;
      draw_filled_circle(x+rx,y+rx,rx,c,true,false);
      return;
    }
  }
  // approximation by a filled polygon
  // points: (x,y), (x+rx*cos(theta)/2,y+ry*sin(theta)/2) theta=theta1..theta2
  while (theta2_deg<theta1_deg)
    theta2_deg+=360;
  if (theta2_deg-theta1_deg>=360){
    theta1_deg=0;
    theta2_deg=360;
  }
  int N0=theta2_deg-theta1_deg+1;
  // reduce N if rx or ry is small
  double red=double(rx)/LCD_WIDTH_PX*double(ry)/LCD_HEIGHT_PX;
  if (red>1) red=1;
  if (red<0.1) red=0.1;
  int N=red*N0;
  if (N<5)
    N=N0>5?5:N0;
  if (N<2)
    N=2;
  vector< vector<int> > v(segment?N+1:N+2,vector<int>(2));
  x += rx/2;
  y += ry/2;
  int i=0;
  if (!segment){
    v[0][0]=x;
    v[0][1]=y;
    ++i;
  }
  double theta=theta1_deg*M_PI/180;
  double thetastep=(theta2_deg-theta1_deg)*M_PI/(180*(N-1));
  for (;i<v.size()-1;++i){
    v[i][0]=int(x+rx*cos(theta)/2+.5);
    v[i][1]=int(y-ry*sin(theta)/2+.5); // y is inverted
    theta += thetastep;
  }
  v.back()=v.front();
  draw_filled_polygon(v,0,LCD_WIDTH_PX,0,LCD_HEIGHT_PX,c);
}

unsigned short motif[8]={0xffff,0xfff0,0xff00,0xf0f0,0xe38e,0xcccc,0xaaaa,0xfc0a};
inline void fl_line(int x0,int y0,int x1,int y1,int c){
  draw_line(x0,y0,x1,y1,c,motif[c%8]);
}

inline void fl_polygon(int x0,int y0,int x1,int y1,int x2,int y2,int c){
  draw_line(x0,y0,x1,y1,c);
  draw_line(x1,y1,x2,y2,c);
}

#ifdef FX
void text_print(int fontsize,const char * s,int x,int y,int c=_BLACK,int bg=_WHITE,int mode=0){
  // *logptr(contextptr) << x << " " << y << " " << fontsize << " " << s << endl; return;
  c=(unsigned short) c;
  if (x>LCD_WIDTH_PX) return;
  int ss=strlen(s);
  if (ss==1 && s[0]==0x1e){ // arrow for limit
    if (mode)
      c=bg;
    draw_line(x,y-4,x+fontsize/2,y-4,c);
    draw_line(x,y-3,x+fontsize/2,y-3,c);
    draw_line(x+fontsize/2-4,y,x+fontsize/2,y-4,c);
    draw_line(x+fontsize/2-3,y,x+fontsize/2+1,y-4,c);
    draw_line(x+fontsize/2-4,y-7,x+fontsize/2,y-3,c);   
    draw_line(x+fontsize/2-3,y-7,x+fontsize/2+1,y-3,c);   
    return;
  }
  if (ss==2 && strcmp(s,"pi")==0){
    if (mode){
      drawRectangle(x,y-fontsize,fontsize,fontsize,c);
      c=bg;
    }
    draw_line(x+fontsize/3-1,y-2,x+fontsize/3,y+2-fontsize,c);
    //draw_line(x+fontsize/3-2,y-2,x+fontsize/3-1,y+2-fontsize,c);
    //draw_line(x+2*fontsize/3,y-2,x+2*fontsize/3,y+2-fontsize,c);
    draw_line(x+2*fontsize/3+1,y-2,x+2*fontsize/3+1,y+2-fontsize,c);
    //draw_line(x+1,y+2-fontsize,x+fontsize,y+2-fontsize,c);
    draw_line(x+1,y+1-fontsize,x+fontsize,y+1-fontsize,c);
    return;
  }
  if (fontsize>=6 && ss==2 && s[0]==char(0xe5) && (s[1]==char(0xea) || s[1]==char(0xeb))) // special handling for increasing and decreasing in tabvar output
    fontsize=8;
  if (fontsize>=8){
    while (*s && x<0){
      x+=6; ++s; --ss;
    }
    if (x+ss*6>LCD_WIDTH_PX){
      // clip string to print: ss=(LCD_WIDTH_PX-x)/4
      char buf[ss+1];
      strcpy(buf,s);
      buf[(LCD_WIDTH_PX-x)/6]=0;
      Printxy(x,y-fontsize, buf, mode?MINI_REV:0);      
    } else
      Printxy(x,y-fontsize,s,mode?1:0);
    return;
  }
  while (*s && x<0){
    x+=4; ++s; --ss;
  }
  if (x+ss*4>LCD_WIDTH_PX){
    // clip string to print: ss=(LCD_WIDTH_PX-x)/4
    char buf[ss+1];
    strcpy(buf,s);
    buf[(LCD_WIDTH_PX-x)/4]=0;
    Printmini( x, y-fontsize, buf, mode?MINI_REV:0);      
  } else
    Printmini( x, y-fontsize, s, mode?MINI_REV:0);
}

void Turtle::draw(){
  vector<logo_turtle> * turtleptr=(vector<logo_turtle> *) turtleptr_;
  const int deltax=0,deltay=0;
  drawRectangle(deltax, deltay, LCD_WIDTH_PX, LCD_HEIGHT_PX,_WHITE);
  if (turtleptr &&
#ifdef TURTLETAB
      turtle_stack_size
#else
      !turtleptr->empty()
#endif
      ){
    if (turtlezoom>8)
      turtlezoom=8;
    if (turtlezoom<0.125)
      turtlezoom=0.125;
    // check that position is not out of screen
#ifdef TURTLETAB
    logo_turtle t=turtleptr[turtle_stack_size-1];
#else
    logo_turtle t=turtleptr->back();
#endif
    double x=turtlezoom*(t.x-turtlex);
    if (x<0)
      turtlex += int(x/turtlezoom);
    if (x>=LCD_WIDTH_PX-10)
      turtlex += int((x-LCD_WIDTH_PX+10)/turtlezoom);
    double y=turtlezoom*(t.y-turtley);
    if (y<0)
      turtley += int(y/turtlezoom);
    if (y>LCD_HEIGHT_PX-10)
      turtley += int((y-LCD_HEIGHT_PX+10)/turtlezoom);
  }
  // Show turtle position/cap
  if (turtleptr &&
#ifdef TURTLETAB
      turtle_stack_size &&
#else
      !turtleptr->empty() &&
#endif
      !(maillage & 0x4)){
#ifdef TURTLETAB
    logo_turtle turtle=turtleptr[turtle_stack_size-1];
#else
    logo_turtle turtle=turtleptr->back();
#endif
    //drawRectangle(deltax+horizontal_pixels,deltay,LCD_WIDTH_PX-horizontal_pixels,2*COORD_SIZE,COLOR_YELLOW);
    // drawRectangle(deltax, deltay, LCD_WIDTH_PX, LCD_HEIGHT_PX,_BLACK);
    string tmp("x ");
    tmp += printint(int(turtle.x+.5));
    Printmini(64,0,tmp.c_str(),_BLACK);
    tmp=string("y ");
    tmp += printint(int(turtle.y+.5));
    Printmini(85,0,tmp.c_str(),_BLACK);
    tmp=string("t ");
    tmp += printint(int(turtle.theta+.5));
    Printmini(106,0,tmp.c_str(),_BLACK);
  }
  // draw turtle Logo
  if (turtleptr){
#ifdef TURTLETAB
    int l=turtle_stack_size;
#else
    int l=turtleptr->size();
#endif
    if (l>0){
#ifdef TURTLETAB
      logo_turtle prec =turtleptr[0];
#else
      logo_turtle prec =(*turtleptr)[0];
#endif
      for (int k=1;k<l;++k){
#ifdef TURTLETAB
	logo_turtle current =(turtleptr)[k];
#else
	logo_turtle current =(*turtleptr)[k];
#endif
	if (current.s>=0){ // Write a string
	  //cout << current.radius << " " << current.s << endl;
	  if (current.s<ecristab().size())
	    text_print(current.radius,ecristab()[current.s].c_str(),int(deltax+turtlezoom*(current.x-turtlex)),int(deltay+LCD_HEIGHT_PX-turtlezoom*(current.y-turtley)),current.color);
	}
	else {
	  if (current.radius>0){
	    int r=current.radius & 0x1ff; // bit 0-8
	    double theta1,theta2;
	    if (current.direct){
	      theta1=prec.theta+double((current.radius >> 9) & 0x1ff); // bit 9-17
	      theta2=prec.theta+double((current.radius >> 18) & 0x1ff); // bit 18-26
	    }
	    else {
	      theta1=prec.theta-double((current.radius >> 9) & 0x1ff); // bit 9-17
	      theta2=prec.theta-double((current.radius >> 18) & 0x1ff); // bit 18-26
	    }
	    bool rempli=(current.radius >> 27) & 0x1;
	    bool seg=(current.radius >> 28) & 0x1;
	    double angle;
	    int x,y,R;
	    R=int(2*turtlezoom*r+.5);
	    angle = M_PI/180*(theta2-90);
	    if (current.direct){
	      x=int(turtlezoom*(current.x-turtlex-r*cos(angle) - r)+.5);
	      y=int(turtlezoom*(current.y-turtley-r*sin(angle) + r)+.5);
	    }
	    else {
	      x=int(turtlezoom*(current.x-turtlex+r*cos(angle) -r)+.5);
	      y=int(turtlezoom*(current.y-turtley+r*sin(angle) +r)+.5);
	    }
	    if (current.direct){
	      if (rempli)
		fl_pie(deltax+x,deltay+LCD_HEIGHT_PX-y,R,R,theta1-90,theta2-90,current.color,seg);
	      else
		fl_arc(deltax+x,deltay+LCD_HEIGHT_PX-y,R,R,theta1-90,theta2-90,current.color);
	    }
	    else {
	      if (rempli)
		fl_pie(deltax+x,deltay+LCD_HEIGHT_PX-y,R,R,90+theta2,90+theta1,current.color,seg);
	      else
		fl_arc(deltax+x,deltay+LCD_HEIGHT_PX-y,R,R,90+theta2,90+theta1,current.color);
	    }
	  } // end radius>0
	  else {
	    if (prec.mark){
	      fl_line(deltax+int(turtlezoom*(prec.x-turtlex)+.5),deltay+int(LCD_HEIGHT_PX+turtlezoom*(turtley-prec.y)+.5),deltax+int(turtlezoom*(current.x-turtlex)+.5),deltay+int(LCD_HEIGHT_PX+turtlezoom*(turtley-current.y)+.5),prec.color);
	    }
	  }
	  if (current.radius<-1 && k+current.radius>=0){
	    // poly-line from (*turtleptr)[k+current.radius] to (*turtleptr)[k]
	    vector< vector<int> > vi(1-current.radius,vector<int>(2));
	    for (int i=0;i>=current.radius;--i){
#ifdef TURTLETAB
	      logo_turtle & t=(turtleptr)[k+i];
#else
	      logo_turtle & t=(*turtleptr)[k+i];
#endif
	      vi[-i][0]=deltax+turtlezoom*(t.x-turtlex);
	      vi[-i][1]=deltay+LCD_HEIGHT_PX+turtlezoom*(turtley-t.y);
	      //*logptr(contextptr) << i << " " << vi[-i][0] << " " << vi[-i][1] << endl;
	    }
	    //vi.back()=vi.front();
	    draw_filled_polygon(vi,0,LCD_WIDTH_PX,0,LCD_HEIGHT_PX,current.color);
	  }
	} // end else (non-string turtle record)
	prec=current;
      } // end for (all turtle records)
#ifdef TURTLETAB
      logo_turtle & t = (turtleptr)[l-1];
#else
      logo_turtle & t = (*turtleptr)[l-1];
#endif
      int x=int(turtlezoom*(t.x-turtlex)+.5);
      int y=int(turtlezoom*(t.y-turtley)+.5);
      double cost=cos(t.theta*deg2rad_d);
      double sint=sin(t.theta*deg2rad_d);
      int Dx=int(turtlezoom*t.turtle_length*cost/2+.5);
      int Dy=int(turtlezoom*t.turtle_length*sint/2+.5);
      if (t.visible){
	fl_line(deltax+x+Dy,deltay+LCD_HEIGHT_PX-(y-Dx),deltax+x-Dy,deltay+LCD_HEIGHT_PX-(y+Dx),t.color);
	int c=t.color;
	if (!t.mark) c=t.color ^ 0x7777;
	fl_line(deltax+x+Dy,deltay+LCD_HEIGHT_PX-(y-Dx),deltax+x+3*Dx,deltay+LCD_HEIGHT_PX-(y+3*Dy),0); // always display turtle
	fl_line(deltax+x-Dy,deltay+LCD_HEIGHT_PX-(y+Dx),deltax+x+3*Dx,deltay+LCD_HEIGHT_PX-(y+3*Dy),0);
      }
    }
    return;
  } // End logo mode
}
#else
  void text_print(int fontsize,const char * s,int x,int y,int c=COLOR_BLACK,int bg=COLOR_WHITE,int mode=0){
    // *logptr(contextptr) << x << " " << y << " " << fontsize << " " << s << endl; return;
    c=(unsigned short) c;
    if (x>LCD_WIDTH_PX) return;
    int ss=strlen(s);
    if (ss==1 && s[0]==0x1e){ // arrow for limit
      if (mode==4)
	c=bg;
      draw_line(x,y-4,x+fontsize/2,y-4,c);
      draw_line(x,y-3,x+fontsize/2,y-3,c);
      draw_line(x+fontsize/2-4,y,x+fontsize/2,y-4,c);
      draw_line(x+fontsize/2-3,y,x+fontsize/2+1,y-4,c);
      draw_line(x+fontsize/2-4,y-7,x+fontsize/2,y-3,c);   
      draw_line(x+fontsize/2-3,y-7,x+fontsize/2+1,y-3,c);   
      return;
    }
    if (ss==2 && strcmp(s,"pi")==0){
      if (mode==4){
	drawRectangle(x,y+2-fontsize,fontsize,fontsize,c);
	c=bg;
      }
      draw_line(x+fontsize/3-1,y+1,x+fontsize/3,y+6-fontsize,c);
      draw_line(x+fontsize/3-2,y+1,x+fontsize/3-1,y+6-fontsize,c);
      draw_line(x+2*fontsize/3,y+1,x+2*fontsize/3,y+6-fontsize,c);
      draw_line(x+2*fontsize/3+1,y+1,x+2*fontsize/3+1,y+6-fontsize,c);
      draw_line(x+2,y+6-fontsize,x+fontsize,y+6-fontsize,c);
      draw_line(x+2,y+5-fontsize,x+fontsize,y+5-fontsize,c);
      return;
    }
    if (fontsize>=16 && ss==2 && s[0]==char(0xe5) && (s[1]==char(0xea) || s[1]==char(0xeb))) // special handling for increasing and decreasing in tabvar output
      fontsize=18;
    if (fontsize>=18){
      y -= 40;//36; // status area shift
      PrintMini(&x,&y,(unsigned char *)s,mode,0xffffffff,0,0,c,bg,1,0);
      return;
    }
    if (fontsize<16){
      y -= 36;//32;
      PrintMiniMini( &x, &y, (unsigned char *)s, mode,c, 0 );
      return;
    }
    y -= 38;//34;
    //PrintCXY(x,y,s,TEXT_MODE_NORMAL,-1,COLOR_BLACK,COLOR_WHITE,1,0);
    Bdisp_MMPrint(x,y,s,mode,0xffffffff,0,0,c,bg,1,0);
  }

void Turtle::draw(){
  vector<logo_turtle> * turtleptr=(vector<logo_turtle> *) turtleptr_;
  int fl_line_width=1,save_width=fl_line_width;
  const int deltax=0,deltay=24,COORD_SIZE=30;
  int horizontal_pixels=LCD_WIDTH_PX-2*COORD_SIZE;
  // Check for fast redraw
  // Then redraw the background
  drawRectangle(deltax, deltay, LCD_WIDTH_PX, LCD_HEIGHT_PX-24,COLOR_WHITE);
#ifdef TURTLETAB
  if (turtleptr && turtle_stack_size==0){
    turtleptr[0]=logo_turtle();
    ++turtle_stack_size;
  }
#endif
  if (turtleptr &&
#ifdef TURTLETAB
      turtle_stack_size
#else
      !turtleptr->empty()
#endif
      ){
    if (turtlezoom>8)
      turtlezoom=8;
    if (turtlezoom<0.125)
      turtlezoom=0.125;
    // check that position is not out of screen
#ifdef TURTLETAB
    logo_turtle t=turtleptr[turtle_stack_size-1];
#else
    logo_turtle t=turtleptr->back();
#endif
    double x=turtlezoom*(t.x-turtlex);
    double y=turtlezoom*(t.y-turtley);
#if 0
    if (x<0)
      turtlex += int(x/turtlezoom);
    if (x>=LCD_WIDTH_PX-10)
      turtlex += int((x-LCD_WIDTH_PX+10)/turtlezoom);
    if (y<0)
      turtley += int(y/turtlezoom);
    if (y>LCD_HEIGHT_PX-10)
      turtley += int((y-LCD_HEIGHT_PX+10)/turtlezoom);
#endif
  }
#if 0
  if (maillage & 0x3){
    fl_color(FL_BLACK);
    double xdecal=floor(turtlex/10.0)*10;
    double ydecal=floor(turtley/10.0)*10;
    if ( (maillage & 0x3)==1){
      for (double i=xdecal;i<LCD_WIDTH_PX+xdecal;i+=10){
	for (double j=ydecal;j<LCD_HEIGHT_PX+ydecal;j+=10){
	  fl_point(deltax+int((i-turtlex)*turtlezoom+.5),deltay+LCD_HEIGHT_PX-int((j-turtley)*turtlezoom+.5));
	}
      }
    }
    else {
      double dj=sqrt(3.0)*10,i0=xdecal;
      for (double j=ydecal;j<LCD_HEIGHT_PX+ydecal;j+=dj){
	int J=deltay+int(LCD_HEIGHT_PX-(j-turtley)*turtlezoom);
	for (double i=i0;i<LCD_WIDTH_PX+xdecal;i+=10){
	  fl_point(deltax+int((i-turtlex)*turtlezoom+.5),J);
	}
	i0 += dj;
	while (i0>=10)
	  i0 -= 10;
      }
    }
  }
#endif
  // Show turtle position/cap
  if (turtleptr &&
#ifdef TURTLETAB
      turtle_stack_size &&
#else
      !turtleptr->empty() &&
#endif
      !(maillage & 0x4)
      ){
#ifdef TURTLETAB
    logo_turtle turtle=turtleptr[turtle_stack_size-1];
#else
    logo_turtle turtle=turtleptr->back();
#endif
    drawRectangle(deltax+horizontal_pixels,deltay,LCD_WIDTH_PX-horizontal_pixels,2*COORD_SIZE,COLOR_YELLOW);
    // drawRectangle(deltax, deltay, LCD_WIDTH_PX, LCD_HEIGHT_PX,COLOR_BLACK);
    char buf[32];
    sprintf(buf,"x %i   ",int(turtle.x+.5));
    text_print(18,buf,deltax+horizontal_pixels,deltay+(2*COORD_SIZE)/3-2,COLOR_BLACK,COLOR_YELLOW);
    sprintf(buf,"y %i   ",int(turtle.y+.5));
    text_print(18,buf,deltax+horizontal_pixels,deltay+(4*COORD_SIZE)/3-3,COLOR_BLACK,COLOR_YELLOW);
    sprintf(buf,"t %i   ",int(turtle.theta+.5));
    text_print(18,buf,deltax+horizontal_pixels,deltay+2*COORD_SIZE-4,COLOR_BLACK,COLOR_YELLOW);
  }
  // draw turtle Logo
  if (turtleptr){
#ifdef TURTLETAB
    int l=turtle_stack_size;
#else
    int l=turtleptr->size();
#endif
    if (l>0){
#ifdef TURTLETAB
      logo_turtle prec =turtleptr[0];
#else
      logo_turtle prec =(*turtleptr)[0];
#endif
      //cout << "turtle length=" << l << '\n';
      for (int k=1;k<l;++k){
#ifdef TURTLETAB
	logo_turtle current =(turtleptr)[k];
#else
	logo_turtle current =(*turtleptr)[k];
#endif
	if (current.s>=0){ // Write a string
	  //cout << current.radius << " " << current.s << endl;
	  if (current.s<ecristab().size())
	    text_print(current.radius,ecristab()[current.s].c_str(),int(deltax+turtlezoom*(current.x-turtlex)),int(deltay+LCD_HEIGHT_PX-turtlezoom*(current.y-turtley)),current.color);
	}
	else {
	  // cout <<"k=" << k << "r=" << current.radius << '\n';
	  //fl_line_width=width;
	  int width=current.turtle_length & 0x1f;
	  if (current.radius>0){
	    int r=current.radius & 0x1ff; // bit 0-8
	    double theta1,theta2;
	    if (current.direct){
	      theta1=prec.theta+double((current.radius >> 9) & 0x1ff); // bit 9-17
	      theta2=prec.theta+double((current.radius >> 18) & 0x1ff); // bit 18-26
	    }
	    else {
	      theta1=prec.theta-double((current.radius >> 9) & 0x1ff); // bit 9-17
	      theta2=prec.theta-double((current.radius >> 18) & 0x1ff); // bit 18-26
	    }
	    bool rempli=(current.radius >> 27) & 0x1;
	    bool seg=(current.radius >> 28) & 0x1;
	    double angle;
	    int x,y,R;
	    R=int(2*turtlezoom*r+.5);
	    angle = M_PI/180*(theta2-90);
	    if (current.direct){
	      x=int(turtlezoom*(current.x-turtlex-r*cos(angle) - r)+.5);
	      y=int(turtlezoom*(current.y-turtley-r*sin(angle) + r)+.5);
	    }
	    else {
	      x=int(turtlezoom*(current.x-turtlex+r*cos(angle) -r)+.5);
	      y=int(turtlezoom*(current.y-turtley+r*sin(angle) +r)+.5);
	    }
	    if (current.direct){
	      if (rempli)
		fl_pie(deltax+x,deltay+LCD_HEIGHT_PX-y,R,R,theta1-90,theta2-90,current.color,seg);
	      else
		fl_arc(deltax+x,deltay+LCD_HEIGHT_PX-y,R,R,theta1-90,theta2-90,current.color);
	    }
	    else {
	      if (rempli)
		fl_pie(deltax+x,deltay+LCD_HEIGHT_PX-y,R,R,90+theta2,90+theta1,current.color,seg);
	      else
		fl_arc(deltax+x,deltay+LCD_HEIGHT_PX-y,R,R,90+theta2,90+theta1,current.color);
	    }
	  } // end radius>0
	  else {
	    if (prec.mark){
	      fl_line(deltax+int(turtlezoom*(prec.x-turtlex)+.5),deltay+int(LCD_HEIGHT_PX+turtlezoom*(turtley-prec.y)+.5),deltax+int(turtlezoom*(current.x-turtlex)+.5),deltay+int(LCD_HEIGHT_PX+turtlezoom*(turtley-current.y)+.5),prec.color);
	    }
	  }
	  if (current.radius<-1 && k+current.radius>=0){
	    // poly-line from (*turtleptr)[k+current.radius] to (*turtleptr)[k]
	    vector< vector<int> > vi(1-current.radius,vector<int>(2));
	    for (int i=0;i>=current.radius;--i){
#ifdef TURTLETAB
	      logo_turtle & t=(turtleptr)[k+i];
#else
	      logo_turtle & t=(*turtleptr)[k+i];
#endif
	      //cout << i << " " << t.radius << " " << t.color << " " << current.color << '\n';
	      if (t.radius>0){
		int r=t.radius & 0x1ff; // bit 0-8
		int x,y,R;
		R=int(2*turtlezoom*r+.5);
		double angle = M_PI/180*(current.theta-90);
		if (t.direct){
		  x=int(turtlezoom*(t.x-turtlex-r*cos(angle) - r)+.5);
		  y=int(turtlezoom*(t.y-turtley-r*sin(angle) + r)+.5);
		}
		else {
		  x=int(turtlezoom*(t.x-turtlex+r*cos(angle) -r)+.5);
		  y=int(turtlezoom*(t.y-turtley+r*sin(angle) +r)+.5);
		}
		fl_pie(deltax+x,deltay+LCD_HEIGHT_PX-y,R,R,0,360,current.color,false);
	      }
	      vi[-i][0]=deltax+turtlezoom*(t.x-turtlex);
	      vi[-i][1]=deltay+LCD_HEIGHT_PX+turtlezoom*(turtley-t.y);
	      //*logptr(contextptr) << i << " " << vi[-i][0] << " " << vi[-i][1] << endl;
	    }
	    //vi.back()=vi.front();
	    draw_filled_polygon(vi,0,LCD_WIDTH_PX,24,LCD_HEIGHT_PX,current.color);
	  }
	} // end else (non-string turtle record)
	prec=current;
      } // end for (all turtle records)
#ifdef TURTLETAB
      logo_turtle & t = (turtleptr)[l-1];
#else
      logo_turtle & t = (*turtleptr)[l-1];
#endif
      int x=int(turtlezoom*(t.x-turtlex)+.5);
      int y=int(turtlezoom*(t.y-turtley)+.5);
      double cost=cos(t.theta*deg2rad_d);
      double sint=sin(t.theta*deg2rad_d);
      int tl=t.turtle_length+10;
      int Dx=int(turtlezoom*tl*cost/2+.5);
      int Dy=int(turtlezoom*tl*sint/2+.5);
      if (t.visible){
	fl_line(deltax+x+Dy,deltay+LCD_HEIGHT_PX-(y-Dx),deltax+x-Dy,deltay+LCD_HEIGHT_PX-(y+Dx),t.color);
	int c=t.color;
	if (!t.mark)
	  c=t.color ^ 0x7777;
	fl_line(deltax+x+Dy,deltay+LCD_HEIGHT_PX-(y-Dx),deltax+x+3*Dx,deltay+LCD_HEIGHT_PX-(y+3*Dy),c);
	fl_line(deltax+x-Dy,deltay+LCD_HEIGHT_PX-(y+Dx),deltax+x+3*Dx,deltay+LCD_HEIGHT_PX-(y+3*Dy),c);
      }
    }
    fl_line_width=save_width;
    return;
  } // End logo mode
}  
#endif

c_complex operator +(const c_complex & a,const c_complex & b){
  c_complex c={a.r+b.r,a.i+b.i};
  return c;
}

c_complex c_complex::operator +=(const c_complex & b){
  r += b.r;
  i += b.i;
  return *this;
}

c_complex c_complex::operator -=(const c_complex & b){
  r -= b.r;
  i -= b.i;
  return *this;
}

c_complex operator -(const c_complex & a,const c_complex & b){
  c_complex c={a.r-b.r,a.i-b.i};
  return c;
}

c_complex operator -(const c_complex & a,double b){
  c_complex c={a.r-b,a.i};
  return c;
}

c_complex operator -(const c_complex & a){
  c_complex c={-a.r,-a.i};
  return c;
}

c_complex operator /(const c_complex & a,double d){
  c_complex c={a.r/d,a.i/d};
  return c;
}

c_complex operator *(const c_complex & a,double d){
  c_complex c={a.r*d,a.i*d};
  return c;
}

c_complex operator *(double d,const c_complex & a){
  c_complex c={a.r*d,a.i*d};
  return c;
}

c_complex operator *(const c_complex & a,const c_complex & b){
  c_complex c={a.r*b.r-a.i*b.i,a.r*b.i+a.i*b.r};
  return c;
}

// x alloc size is n+1
bool c_pcoeff(c_complex * x,int n){
  c_complex tab[n+1];
  tab[0].r=1; tab[0].i=0; // init tab to polynomial 1
  for (int i=0;i<n;++i){
    // tab:=tab*(X-x[i]): leading coeff unchanged
    tab[i+1].r=tab[i+1].i=0;
    c_complex & xi=x[i];
    for (int j=i;j>=0;--j){
      tab[j+1] -= tab[j]*xi;
    }
  }
  // copy result in x
  for (int i=0;i<=n;++i)
    x[i]=tab[i];
  return true;
}

static void fft2( c_complex *A, int n, c_complex *W, c_complex *T ) {  
  if ( n==1 ) return;
  // if p is fixed, the code is about 2* faster
  if (n==4){
    c_complex w1=W[1];
    c_complex f0=A[0],f1=A[1],f2=A[2],f3=A[3],f01=(f1-f3)*w1;
    A[0]=(f0+f1+f2+f3);
    A[1]=(f0-f2+f01);
    A[2]=(f0-f1+f2-f3);
    A[3]=(f0-f2-f01);
    return;
  }
  if (n==2){
    c_complex f0=A[0],f1=A[1];
    A[0]=(f0+f1);
    A[1]=(f0-f1);
    return;
  }
  int i,n2;
  n2 = n/2;
  // Step 1 : arithmetic
  c_complex * Tn2=T+n2,*An2=A+n2;
  for( i=0; i<n2; ++i ) {
    c_complex Ai,An2i;
    Ai=A[i];
    An2i=An2[i];
    T[i] = Ai+An2i; // addmod(Ai,An2i,p);
    Tn2[i] = (Ai-An2i)*W[i]; // submod(Ai,An2i,p); mulmod(t,W[i],p); 
    i++;
    Ai=A[i];
    An2i=An2[i];
    T[i] = Ai+An2i; // addmod(Ai,An2i,p);
    Tn2[i] = (Ai-An2i)*W[i]; // submod(Ai,An2i,p); mulmod(t,W[i],p); 
  }
  // Step 2 : recursive calls
  fft2( T,    n2, W+n2, A    );
  fft2( Tn2, n2, W+n2, A+n2 );
  // Step 3 : permute
  for( i=0; i<n2; ++i ) {
    A[  2*i] = T[i];
    A[2*i+1] = Tn2[i]; 
    ++i;
    A[  2*i] = T[i];
    A[2*i+1] = Tn2[i]; 
  }
  return;
}  

void fft2( c_complex * A, int n, double theta){
  vector< c_complex > W,T(n);
  W.reserve(n); 
  double thetak(theta);
  for (int N=n/2;N;N/=2,thetak*=2){
    c_complex ww={1,0};
    c_complex wk={cos(thetak),sin(thetak)};
    for (int i=0;i<N;ww=ww*wk,++i){
      if (i%64==0){
	ww.r=cos(i*thetak);
	ww.i=sin(i*thetak);
      }
      W.push_back(ww);
    }
  }
  fft2(A,n,&W.front(),&T.front());
}

bool c_fft(c_complex * x,int n,bool inverse){
  c_complex * X=(c_complex *) x;
  double theta=2*M_PI/n;
  if (!inverse)
    theta=-theta;
  fft2(X,n,theta);
  if (inverse){
    for (int i=0;i<n;++i)
      X[i]=X[i]/double(n);
  }
  return true;
}
//inline double absdouble(double x){ return x<0?-x:x;}
double abs(const c_complex & c){
  double X=fabs(c.r),Y=fabs(c.i);
  if (X==0 && Y==0) return 0;
  if (X<Y){
    X/=Y;
    return Y*sqrt(1+X*X);
  }
  Y/=X;
  return X*sqrt(1+Y*Y);
}

double norm(const c_complex & c){
  return c.r*c.r+c.i*c.i;
}

c_complex inv(const c_complex & a){
  double n=abs(a);
  c_complex c={a.r/n/n,-a.i/n/n};
  return c;
}

bool is_zero(const c_complex & a){
  return a.r==0 && a.i==0;
}

bool operator ==(const c_complex & a,const c_complex &b){
  return a.r==b.r && a.i==b.i;
}

bool operator !=(const c_complex & a,const c_complex &b){
  return a.r!=b.r || a.i!=b.i;
}

typedef vector< vector< c_complex> > cmatrice;
typedef vector< c_complex> cvecteur;

c_complex cdot(const cvecteur & v,const cvecteur & w){
  int n=v.size(),m=w.size();
  if (n>m) n=m;
  c_complex r={0,0};
  for (int i=0;i<n;++i)
    r += v[i]*w[i];
  return r;
}

bool cmult(const cmatrice & A,const cmatrice & B,cmatrice &C){
  int An=A.size(),Bn=B.size();
  if (!An || !Bn) return false;
  int Ac=A[0].size(),Bc=B[0].size();
  for (int i=0;i<An;++i){
    if (B[i].size()!=Bc)
      return false;
  }
  C.resize(An);
  for (int i=0;i<An;++i){
    const cvecteur & Ai=A[i];
    if (Ai.size()!=Ac)
      return false;
    cvecteur & Ci=C[i];
    Ci.resize(Bc);
    for (int j=0;j<Bc;++j){
      c_complex r={0,0};
      for (int k=0;k<Ac;++k){
	r += Ai[k]*B[k][j];
      }
      Ci[j]=r;
    }
  }
  return true;
}

// v1=v1+c2*v2 
void linear_combination(cvecteur & v1,const c_complex & c2,const cvecteur & v2,int cstart,int cend){
  if (!is_zero(c2)){
    cvecteur::iterator it1=v1.begin()+cstart,it1end=v1.end();
    if (cend && cend>=cstart && cend<it1end-v1.begin())
      it1end=v1.begin()+cend;
    cvecteur::const_iterator it2=v2.begin()+cstart;
    for (;it1!=it1end;++it1,++it2)
      *it1 += c2*(*it2);
  }
}

string print(const c_complex & c){
  char buf[32];
  sprint_double(buf,c.r);
  if (c.i==0)
    return buf;
  string s="(";
  s+=buf;
  s+=',';
  sprint_double(buf,c.i);
  s+=buf;
  s+=')';
  return s;
}

string print(const cvecteur & v){
  string s="[";
  for (int i=0;i<v.size();++i){
    s+=print(v[i]);
    s+=',';
  }
  s+=']';
  return s;
}

string print(const cmatrice & v){
  string s="[";
  for (int i=0;i<v.size();++i){
    s+=print(v[i]);
    s+=',';
  }
  s+=']';
  return s;
}

void crref(cmatrice & N,cvecteur & pivots,vector<int> & permutation,vector<int> & maxrankcols,c_complex & idet,int l, int lmax, int c,int cmax,int fullreduction,double eps,int rref_or_det_or_lu){
  bool use_cstart=!c;
  bool inverting=fullreduction==2;
  int linit=l;//,previous_l=l;
  // Reduction
  c_complex pivot,temp;
  // cvecteur vtemp;
  int pivotline,pivotcol;
  idet.r=1; idet.i=0;
  pivots.clear();
  pivots.reserve(cmax-c);
  permutation.clear();
  maxrankcols.clear();
  for (int i=0;i<lmax;++i)
    permutation.push_back(i);
  bool noswap=true;
  double epspivot=(eps<1e-13)?1e-13:eps;
  for (;(l<lmax) && (c<cmax);){
    pivot=N[l][c];
    if (abs(pivot)<epspivot)
      N[l][c].r=N[l][c].i=pivot.r=pivot.i=0;
    if (rref_or_det_or_lu==3 && is_zero(pivot)){
      idet.r=idet.i=0;
      return;
    }
    if ( rref_or_det_or_lu==1 && l==lmax-1 ){
      idet = (idet * pivot);
      break;
    }
    pivotline=l;
    pivotcol=c;
    noswap=false;
    // scan N current column for the best pivot available
    for (int ltemp=l+1;ltemp<lmax;++ltemp){
      temp=N[ltemp][c];
      if (abs(temp)<epspivot)
	temp.r=temp.i=N[ltemp][c].r=N[ltemp][c].i=0;
      if (abs(temp)>abs(pivot)){
	pivot=temp;
	pivotline=ltemp;
      }
    }
    if (!is_zero(pivot)){
      epspivot=eps*abs(pivot);
      maxrankcols.push_back(c);
      if (l!=pivotline){
	swap(N[l],N[pivotline]);
	swap(permutation[l],permutation[pivotline]);
	pivotline=l;
	idet = -idet;
      }
      // save pivot for annulation test purposes
      if (rref_or_det_or_lu!=1)
	pivots.push_back(pivot);
      // invert pivot 
      temp=inv(pivot);
      // multiply det
      idet = idet * pivot ;
      if (fullreduction || rref_or_det_or_lu<2){ // not LU decomp
	cvecteur::iterator it=N[pivotline].begin(),itend=N[pivotline].end();
	c_complex invpivot=inv(pivot);
	for (;it!=itend;++it){
	  *it = *it*invpivot;
	}
      }
      // if there are 0 at the end, ignore them in linear combination
      int effcmax=cmax-1;
      const cvecteur & Npiv=N[pivotline];
      for (;effcmax>=c;--effcmax){
	if (!is_zero(Npiv[effcmax]))
	  break;
      }
      ++effcmax;
      if (fullreduction && inverting && noswap)
	effcmax=giacmax(effcmax,c+1+lmax);
      // make the reduction
      if (fullreduction){
	for (int ltemp=linit;ltemp<lmax;++ltemp){
	  if (ltemp==l)
	    continue;
	  linear_combination(N[ltemp],-N[ltemp][pivotcol],N[l],(use_cstart?c:cmax),effcmax);
	}
      }
      else {
	for (int ltemp=l+1;ltemp<lmax;++ltemp){
	  if (rref_or_det_or_lu>=2) // LU decomp
	    N[ltemp][pivotcol] =  N[ltemp][pivotcol]*temp;
	  linear_combination(N[ltemp],-N[ltemp][pivotcol],N[l],(rref_or_det_or_lu>0)?(c+1):(use_cstart?c:cmax),effcmax);
	}
      } // end else
      // increment column number 
      ++c;
      // increment line number since reduction has been done
      ++l;	  
    } // end if (!is_zero(pivot)
    else { // if pivot is 0 increment col
      idet.r = idet.i=0;
      if (rref_or_det_or_lu==1)
	return;
      c++;
    }
  }
}

void c_complextab2cmatrice(c_complex * x,int n,int m,cmatrice & M){
  M.resize(n);
  for (int i=0;i<n;++i){
    M[i].resize(m);
    cvecteur & v=M[i];
    for (int j=0;j<m;++j){
      v[j]=*x; ++x;
    }
  }
}

void cmatrice2c_complextab(const cmatrice &M,c_complex * x){
  int n=M.size();
  for (int i=0;i<n;++i){
    const cvecteur & v=M[i];
    int m=v.size();
    for (int j=0;j<m;++j){
      *x=v[j];
      ++x;
    }
  }
}

void c_complextab2cvecteur(c_complex * x,int n,cvecteur & v){
  v.resize(n);
  for (int j=0;j<n;++j){
    v[j]=*x; ++x;
  }
}

void cvecteur2c_complextab(const cvecteur &v,c_complex * x){
  int m=v.size();
  for (int j=0;j<m;++j){
    *x=v[j];
    ++x;
  }
}

// add identity matrix, modifies arref in place
void add_identity(cmatrice & arref){
  int s=int(arref.size());
  for (int i=0;i<s;++i){
    cvecteur &v=arref[i];
    v.reserve(2*s);
    for (int j=0;j<s;++j){
      c_complex c={i==j?1.0:0.0,0};
      v.push_back(c);
    }
  }
}

void cidn(cmatrice & m){
  int s=int(m.size());
  for (int i=0;i<s;++i){
    cvecteur &v=m[i];
    v.clear();
    for (int j=0;j<s;++j){
      c_complex c={i==j?1.0:0.0,0};
      v.push_back(c);
    }
  }
}

bool remove_identity(cmatrice & res){
  int s=int(res.size());
  // "shrink" res
  for (int i=0;i<s;++i){
    cvecteur & v = res[i];
    if (is_zero(v[i]))
      return false;
    c_complex p=inv(v[i]);
    cvecteur d(s);
    for (int j=0;j<s;++j)
      d[j]=p*v[s+j];
    res[i].swap(d);
  }
  return true;
}

cmatrice companion(const cvecteur & w){
  cvecteur v(w);
  int s=int(v.size())-1;
  if (s<=0)
    return cmatrice(0);
  c_complex v0=inv(v[0]);
  cmatrice m;
  m.reserve(s);
  for (int i=0;i<s;++i){
    c_complex zero={0,0};
    cvecteur w(s,zero);
    w[s-1]=-v0*v[s-i];
    if (i>0)
      w[i-1].r=1;
    m.push_back(w);
  }
  return m;
}

bool cinv(cmatrice &M){
  int n=M.size();
  add_identity(M);
  cvecteur pivots; vector<int> perm,maxrankcols; c_complex idet;
  crref(M,pivots,perm,maxrankcols,idet,0,n,0,2*n,2,1e-13,0);
  if (abs(idet)<1e-13)
    return false;
  remove_identity(M);
  return true;
}

c_complex sqrt(const c_complex & c){
  double r=c.r,i=c.i;
  if (c.i==0) {
    if (c.r<0){
      c_complex res={0,sqrt(-c.r)}; return res;      
    }
    c_complex res={sqrt(c.r),0}; return res;
  }
  double rho=abs(c);
  double rrho=r<0?i*i/(rho-r):(rho+r); // accuracy if r<0
  double sqrtr=sqrt(rrho/2);
  double sqrti=i*sqrtr/rrho;
  c_complex res={sqrtr,sqrti};
  return res;
}

c_complex conj(const c_complex & c){
  c_complex C={c.r,-c.i};
  return C;
}

double real(const c_complex &c){
  return c.r;
}

double imag(const c_complex &c){
  return c.i;
}

bool ctrn(const cmatrice & M){
  int n=M.size();
  if (!n) return false;
  int c=M[0].size();
  for (int i=0;i<n;++i)
    if (M[i].size()!=c)
      return false;
  cmatrice T(c);
  for (int i=0;i<c;++i){
    cvecteur &Ti=T[i];
    Ti.resize(n);
    for (int j=0;j<n;++j){
      Ti[j]=conj(M[j][i]);
    }
  }
  return true;
}

// conj(a)*A+conj(c)*C->C
// c*A-a*C->A
void bi_linear_combination( c_complex  a,vector< c_complex > & A, c_complex  c,vector< c_complex > & C,int cstart,int cend){
  c_complex  * Aptr=&A.front()+cstart;
  c_complex  * Cptr=&C.front()+cstart,* Cend=Cptr+(cend-cstart);
  c_complex ac=conj(a),cc=conj(c);
  for (;Cptr!=Cend;++Aptr,++Cptr){
    c_complex  tmp=c*(*Aptr)-a*(*Cptr);
    *Cptr=ac*(*Aptr)+cc*(*Cptr);
    *Aptr=tmp;
  }
}

void hessenberg_ortho(cmatrice & H,cmatrice & P,int firstrow,int n,bool compute_P,int already_zero){
  int nH=int(H.size());
  if (n<0 || n>nH) 
    n=nH;
  if (firstrow<0 || firstrow>n)
    firstrow=0;
  c_complex  t,u,tc,uc;
  double norme;
  for (int m=firstrow;m<n-2;++m){
    // if initial Hessenberg check for a non zero coeff in the column m below ligne m+1
    int i=m+1;
    int nend=n;
    if (already_zero){
      if (i+already_zero<n)
	nend=i+already_zero;
    }
    else {
      double pivot=0;
      int pivotline=0;
      for (;i<nend;++i){
	double t=abs(H[i][m]);
	if (t>pivot){
	  pivotline=i;
	  pivot=t;
	}
      }
      if (pivot==0)
	continue;
      i=pivotline;
      // exchange line and columns
      if (i>m+1){
	swap(H[i],H[m+1]);
	if (compute_P)
	  swap(P[i],P[m+1]);
	for (int j=0;j<n;++j){
	  vector< c_complex > & Hj=H[j];
#if 1 //def VISUALC
	  c_complex cc=Hj[i];
	  Hj[i]=Hj[m+1];
	  Hj[m+1]=cc;
#else
	  swap< c_complex >(Hj[i],Hj[m+1]);
#endif
	}
      }
    }
    // now coeff at line m+1 column m is H[m+1][m]=t!=0
    for (i=m+2;i<nend;++i){
      u=H[i][m];
      if (is_zero(u))
	continue;
      // line operation
      t=H[m+1][m];
      norme=sqrt(norm(u)+norm(t));
      u=u/norme; t=t/norme;
      uc=conj(u); tc=conj(t);
      // H[m+1]=uc*H[i]+tc*H[m+1] and H[i]=t*H[i]-u*H[m+1];
      bi_linear_combination(u,H[i],t,H[m+1],m,nH);
      // column operation:
      int nstop=already_zero?nend+already_zero-1:nH;
      if (nstop>nH)
	nstop=nH;
      cmatrice::iterator Hjptr=H.begin(),Hjend=Hjptr+nstop;
      for (;Hjptr!=Hjend;++Hjptr){
	c_complex  *Hj=&Hjptr->front();
	c_complex  Hjm=Hj[m+1],Hji=Hj[i];
	Hj[i]=-uc*Hjm+tc*Hji;
	Hj[m+1]=t*Hjm+u*Hji;
      }
      if (compute_P){
	bi_linear_combination(u,P[i],t,P[m+1],0,nH);
      }
    } // for i=m+2...
  } // for int m=firstrow ...
}

// a*A+c*C->A
// c*A-a*C->C
void bi_linear_combination(double a,vector< c_complex > & A,c_complex c,vector< c_complex > & C){
  c_complex * Aptr=&A.front();
  c_complex * Cptr=&C.front(),* Cend=Cptr+C.size();
  c_complex cc=conj(c);
  for (;Cptr!=Cend;++Aptr,++Cptr){
    c_complex tmp=a*(*Aptr)+cc*(*Cptr);
    *Cptr=c*(*Aptr)-a*(*Cptr);
    *Aptr=tmp;
  }
}

void francis_iterate1(cmatrice & H,int n1,int n2,cmatrice & P,double eps,bool compute_P,c_complex l1,bool finish){
  int n_orig=int(H.size());
  c_complex x,y,yc;
  if (finish){
    // [[a,b],[c,d]] -> [b,l1-a] or [l1-d,c] as first eigenvector
    c_complex a=H[n2-2][n2-2],b=H[n2-2][n2-1],c=H[n2-1][n2-2],d=H[n2-1][n2-1];
    c_complex l1a=l1-a,l1d=l1-d;
    if (abs(l1a)>abs(l1d)){
      x=b; y=l1a;
    }
    else {
      x=l1d; y=c;
    }
  }
  else {
    x=H[n1][n1]-l1,y=H[n1+1][n1];
    if (abs(x)<eps && abs(y-1.0)<eps){
      x.r = double(rand())/2147483647;
      x.i=0;
    }
  }
  // make x real
  double xr=real(x),xi=imag(x),yr=real(y),yi=imag(y),X;
  X = sqrt(xr*xr+xi*xi);
  if (X!=0){
    // gen xy = gen(xr/x,-xi/x); y=y*xy;
    y.r=(yr*xr+yi*xi)/X; y.i=(yi*xr-yr*xi)/X; 
    yr=real(y); yi=imag(y);
  }
  double xy=sqrt(X*X+yr*yr+yi*yi);
  // normalize eigenvector
  X = X/xy; y = y/xy;	yc=conj(y);
  // compute reflection matrix such that Q*[1,0]=[x,y]
  // hence column 1 is [x,y] and column2 is [conj(y),-x]
  // apply Q on H and P: line operations on H and P
  // c_complex c11=x, c12=conj(y,contextptr),
  //                 c21=y, c22=-x;
  // apply Q on H and P: line operations on H and P
  bi_linear_combination(X,H[n1],y,H[n1+1]);
  if (compute_P)
    bi_linear_combination(X,P[n1],y,P[n1+1]);
  // now columns operations on H (not on P)
  for (int j=0;j<n_orig;++j){
    vector< c_complex > & Hj=H[j];
    c_complex & Hjm1=Hj[n1];
    c_complex & Hjm2=Hj[n1+1];
    c_complex tmp1=Hjm1*X+Hjm2*y; // tmp1=Hjm1*c11+Hjm2*c21;
    Hjm2=Hjm1*yc-Hjm2*X; // tmp2=Hjm1*c12+Hjm2*c22;
    Hjm1=tmp1;
  }
  hessenberg_ortho(H,P,n1,n2,compute_P,2); 
}

bool in_francis_schur(cmatrice & H,int n1,int n2,cmatrice & P,int maxiter,double eps,bool compute_P,cmatrice & Haux,bool only_one);

void francis_iterate2(cmatrice & H,int n1,int n2,cmatrice & P,double eps,bool compute_P,cmatrice & Haux,bool only_one){
  // int n_orig(H.size());
  // now H is proper hessenberg (indices n1 to n2-1)
  c_complex s=H[n2-1][n2-1]; 
  double ok=abs(H[n2-1][n2-2])/abs(H[n2-1][n2-1]);
  if (n2-n1==2 ||(ok>1e-1 && n2-n1>2 && abs(H[n2-2][n2-3])<1e-2*abs(H[n2-2][n2-2]))){
    c_complex a=H[n2-2][n2-2],b=H[n2-2][n2-1],c=H[n2-1][n2-2],d=H[n2-1][n2-1];
    c_complex delta=a*a-2*a*d+d*d+4*b*c;
    delta=sqrt(delta);
    c_complex l1=(a+d+delta)/2.0;
    // c_complex l2=(a+d-delta)/2.0;
    s=l1;
  }
  francis_iterate1(H,n1,n2,P,eps,compute_P,s,false);
}

// EIGENVALUES 
bool eigenval2(cmatrice & H,int n2,c_complex & l1, c_complex & l2){
  c_complex a=H[n2-2][n2-2],b=H[n2-2][n2-1],c=H[n2-1][n2-2],d=H[n2-1][n2-1];
  c_complex delta=a*a-2*a*d+d*d+4*b*c;
  delta=sqrt(delta);
  l1=(a+d+delta)/2; 
  l2=(a+d-delta)/2; 
  return true;
}

bool in_francis_schur(cmatrice & H,int n1,int n2,cmatrice & P,int maxiter,double eps,bool compute_P,cmatrice & Haux,bool only_one){
  if (n2-n1<=1)
    return true; // nothing to do
  if (n2-n1==2){ // 2x2 submatrix, we know how to diagonalize
    c_complex l1,l2;
    if (eigenval2(H,n2,l1,l2)){
      francis_iterate1(H,n1,n2,P,eps,compute_P,l1,true);
    }
    return true;
  }
  for (int niter=0;n2-n1>1 && niter<maxiter;niter++){
    // if (niter<13) dConsolePut(("niter "+print_INT_(niter)+" "+print(H)).c_str()); Console_NewLine(LINE_TYPE_OUTPUT,1);
    // check if one subdiagonal element is sufficiently small, if so 
    // we can increase n1 or decrease n2 or split
    double ratio,coeff=1;
    if (niter>maxiter-3)
      coeff=100;
    for (int i=n2-2;i>=n1;--i){
      ratio=abs(H[i+1][i])/abs(H[i][i]);
      if (ratio<coeff*eps){ 
	// do a final iteration if i==n2-2 or n2-3? does not improve much precision
	// if (i>=n2-3) francis_iterate2(H,n1,n2,P,eps,true,complex_schur,compute_P,v1,v2);
	// submatrices n1..i and i+1..n2-1
	if (only_one && n2-(i+1)<=2)
	  return true;
	if (!only_one && !in_francis_schur(H,n1,i+1,P,maxiter,eps,compute_P,Haux,only_one)){
	  in_francis_schur(H,i+1,n2,P,maxiter,eps,compute_P,Haux,only_one);
	  return false;
	}
	return in_francis_schur(H,i+1,n2,P,maxiter,eps,compute_P,Haux,only_one);
      }
    }
    francis_iterate2(H,n1,n2,P,eps,compute_P,Haux,only_one);
  } // end for loop on niter
  return false;
}

// Francis algorithm on submatrix rows and columns n1..n2-1
// Invariant: trn(P)*H*P=orig matrix, complex_schur not used for giac_double coeffs
bool francis_schur(cmatrice & H,int n1,int n2,cmatrice & P,int maxiter,double eps,bool is_hessenberg,bool compute_P){
  int n_orig=int(H.size());//,nitershift0=0;
  if (!is_hessenberg){
    hessenberg_ortho(H,P,0,n_orig,compute_P,0); // insure Hessenberg form (on the whole matrix)
  }
  cmatrice Haux(n2/2);
  return in_francis_schur(H,n1,n2,P,maxiter,eps,compute_P,Haux,false);
}

bool schur_eigenvalues(cmatrice &d,double eps){
  int dim=d.size();
  bool ans=true;
  for (int i=0;i<dim;++i){
    cvecteur & di= d[i];
    for (int j=0;j<dim;++j){
      if (j==i) continue;
      if (ans && j==i-1 && abs(di[j])/abs(di[j+1])>eps){
	// *logptr(contextptr) << gettext("Low accuracy for Schur row ") << j << " " << d[i] << '\n';
	ans=false;
      }
      di[j].r=di[j].i=0;
    }
  }
  return ans;
}

// input trn(p)*d*p=original matrix, d upper triangular
// output p*d*inv(p)=original matrix, d diagonal
bool schur_eigenvectors(cmatrice &p,cmatrice & d,double eps){
  int dim=int(p.size());
  cmatrice m(dim);
  cidn(m);
  // columns of m are the vector of the basis of the Schur decomposition
  // in terms of the eigenvector
  for (int k=1;k<dim;++k){
    // compute column k of m
    for (int j=0;j<k;++j){
      c_complex tmp={0,0};
      for (int i=0;i<k;++i){
	tmp += d[i][k]*m[j][i];
      }
      if (!is_zero(tmp)) 
	tmp = tmp*inv(d[j][j]-d[k][k]);
      m[j][k]=tmp;
    }
  }
  if (!cinv(m))
    return false;
  ctrn(p);
  cmatrice pm;
  cmult(p,m,pm);
  swap(p,pm);
  // set d to its diagonal
  return schur_eigenvalues(d,eps);
}

bool c_rref(c_complex * x,int n,int m){
  cmatrice M;
  c_complextab2cmatrice(x,n,m,M);
  cvecteur pivots; vector<int> perm,maxrankcols; c_complex idet;
  crref(M,pivots,perm,maxrankcols,idet,0,n,0,m,1,1e-13,0);
  cmatrice2c_complextab(M,x);
  return true;
}

c_complex c_det(c_complex *x,int n){
  cmatrice M;
  c_complextab2cmatrice(x,n,n,M);
  cvecteur pivots; vector<int> perm,maxrankcols; c_complex idet;
  crref(M,pivots,perm,maxrankcols,idet,0,n,0,n,0,1e-13,1);
  return idet;
}

bool c_inv(c_complex * x,int n){
  cmatrice M;
  c_complextab2cmatrice(x,n,n,M);
  if (!cinv(M))
    return false;
  cmatrice2c_complextab(M,x);
  return true;
}

bool c_eig(c_complex * x,c_complex * d,int n){
  cmatrice H;
  c_complextab2cmatrice(x,n,n,H);
  // load identity
  cmatrice P(n); c_complex z={0,0};
  for (int i=0;i<n;++i){
    P[i]=vector<c_complex>(n,z);
    P[i][i].r=1;
  }
  double eps=1e-11;
  if (!francis_schur(H,0,n,P,100,eps,false,true))
    return false;
  if (!schur_eigenvectors(P,H,eps))
    return false;
  cmatrice2c_complextab(H,d);
  cmatrice2c_complextab(P,x);  
  return true;
}

bool c_egv(c_complex * x,int n){
  cmatrice H;
  c_complextab2cmatrice(x,n,n,H);
  cmatrice P(n); 
  double eps=1e-11;
  if (!francis_schur(H,0,n,P,100,eps,false,false))
    return false;
  if (!schur_eigenvalues(H,eps))
    return false;
  cmatrice2c_complextab(H,x);
  return true;
}



bool c_proot(c_complex * x,int n){
  cvecteur v;
  c_complextab2cvecteur(x,n,v);
  cmatrice H(companion(v));
  n--; // size -> degree
  cmatrice P(n); 
  double eps=1e-11;
  bool dbg=false;
  if (dbg) dConsolePut(print(v).c_str()); 	Console_NewLine(LINE_TYPE_OUTPUT,1);
  if (!francis_schur(H,0,n,P,100,eps,true,false)) 
    return false;
  if (dbg) dConsolePut(print(H).c_str()); 	Console_NewLine(LINE_TYPE_OUTPUT,1);
  if (!schur_eigenvalues(H,eps))
    return false;
  if (dbg) dConsolePut(print(H).c_str()); 	Console_NewLine(LINE_TYPE_OUTPUT,1);
  // copy diag of H in x
  for (int i=0;i<n;++i,++x){
    *x=H[i][i];
  }
  return true;
}
