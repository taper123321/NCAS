#if defined FX || defined FXCG

#include "casio.h"
#include "file.h"

void reset_kbd(){
#ifdef FXCG
  SetSetupSetting( (unsigned int)0x14,0);
#endif
}

int clip_ymin=0;
void os_fill_rect(int x, int y, int width, int height, int color){
  if (x<0){ width+=x; x=0;}
  if (y<clip_ymin){ height+=y-clip_ymin; y=clip_ymin;}
  if (width<=0 || height<=0) return;
  if (x+width>LCD_WIDTH_PX) width=LCD_WIDTH_PX-x;
  if (y+height>LCD_HEIGHT_PX) height=LCD_HEIGHT_PX-y;
  if (width<=0 || height<=0) return;
#ifdef FX
  DISPBOX d={x,y,x+width-1,y+height-1};
  Bdisp_AreaClr_VRAM(&d);
  if (color==SDK_BLACK) Bdisp_AreaReverseVRAM(x,y,x+width-1,y+height-1);
#else
  unsigned short* VRAM = (unsigned short*)GetVRAMAddress();
  VRAM+=(y*384)+x;
  while(height--){
    int i=width;
    while(i--){
      *VRAM++ = color;
    }
    VRAM+=384-width;
  }
#endif
}

#ifdef FX
int print_msg12(const char * msg1,const char * msg2,int textY){
  drawRectangle(0, textY, LCD_WIDTH_PX, 27, _WHITE);
  drawRectangle(2,textY,120,2, _BLACK);
  drawRectangle(2,textY,2,27, _BLACK);
  drawRectangle(120,textY,2,27, _BLACK);
  drawRectangle(2,textY+27,120,2, _BLACK);
  int textX=5;
  textY+=3;
  if (msg1)
    Printmini(textX,textY,msg1,1);
  textY+=8;
  if (msg2)
    Printmini(textX,textY,msg2,1);
  sync_screen();
  return textX;
}
#endif

#ifdef FXCG
static void PrintMini(int x,int y,const char * s,int mode){
  x *=3;
  y *=3;
  PrintMini(&x,&y,(unsigned char *)s,mode,0xFFFFFFFF,0,0,COLOR_BLACK, COLOR_WHITE, 1, 0);
}
int print_msg12(const char * msg1,const char * msg2,int textY){
  drawRectangle(0, textY+10, LCD_WIDTH_PX, 60, SDK_WHITE);
  drawRectangle(3,textY+10,380,3, SDK_BLACK);
  drawRectangle(3,textY+10,3,60, SDK_BLACK);
  drawRectangle(380,textY+10,3,60, SDK_BLACK);
  drawRectangle(3,textY+70,380,3, SDK_BLACK);
  int textX=30;
  textY -= 5;
  if (msg1)
    PrintMini(&textX,&textY,(unsigned char*)msg1,0x02, 0xFFFFFFFF, 0, 0, COLOR_BLACK, COLOR_WHITE, 1, 0); 
  textX=10;
  textY+=25;
  if (msg2)
    PrintMini(&textX,&textY,(unsigned char*)msg2,0x02, 0xFFFFFFFF, 0, 0, COLOR_BLACK, COLOR_WHITE, 1, 0); 
  return textX;
}
#endif

void statusflags(){
#ifdef FX
  int pos=100;
#else
  int pos=300;
#endif
  char mode=Setup_GetEntry(0x14);
  if (mode==1)
    Printmini(pos,0," SHIFT  ",0);
  if (mode==4)
    Printmini(pos,0," ALPHA  ",0);
  if (mode==8)
    Printmini(pos,0," alpha  ",0);
  if (mode==(char) 0x84)
    Printmini(pos,0," ALOCK  ",0);
  if (mode==(char) 0x88)
    Printmini(100,0," alock  ",0);
}

void get_time(int * heure,int * minute){
  int t=RTC_GetTicks();
  t=t/128;
  t=(t+30)/60; // minutes;
  *minute=t%60;
  *heure=(t/60) %24;
}

void set_time(int heure,int minute){
  unsigned char time[7];
  time[0]=0x20;
  time[1]=0x18;
  time[2]=0x10;
  time[3]=0x1;
#if 1
  time[4]=(heure/10)*16+heure % 10;
  time[5]=(minute/10)*16+minute % 10;
#else
  time[4]=heure;//(heure/10)*16+heure % 10;
  time[5]=minute; //(minute/10)*16+minute % 10;
#endif
  time[6]=0x30;
  RTC_SetDateTime(time);
}

int handle_f5(){
  char keyflag = Setup_GetEntry(0x14);
  if (keyflag == 0x04 || keyflag == 0x08 || keyflag == (char)0x84 || keyflag == (char)0x88) {
    // ^only applies if some sort of alpha (not locked) is already on
    if (keyflag == 0x08 || keyflag == (char)0x88) { //if lowercase
      SetSetupSetting( (unsigned int)0x14, keyflag-0x04);
      return 1; //do not process the key, because otherwise we will leave alpha status
    } else {
      SetSetupSetting( (unsigned int)0x14, keyflag+0x04);
      return 1; //do not process the key, because otherwise we will leave alpha status
    }
  }
  if (keyflag==0) {
    SetSetupSetting( (unsigned int)0x14, (char)0x88);	
  }
  return 0;
}

int filebrowser(char * filename,const char * extension,const char * title,int storage){
  return casio_fileBrowser(filename,extension,title);
}


#if  1 // def MPM
// int Keyboard_SpyMatrixCode(char* column, char* row) ;
// returns the current number of key codes in the key buffer.
bool shiftstate=false,alphastate=false,alphalock=false,alphamaj=true,oldshiftstate=false,oldalphastate=false;
short int timeout_delay=300;

void casiostatus(const char * menu,const char * shiftmenu,const char * alphamenu,int color){
  static const char * prev=0;
  bool is_emulator = *(volatile uint32_t *)0xff000044 == 0x00000000;
  bool setstatus=!is_emulator;
  if ((unsigned)menu==1){
    menu=0;
    setstatus=false;
  }
  if (!menu)
    prev=menu;
  if (setstatus){
    int casioset=0;
    if (shiftstate)
      casioset=(1);
    else if (alphastate){
      if (alphalock){
	if (alphamaj)
	  casioset=(0x84);
	else
	  casioset=(0x88);
      }
      else {
	if (alphamaj)
	  casioset=(0x4);
	else
	  casioset=(0x8);
      }
    } 
    SetSetupSetting(0x14,casioset);
  }
  if (menu && shiftmenu && alphamenu){
    int px=0*3,py=58*3;
    const char * cur=0;
    if (shiftstate)
      cur=shiftmenu;
    else {
      if (alphastate && !alphalock)
	cur=alphamenu;
      else
	cur=menu;
    }
    if (cur!=prev){
      prev=cur;
      PrintMini(&px,&py,(unsigned char *)cur,0,0xFFFFFFFF,0,0,COLOR_BLACK,color, 1, 0);
    }
  }
}

#ifdef MPM
const unsigned short translated_keys[] =
{ 
  // non shifted
  KEY_CTRL_F1,KEY_CTRL_F2,KEY_CTRL_F3,KEY_CTRL_UP,KEY_CTRL_F5,KEY_CTRL_PAGEUP,
  KEY_CTRL_SETUP,KEY_CTRL_EXIT,KEY_CTRL_LEFT,KEY_CTRL_OK,KEY_CTRL_RIGHT,KEY_CTRL_PAGEDOWN,
  KEY_CTRL_SHIFT,KEY_CTRL_ALPHA,KEY_CTRL_VARS,KEY_CTRL_DOWN,KEY_CTRL_F4,KEY_CTRL_F6,
  KEY_CTRL_XTT,KEY_CHAR_FRAC,KEY_CHAR_ROOT,KEY_CHAR_POW,KEY_CHAR_SQUARE,KEY_CHAR_EXP,
  KEY_CHAR_COMMA,KEY_CHAR_SIN,KEY_CHAR_COS,KEY_CHAR_TAN,KEY_CHAR_LPAR,KEY_CHAR_RPAR,
  '7','8','9',KEY_CTRL_DEL,KEY_CTRL_AC,KEY_CTRL_AC,
  '4','5','6',KEY_CHAR_MULT,KEY_CHAR_DIV,65535,
  '1','2','3',KEY_CHAR_PLUS,KEY_CHAR_MINUS,65535,
  '0','.',KEY_CHAR_EXP,KEY_CHAR_PMINUS,KEY_CTRL_EXE,65535,
  // shifted
  KEY_CTRL_F7,KEY_CTRL_F8,KEY_CTRL_F9,KEY_CTRL_PAGEUP,KEY_CTRL_F11,KEY_CTRL_F12,
  KEY_CTRL_OPTN,KEY_CTRL_EXIT,KEY_SHIFT_LEFT,KEY_CTRL_OK,KEY_SHIFT_RIGHT,KEY_CTRL_PAGEDOWN,
  KEY_CTRL_SHIFT,KEY_CTRL_ALPHA,KEY_CHAR_STORE,KEY_CTRL_PAGEDOWN,KEY_CTRL_CATALOG,KEY_CTRL_SD,
  KEY_CHAR_STORE,KEY_CTRL_MIXEDFRAC,KEY_CHAR_POWROOT,KEY_CHAR_LOG,KEY_CHAR_LOG,KEY_CHAR_LN,
  ':',KEY_CHAR_ASIN,KEY_CHAR_ACOS,KEY_CHAR_ATAN,'=',KEY_CTRL_CLIP,
  KEY_CHAR_PI,KEY_CHAR_ANGLE,KEY_CHAR_IMGNRY,KEY_CTRL_INS,KEY_PRGM_ACON,65535,
  '[',']',KEY_CHAR_LIST,'{','}',65535,
  KEY_CTRL_UNDO,KEY_CHAR_MAT,KEY_CTRL_PRGM,'<','>',65535,
  KEY_CTRL_CLIP,KEY_CTRL_PASTE,KEY_SAVE,KEY_CHAR_ANS,KEY_CHAR_CR,65535,
  // alpha
  KEY_CTRL_F1,KEY_CTRL_F2,KEY_CTRL_F3,KEY_CTRL_UP,KEY_CTRL_F5,KEY_CTRL_PAGEUP,
  KEY_CTRL_SETUP,KEY_CTRL_EXIT,KEY_CTRL_LEFT,KEY_CTRL_OK,KEY_CTRL_RIGHT,KEY_CTRL_PAGEDOWN,
  KEY_CTRL_SHIFT,KEY_CTRL_ALPHA,KEY_CTRL_VARS,KEY_CTRL_DOWN,KEY_CTRL_F4,KEY_CTRL_F6,
  'A','B','C','D','E','F',
  'G','H','I','J','K','L',
  'M','N','O',KEY_CTRL_DEL,KEY_CTRL_AC,0,
  'P','Q','R','S','T',65535,
  'U','V','W','X','Y',65535,
  'Z',' ','"',KEY_CHAR_ANS,KEY_CTRL_EXE,65535,
  // alpha shifted
  KEY_CTRL_F1,KEY_CTRL_F2,KEY_CTRL_F3,KEY_CTRL_UP,KEY_CTRL_F5,KEY_CTRL_F6,
  KEY_CTRL_OPTN,KEY_CTRL_EXIT,KEY_CTRL_LEFT,KEY_CTRL_OK,KEY_CTRL_RIGHT,KEY_CTRL_PAGEDOWN,
  KEY_CTRL_SHIFT,KEY_CTRL_ALPHA,KEY_CTRL_VARS,KEY_CTRL_DOWN,KEY_CTRL_F4,KEY_CTRL_F6,
  'a','b','c','d','e','f',
  'g','h','i','j','k','l',
  'm','n','o',KEY_CTRL_DEL,KEY_CTRL_AC,0,
  'p','q','r','s','t',65535,
  'u','v','w','x','y',65535,
  'z',' ','"',KEY_CHAR_ANS,KEY_CTRL_EXE,65535,
};
#else
const unsigned short translated_keys[] =
{ 
  // non shifted
  KEY_CTRL_F1,KEY_CTRL_F2,KEY_CTRL_F3,KEY_CTRL_F4,KEY_CTRL_F5,KEY_CTRL_F6,
  KEY_CTRL_SHIFT,KEY_CTRL_OPTN,KEY_CTRL_VARS,KEY_CTRL_MENU,KEY_CTRL_LEFT,KEY_CTRL_UP,
  KEY_CTRL_ALPHA,KEY_CHAR_SQUARE,KEY_CHAR_POW,KEY_CTRL_EXIT,KEY_CTRL_DOWN,KEY_CTRL_RIGHT,
  KEY_CTRL_XTT,KEY_CHAR_LOG,KEY_CHAR_LN,KEY_CHAR_SIN,KEY_CHAR_COS,KEY_CHAR_TAN,
  KEY_CHAR_FRAC,KEY_CTRL_SD,KEY_CHAR_LPAR,KEY_CHAR_RPAR,KEY_CHAR_COMMA,KEY_CHAR_STORE,
  '7','8','9',KEY_CTRL_DEL,KEY_CTRL_AC,KEY_CTRL_AC,
  '4','5','6',KEY_CHAR_MULT,KEY_CHAR_DIV,65535,
  '1','2','3',KEY_CHAR_PLUS,KEY_CHAR_MINUS,65535,
  '0','.',KEY_CHAR_EXP,KEY_CHAR_PMINUS,KEY_CTRL_EXE,65535,
  // shifted
  KEY_CTRL_F7,KEY_CTRL_F8,KEY_CTRL_F9,KEY_CTRL_F10,KEY_CTRL_F11,KEY_CTRL_F12,
  KEY_CTRL_SHIFT,KEY_SHIFT_OPTN,KEY_CTRL_PRGM,KEY_CTRL_SETUP,KEY_SHIFT_LEFT,KEY_CTRL_PAGEUP,
  KEY_CTRL_ALPHA,KEY_CHAR_ROOT,KEY_CHAR_POWROOT,KEY_CTRL_QUIT,KEY_CTRL_PAGEDOWN,KEY_SHIFT_RIGHT,
  KEY_CHAR_ANGLE,KEY_CHAR_EXPN10,KEY_CHAR_EXPN,KEY_CHAR_ASIN,KEY_CHAR_ACOS,KEY_CHAR_ATAN,
  KEY_CTRL_MIXEDFRAC,KEY_CTRL_FRACCNVRT,KEY_CHAR_CUBEROOT,KEY_CHAR_RECIP,KEY_LOAD,KEY_SAVE,
  KEY_CTRL_CAPTURE,KEY_CTRL_CLIP,KEY_CTRL_PASTE,KEY_CTRL_INS,KEY_PRGM_ACON,65535,
  KEY_CTRL_CATALOG,KEY_CTRL_FORMAT,KEY_CTRL_F16,KEY_CHAR_LBRACE,KEY_CHAR_RBRACE,65535,
  KEY_CHAR_LIST,KEY_CHAR_MAT,KEY_CTRL_F13,KEY_CHAR_LBRCKT,KEY_CHAR_RBRCKT,65535,
  KEY_CHAR_IMGNRY,KEY_CHAR_EQUAL,KEY_CHAR_PI,KEY_CHAR_ANS,KEY_CHAR_CR,65535,
  // alpha
  KEY_CTRL_F1,KEY_CTRL_F2,KEY_CTRL_F3,KEY_CTRL_F4,KEY_CTRL_F5,KEY_CTRL_F6,
  KEY_CTRL_SHIFT,KEY_CTRL_OPTN,KEY_CTRL_VARS,9,KEY_CTRL_LEFT,KEY_CTRL_UP,
  KEY_CTRL_ALPHA,KEY_CHAR_VALR,KEY_CHAR_THETA,KEY_CTRL_EXIT,KEY_CTRL_DOWN,KEY_CTRL_RIGHT,
  'A','B','C','D','E','F',
  'G','H','I','J','K','L',
  'M','N','O',KEY_CTRL_UNDO,KEY_CTRL_DEL,KEY_CTRL_AC,
  'P','Q','R','S','T',65535,
  'U','V','W','X','Y',65535,
  'Z',' ','"',KEY_CHAR_ANS,KEY_CTRL_EXE,65535,
  // alpha shifted
  KEY_CTRL_F1,KEY_CTRL_F2,KEY_CTRL_F3,KEY_CTRL_F4,KEY_CTRL_F5,KEY_CTRL_F6,
  KEY_CTRL_SHIFT,KEY_CTRL_OPTN,KEY_CTRL_VARS,9,KEY_CTRL_LEFT,KEY_CTRL_UP,
  KEY_CTRL_ALPHA,KEY_CHAR_VALR,KEY_CHAR_THETA,KEY_CTRL_EXIT,KEY_CTRL_DOWN,KEY_CTRL_RIGHT,
  'a','b','c','d','e','f',
  'g','h','i','j','k','l',
  'm','n','o',KEY_CTRL_UNDO,KEY_CTRL_DEL,KEY_CTRL_AC,
  'p','q','r','s','t',65535,
  'u','v','w','x','y',65535,
  'z',' ','"',KEY_CHAR_ANS,KEY_CTRL_EXE,65535,
};
#endif

static volatile int menutimer=0;
void clear_menu_timer(){
  if (menutimer > 0) {
    Timer_Stop(menutimer);
    Timer_Deinstall(menutimer);
    menutimer=0;
  }
}

void send_menu_key(){
  if (menutimer > 0) {
    clear_menu_timer();
    // OS_InnerWait_ms(50);
    // menu row 9 col 4
    // Keyboard_PutKeycode(4,9,KEY_CTRL_MENU);
    Keyboard_PutKeycode(4,9,0);
  }
}

void set_menu_timer(){
  if (menutimer) return;
  menutimer = Timer_Install(0,send_menu_key, 50);
  if (menutimer > 0) {
    Timer_Start(menutimer);
  }
}

int in_ckgetkey(int * keyptr,int waitforkey,const char * menu,const char * shiftmenu,const char * alphamenu,int menucolorbg){
  bool is_emulator = *(volatile uint32_t *)0xff000044 == 0x00000000;
  int keyflag=GetSetupSetting( (unsigned int)0x14);
  if (is_emulator){
    alphalock= keyflag &0x80;
    if ( (keyflag&4) | (keyflag &8))
      alphastate=oldalphastate=true;
    else
      alphastate=oldalphastate=false;
    if (keyflag & 1)
      shiftstate=oldshiftstate=true;
    else
      shiftstate=oldshiftstate=false;
    casiostatus(0,0,0,0);
    casiostatus(menu,shiftmenu,alphamenu,menucolorbg);
    GetKey(keyptr);
    if (*keyptr>=KEY_CTRL_F1 && *keyptr<=KEY_CTRL_F6 && (keyflag & 1))
      *keyptr += 9906; // shift-F1 -> F7
    if (*keyptr>=KEY_CTRL_F1 && *keyptr<=KEY_CTRL_F6 && (alphastate && !alphalock))
      *keyptr += 9912; // ALPHA-F1 -> F13
    return 1;
  }
  int col, row;
  unsigned short keycode=0;
  shiftstate=false;alphastate=false;alphalock=false;alphamaj=true;
  // Keyboard input mode. 0 for standard, 0x01 for Shift, 0x04 for Alpha, 0x08 for lower-case Alpha, 0x84 for Alpha-lock, 0x88 for lower-case Alpha-Lock. 
  if ( (keyflag&4) | (keyflag &8))
    alphastate=true;
  if (keyflag&0x80)
    alphalock=true;
  if (keyflag==0x88)
    alphamaj=false;
  if (keyflag & 1)
    shiftstate=true;
  while (1){
    if (waitforkey){
      casiostatus(menu,shiftmenu,alphamenu,menucolorbg);
      //DefineStatusMessage(shiftstate?shiftmenu:menu,1,0,0);
      DisplayStatusArea();
      Bdisp_PutDisp_DD ();
    }
    SetSetupSetting(0x14,0); // disable OFF
    int ret=GetKeyWait_OS(&col,&row, waitforkey?2:1, timeout_delay /*timeout_period*/, 1 /* 0: handle menu key*/, &keycode) ;
    // ret==0 : no key available, ret==1 key available, ret==2 timeout
    if (ret==0)
      return -1;
#ifndef MPM
    if (!shiftstate && (col==4 && row==9)){
      //save_session();
      set_menu_timer();
      GetKey(keyptr);
      //*keyptr=KEY_SHUTDOWN;
      return 1;      
    }
#endif
    if (ret==2 /* timeout */ ){
      // save_session();
      //printf("timeout shutdown \n");
#if 1
      set_menu_timer();
      GetKey(keyptr);
      //*keyptr=KEY_SHUTDOWN;
      return 1;      
#endif
      print_msg12("Auto shutdown","MENU");	
      Bdisp_PutDisp_DD ();
      set_menu_timer();
      GetKey(keyptr);
      *keyptr=KEY_SHUTDOWN;
      return 1;
      // continue;
    }
    if (0 && keycode>0){
      *keyptr=keycode;
      return ret;
    }
    int code;
    if (col==1)
      code=35;
    else
      code=(10-row)*6+(7-col);
#if 0
    char buf[256],buf2[256];
    sprint_int(buf,row);
    sprint_int(buf2,col);
    *logptr(contextptr) << "row " << buf << " col " << buf2 << '\n';
#endif
    if (code==
#ifdef MPM
        12
#else
        6
#endif
        ){ // shift
      shiftstate=!shiftstate;
      continue;
      *keyptr=KEY_CTRL_SHIFT; return 1; // does not work
    }
    if (code==
#ifdef MPM
        13
#else
        12
#endif
        ){ // alpha
      if (shiftstate){
	alphastate=true;
	alphalock=true;
	shiftstate=false;
      }
      else {
	if (alphastate){
	  alphastate=false;
	  alphalock=false;
	}
	else
	  alphastate=true;
      }
      continue;
      *keyptr=KEY_CTRL_ALPHA; return 1;// does not work
    }
    if (code<0 || code>=54/* USB connect */){
      *keyptr=KEY_SHUTDOWN;
      return 1;
      print_msg12("Please type any key","");
      Bdisp_PutDisp_DD ();
      GetKey(keyptr);
      return 1;
    }
    if (shiftstate && code==35){
      shiftstate=false;
      // print_msg12("Type MENU SHIFT ON to shutdown","Taper MENU SHIFT ON pour eteindre");
      *keyptr=KEY_SHUTDOWN;
      return 1;
#if 0
      print_msg12("Back to home menu. To shutdown","type again SHIFT AC");	
      Bdisp_PutDisp_DD ();
      OS_InnerWait_ms(1000);
      set_menu_timer();
      GetKey(keyptr);
      //*keyptr=KEY_SHUTDOWN;
      return 1;      
#endif
      print_msg12("To shutdown, type the keys","SHIFT AC/ON");	
      continue;
      Bdisp_PutDisp_DD ();
      OS_InnerWait_ms(1000);
      //set_menu_timer();
      //GetKey(keyptr);
      casiostatus(menu,shiftmenu,alphamenu,menucolorbg);
      *keyptr=KEY_SHUTDOWN;
      return 1;
    }
    // col and row translation to keycode
    if (alphastate){
      if (alphamaj)
	code += 2*9*6;
      else
	code += 3*9*6;
    }
    else 
      if (shiftstate)
	code += 9*6;
    *keyptr=translated_keys[code];
    if (alphalock && *keyptr==KEY_CTRL_UNDO)
      *keyptr=KEY_CTRL_DEL;
    if (alphastate && !alphalock){
      if (*keyptr==KEY_CTRL_EXIT)
	*keyptr=65535;
      if (*keyptr>=KEY_CTRL_F1 && *keyptr<=KEY_CTRL_F6)
	*keyptr += KEY_CTRL_F13-KEY_CTRL_F1;
    }
#if 0
    char buf[512];
    sprintf(buf,"code %i key %i ",code,*keyptr);
    Console_Output(buf);
#endif
    oldshiftstate=shiftstate;
    shiftstate=false;
    oldalphastate=alphastate;
    if (!alphalock)
      alphastate=false;
    casiostatus(menu,shiftmenu,alphamenu,menucolorbg);
    return 1;
  }
}

int ck_getkey(int * keyptr){
  return in_ckgetkey(keyptr,1,0,0,0,12345); /* wait for key */
}

#else

//#include "console.h"
int ck_getkey(int * keyptr){
  int keyflag=GetSetupSetting( (unsigned int)0x14);
#ifdef FX
  GetKey((unsigned int *)keyptr);
#else
  GetKey(keyptr);
#endif
  if (*keyptr>=KEY_CTRL_F1 && *keyptr<=KEY_CTRL_F6 && (keyflag & 1)){
    *keyptr += KEY_CTRL_F7-KEY_CTRL_F1;
    // confirm(print_INT_(keyflag).c_str(),print_INT_(*keyptr).c_str());
  }
  if (*keyptr>=KEY_CTRL_F1 && *keyptr<=KEY_CTRL_F6 && (keyflag & 0xc)){
    *keyptr += KEY_CTRL_F13-KEY_CTRL_F1;;
    // confirm(print_INT_(keyflag).c_str(),print_INT_(*keyptr).c_str());
  }
  return 1;
}

#endif

bool erase_file(const char * filename){
  unsigned short pFile[MAX_FILENAME_SIZE+1];
  // create file in data folder (assumes data folder already exists)
  Bfile_StrToName_ncpy(pFile, (const unsigned char *)filename, strlen(filename)+1);
  int hFile = Bfile_OpenFile_OS(pFile, _OPENMODE_READWRITE); // Get handle
  if (hFile>=0){
    Bfile_CloseFile_OS(hFile);
    Bfile_DeleteEntry(pFile);
    return true;
  }
  return false;
}  

void sync_screen(){ Bdisp_PutDisp_DD(); }

void clear_screen(){
  Bdisp_AllClr_VRAM();
}

int os_get_pixel(int x0,int y0){
#if 0
  return Bdisp_GetPoint_VRAM(x0,y0);
#else
  unsigned short* VRAM = (unsigned short*)GetVRAMAddress();
  VRAM += (y0*LCD_WIDTH_PX + x0);
  return *VRAM;
#endif
}


#ifdef FX // Casio monochrom
int os_draw_string(int x,int y,int c,int bg,const char * s,bool fake){
  if (!fake) 
    PrintXY(x,y,(const unsigned char *) s,c==SDK_WHITE?1:0);
  return x+6*strlen(s);  
}

int os_draw_string_medium(int x,int y,int c,int bg,const char * s,bool fake){
  return os_draw_string(x,y,c,bg,s,fake);
}

int os_draw_string_small(int x,int y,int c,int bg,const char * s,bool fake){
  if (!fake) 
    return PrintMini(x,y,(const unsigned char *) s,c==SDK_WHITE?1:0);
  return x+4*strlen(s);  
}

void os_set_pixel(int x0, int y0,int color) {
  if (x0<0 || x0>=LCD_WIDTH_PX || y0<clip_ymin || y0>=LCD_HEIGHT_PX)
    return;
  Bdisp_SetPoint_VRAM(x0,y0,color==SDK_WHITE?0:1);
}

void statuslinemsg(const char * s){
  os_fill_rect(0,0,LCD_WIDTH_PX,7,SDK_WHITE);
  Printmini(0,0,s,0);
}

int execution_in_progress=0;
volatile bool kbd_interrupted=false; int esc_flag=0;

static void check_execution_abort() {
  if (execution_in_progress) {
    // HourGlass();
#if 0
    unsigned int key=0;
    int res = GetKeyWait(KEYWAIT_HALTOFF_TIMEROFF,0,1,&key);//PRGM_GetKey_();
    if (res==KEYREP_KEYEVENT){
      //cout << "timer " << key << " " << res << endl;
      cout << "Key pressed" << endl;
      esc_flag = 1;
    }
#else
    unsigned short key=0;
    int c=0,r=0;
    int res = getkeywait(&c,&r,KEYWAIT_HALTOFF_TIMEROFF,0,1,&key);//PRGM_GetKey_();
    if (res==KEYREP_KEYEVENT){
      // cout << "timer " << c << " " << r << endl;
      if (c==1 && r==1){
	//cout << "AC/ON" << endl;
	esc_flag = 1;
	kbd_interrupted=true;
      }
    }
#endif      
  }
}
  
static int aborttimer = 0;
void set_abort(){
  //cout << "set_abort " << endl;
  for (int i=1;i<=5;++i){
    aborttimer=SetTimer(i,300,check_execution_abort);
    if (aborttimer>0){
      //cout << "abort " << aborttimer << " " << i << endl;
      aborttimer=i;
      return;
    }
  }
  aborttimer=-1;
  // aborttimer = Timer_Install(0, check_execution_abort, 100);
  // if (aborttimer > 0) { Timer_Start(aborttimer); }  
}
  
void clear_abort(){
  //cout << "clr_abort " << aborttimer << endl;
  if (aborttimer > 0) {
    KillTimer(aborttimer);
    //Timer_Stop(aborttimer);
    //Timer_Deinstall(aborttimer);
  }
}
void OS_InnerWait_ms(int ms){
  Sleep(ms); 
}

void HourGlass(){
}

int GetKeyWait_OS(int* column, int* row, int type_of_waiting, int timeout_period, int menu, unsigned short* keycode){
  getkeywait(column,row,type_of_waiting,timeout_period,menu,keycode);
}

#endif // FX

#ifdef FXCG
int os_draw_string(int x,int y,int c,int bg,const char * s,bool fake){
  if (!fake)
    PrintCXY(x, y, s, 0, -1, c, bg, 1,0);
  return x+18*strlen(s);  
}

int os_draw_string_medium(int x,int y,int c,int bg,const char * s,bool fake){
  int X=x,Y=y;
  PrintMini(&X, &Y, (unsigned char *)s, 0, 0xFFFFFFFF, 0, 0, c, bg, fake?0:1, 0);
  return X;
}

int os_draw_string_small(int x,int y,int c,int bg,const char * s,bool fake){
  int X=x,Y=y;
  PrintMini(&X, &Y, (unsigned char *)s, 0, 0xFFFFFFFF, 0, 0, c, bg, fake?0:1, 0);
  return X;
}

void Printmini(int x,int y,const char * s,int i){
  int X=x,Y=y;
  PrintMini(&X, &Y, (unsigned char *)s, i?4:0, 0xFFFFFFFF, 0, 0, SDK_BLACK, SDK_WHITE, 1, 0);
}

unsigned short* VRAMsave =0;
void os_set_pixel(int x0, int y0,int color) {
  //if (x0>100 && x0<150 && y0>100 && y0<150) cout << x0 << " " << y0 << '\n';
  //drawRectangle(x0,y0,1,1,color);
  if (x0<0 || x0>=LCD_WIDTH_PX || y0<clip_ymin || y0>=LCD_HEIGHT_PX)
    return;
  if (!VRAMsave)
    VRAMsave = (unsigned short*)GetVRAMAddress(); 
  unsigned short * VRAM = VRAMsave + (y0*LCD_WIDTH_PX + x0);
  *VRAM=color;//COLOR_RED; // color; 
}

void fxcg_set_pixel(int x,int y,int c);
extern bool freeze; extern int c_yshift;
void fxcg_set_pixel(int x0,int y0,int c){
  freeze=true;
  y0 += c_yshift;
  if (x0<0 || x0>=LCD_WIDTH_PX || y0<clip_ymin || y0>=LCD_HEIGHT_PX)
    return;
  if (!VRAMsave)
    VRAMsave = (unsigned short*)GetVRAMAddress(); 
  unsigned short * VRAM = VRAMsave + (y0*LCD_WIDTH_PX + x0);
  *VRAM=c;
}


void statuslinemsg(const char * s){
  EnableStatusArea(2);
  DefineStatusAreaFlags(3, SAF_BATTERY | SAF_TEXT | SAF_GLYPH | SAF_ALPHA_SHIFT, 0, 0);
  DefineStatusMessage((char *)s, 0, 0, 0);
  DisplayStatusArea();
  return;
}

static int PRGM_GetKey_() {
  unsigned char buffer[12];
  PRGM_GetKey_OS( buffer );
  return ( ( buffer[1] & 0x0F) *10 + ( ( buffer[2] & 0xF0) >> 4 ));
}
  
int execution_in_progress = 0; // set to 1 during program execution

static void check_execution_abort() {
  if (execution_in_progress) {
    HourGlass();
    short unsigned int key = PRGM_GetKey_();
    if(key == KEY_PRGM_ACON){
      // if (!ctrl_c) cout << "ACON pressed\n";
      esc_flag = 1;
      ctrl_c=kbd_interrupted=interrupted=true;
    }
  }
}
  
static int aborttimer = 0;
void set_abort(){
  aborttimer = Timer_Install(0, check_execution_abort, 100);
  if (aborttimer > 0) { Timer_Start(aborttimer); }
}
  
void clear_abort(){
  if (aborttimer > 0) {
    Timer_Stop(aborttimer);
    Timer_Deinstall(aborttimer);
  }
}
    
#endif

#endif // FX || FXCG

