#include <string>
#include "calc.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <ctype.h>

#include "menuGUI.h"
#include "textGUI.h"
#include "main.h"
#include "console.h"

using namespace ustl;
int lang=0;

void fix_f(int & key){
  if (key>=KEY_CTRL_F7 && key<=KEY_CTRL_F12)
    key -= 906;
  if (key>=KEY_CTRL_F13 && key<=KEY_CTRL_F18)
    key -= 912;
}

int doMenu(Menu* menu, MenuItemIcon* icontable) { // returns code telling what user did. selection is on menu->selection. menu->selection starts at 1!
  int itemsStartY=menu->startY; // char Y where to start drawing the menu items. Having a title increases this by one
  int itemsHeight=menu->height;
  int showtitle = menu->title != NULL;
  if (showtitle) {
    itemsStartY++;
    itemsHeight--;
  }
  char keyword[5];
  keyword[0]=0;
  if(menu->selection > menu->scroll+(menu->numitems>itemsHeight ? itemsHeight : menu->numitems))
    menu->scroll = menu->selection -(menu->numitems>itemsHeight ? itemsHeight : menu->numitems);
  if(menu->selection-1 < menu->scroll)
    menu->scroll = menu->selection -1;
  
  while(1) {
    Cursor_SetFlashOff();
    if (menu->selection <=1)
      menu->selection=1;
    if (menu->selection > menu->scroll+(menu->numitems>itemsHeight ? itemsHeight : menu->numitems))
      menu->scroll = menu->selection -(menu->numitems>itemsHeight ? itemsHeight : menu->numitems);
    if (menu->selection-1 < menu->scroll)
      menu->scroll = menu->selection -1;
    //if(menu->statusText != NULL) DefineStatusMessage(menu->statusText, 1, 0, 0);
    // Clear the area of the screen we are going to draw on
    if(0 == menu->pBaRtR) drawRectangle(C18*(menu->startX-1), C24*(menu->miniMiniTitle ? itemsStartY:menu->startY), C18*(menu->width+2)+((menu->scrollbar && menu->scrollout)?C6:0), C24*menu->height-(menu->miniMiniTitle ? C24:0), _WHITE);
    if (menu->numitems>0) {
      for(int curitem=0; curitem < menu->numitems; curitem++) {
        // print the menu item only when appropriate
        if(menu->scroll < curitem+1 && menu->scroll > curitem-itemsHeight) {
          char menuitem[256] = "";
          if(menu->numitems>=100 || menu->type == MENUTYPE_MULTISELECT){
	    strcpy(menuitem, "  "); //allow for the folder and selection icons on MULTISELECT menus (e.g. file browser)
	    strcpy(menuitem+2,menu->items[curitem].text);
	  }
	  else {
	    int cur=curitem+1;
	    if (menu->numitems<10){
	      menuitem[0]='0'+cur;
	      menuitem[1]=' ';
	      menuitem[2]=0;
	      strcpy(menuitem+2,menu->items[curitem].text);
	    }
	    else {
	      menuitem[0]=cur>=10?('0'+(cur/10)):' ';
	      menuitem[1]='0'+(cur%10);
	      menuitem[2]=' ';
	      menuitem[3]=0;
	      strcpy(menuitem+3,menu->items[curitem].text);
	    }
	  }
          //strncat(menuitem, menu->items[curitem].text, 68);
          if(menu->items[curitem].type != MENUITEM_SEPARATOR) {
            //make sure we have a string big enough to have background when item is selected:          
            // MB_ElementCount is used instead of strlen because multibyte chars count as two with strlen, while graphically they are just one char, making fillerRequired become wrong
            int fillerRequired = menu->width - MB_ElementCount(menu->items[curitem].text) - (menu->type == MENUTYPE_MULTISELECT ? 2 : 3);
            for(int i = 0; i < fillerRequired; i++) strcat(menuitem, " ");
            Printxy(6*menu->startX,8*(curitem+itemsStartY-menu->scroll),menuitem, (menu->selection == curitem+1 ? TEXT_MODE_INVERT : TEXT_MODE_NORMAL));
          } else {
            /*int textX = (menu->startX-1) * C18;
            int textY = curitem*C24+itemsStartY*C24-menu->scroll*C24-C24+C6;
            clearLine(menu->startX, curitem+itemsStartY-menu->scroll, (menu->selection == curitem+1 ? textColorToFullColor(menu->items[curitem].color) : _WHITE));
            drawLine(textX, textY+C24-4, LCD_WIDTH_PX-2, textY+C24-4, COLOR_GRAY);
            Printmini(&textX, &textY, (unsigned char*)menuitem, 0, 0xFFFFFFFF, 0, 0, (menu->selection == curitem+1 ? _WHITE : textColorToFullColor(menu->items[curitem].color)), (menu->selection == curitem+1 ? textColorToFullColor(menu->items[curitem].color) : _WHITE), 1, 0);*/
          }
          // deal with menu items of type MENUITEM_CHECKBOX
          if(menu->items[curitem].type == MENUITEM_CHECKBOX) {
            Printxy(6*(menu->startX+menu->width-1),8*(curitem+itemsStartY-menu->scroll),
              (menu->items[curitem].value == MENUITEM_VALUE_CHECKED ? "\xe6\xa9" : "\xe6\xa5"),
              (menu->selection == curitem+1 ? TEXT_MODE_INVERT : (menu->pBaRtR == 1? TEXT_MODE_NORMAL : TEXT_MODE_NORMAL)));
          }
          // deal with multiselect menus
          if(menu->type == MENUTYPE_MULTISELECT) {
            if((curitem+itemsStartY-menu->scroll)>=itemsStartY &&
              (curitem+itemsStartY-menu->scroll)<=(itemsStartY+itemsHeight) &&
              icontable != NULL
            ) {
#if 0
              if (menu->items[curitem].isfolder == 1) {
                // assumes first icon in icontable is the folder icon
                CopySpriteMasked(icontable[0].data, (menu->startX)*C18, (curitem+itemsStartY-menu->scroll)*C24, 0x12, 0x18, 0xf81f  );
              } else {
                if(menu->items[curitem].icon >= 0) CopySpriteMasked(icontable[menu->items[curitem].icon].data, (menu->startX)*C18, (curitem+itemsStartY-menu->scroll)*C24, 0x12, 0x18, 0xf81f  );
              }
#endif
            }
            if (menu->items[curitem].isselected) {
              if (menu->selection == curitem+1) {
                Printxy(6*menu->startX,8*(curitem+itemsStartY-menu->scroll),"\xe6\x9b", TEXT_MODE_NORMAL);
              } else {
                Printxy(6*menu->startX,8*(curitem+itemsStartY-menu->scroll),"\xe6\x9b", TEXT_MODE_NORMAL);
              }
            }
          }
        }
      }
      if (menu->scrollbar) {
#ifdef SCROLLBAR
        TScrollbar sb;
        sb.I1 = 0;
        sb.I5 = 0;
        sb.indicatormaximum = menu->numitems;
        sb.indicatorheight = itemsHeight;
        sb.indicatorpos = menu->scroll;
        sb.barheight = itemsHeight*C24;
        sb.bartop = (itemsStartY-1)*C24;
        sb.barleft = menu->startX*C18+menu->width*C18 - C18 - (menu->scrollout ? 0 : 5);
        sb.barwidth = C6;
        Scrollbar(&sb);
#endif
      }
      //if(menu->type==MENUTYPE_MULTISELECT && menu->fkeypage == 0) drawFkeyLabels(0x0037); // SELECT (white)
    } else {
      printCentered(menu->nodatamsg, (itemsStartY*C24)+(itemsHeight*C24)/2-12);
    }
    if(showtitle) {
      if(menu->miniMiniTitle) {
        int textX = 0, textY=(menu->startY-1)*C24;
        Printmini( textX, textY, menu->title, 0 );
      } else Printxy(6*menu->startX, 8*menu->startY, menu->title, TEXT_MODE_NORMAL);
      if(menu->subtitle != NULL) {
        int textX=(MB_ElementCount(menu->title)+menu->startX-1)*C18+C10, textY=C6;
        Printmini(textX, textY, menu->subtitle, 0);
      }
      Printxy(104, 1, "____", 0);
      Printxy(104, 1, keyword, 0);
    }
    /*if(menu->darken) {
      DrawFrame(_BLACK);
      VRAMInvertArea(menu->startX*C18-C18, menu->startY*C24, menu->width*C18-(menu->scrollout || !menu->scrollbar ? 0 : 5), menu->height*C24);
    }*/
    if(menu->type == MENUTYPE_NO_KEY_HANDLING) return MENU_RETURN_INSTANT; // we don't want to handle keys
    int key;
    ck_getkey(&key);
    fix_f(key);
    if (isalpha(key)){
      key=tolower(key);
      int pos=strlen(keyword);
      if (pos>=4)
	pos=0;
      keyword[pos]=key;
      keyword[pos+1]=0;
      int cur=0;
      for (;cur<menu->numitems;++cur){
#if 1
	if (strcmp(menu->items[cur].text,keyword)>=0)
	  break;
#else
	char c=menu->items[cur].text[0];
	if (key<=c)
	  break;
#endif
      }
      if (cur<menu->numitems){
	menu->selection=cur+1;
	if(menu->selection > menu->scroll+(menu->numitems>itemsHeight ? itemsHeight : menu->numitems))
	  menu->scroll = menu->selection -(menu->numitems>itemsHeight ? itemsHeight : menu->numitems);
	if(menu->selection-1 < menu->scroll)
	  menu->scroll = menu->selection -1;
      }
      continue;
    }
    switch(key) {
    case KEY_CTRL_PAGEDOWN:
      menu->selection+=6;
      if (menu->selection >= menu->numitems)
	menu->selection=menu->numitems;
      if(menu->selection > menu->scroll+(menu->numitems>itemsHeight ? itemsHeight : menu->numitems))
	menu->scroll = menu->selection -(menu->numitems>itemsHeight ? itemsHeight : menu->numitems);
      break;
    case KEY_CTRL_DOWN:
      if(menu->selection == menu->numitems)
	{
          if(menu->returnOnInfiniteScrolling) {
            return MENU_RETURN_SCROLLING;
          } else {
            menu->selection = 1;
            menu->scroll = 0;
          }
        }
      else
        {
	  menu->selection++;
          if(menu->selection > menu->scroll+(menu->numitems>itemsHeight ? itemsHeight : menu->numitems))
            menu->scroll = menu->selection -(menu->numitems>itemsHeight ? itemsHeight : menu->numitems);
        }
      if(menu->pBaRtR==1) return MENU_RETURN_INSTANT;
      break;
    case KEY_CTRL_PAGEUP:
      menu->selection-=6;
      if (menu->selection <=1)
	menu->selection=1;
      if(menu->selection-1 < menu->scroll)
	menu->scroll = menu->selection -1;
      break;
    case KEY_CTRL_UP:
      if(menu->selection == 1)
	{
	  if(menu->returnOnInfiniteScrolling) {
	    return MENU_RETURN_SCROLLING;
	  } else {
	    menu->selection = menu->numitems;
	    menu->scroll = menu->selection-(menu->numitems>itemsHeight ? itemsHeight : menu->numitems);
	  }
	}
      else
	{
	  menu->selection--;
	  if(menu->selection-1 < menu->scroll)
	    menu->scroll = menu->selection -1;
	}
      if(menu->pBaRtR==1) return MENU_RETURN_INSTANT;
      break;
    case KEY_CTRL_F1: 
      if(menu->type==MENUTYPE_MULTISELECT && menu->fkeypage == 0 && menu->numitems > 0) {
          /*if(menu->items[menu->selection-1].isselected) {
            menu->items[menu->selection-1].isselected=0;
            menu->numselitems = menu->numselitems-1;
	    } else {
            menu->items[menu->selection-1].isselected=1;
            menu->numselitems = menu->numselitems+1;
	    }
	    return key; //return on F1 too so that parent subroutines have a chance to e.g. redraw fkeys*/
      } else if (menu->type == MENUTYPE_FKEYS) {
	return key;
      }
      break;
    case KEY_CTRL_F2:
    case KEY_CTRL_F3:
    case KEY_CTRL_F4:
    case KEY_CTRL_F5:
    case KEY_CTRL_F6:
      if (menu->type == MENUTYPE_FKEYS || menu->type==MENUTYPE_MULTISELECT) return key; // MULTISELECT also returns on Fkeys
      break;
    case KEY_CTRL_PASTE:
      if (menu->type==MENUTYPE_MULTISELECT) return key; // MULTISELECT also returns on paste
    case KEY_CTRL_OPTN:
      if (menu->type==MENUTYPE_FKEYS || menu->type==MENUTYPE_MULTISELECT) return key;
      break;
    case KEY_CTRL_FORMAT:
      if (menu->type==MENUTYPE_FKEYS) return key; // return on the Format key so that event lists can prompt to change event category
      break;
    case KEY_CTRL_RIGHT:
      if(menu->type != MENUTYPE_MULTISELECT) break;
      // else fallthrough
    case KEY_CTRL_EXE:
      if(menu->numitems>0) return MENU_RETURN_SELECTION;
      break;
    case KEY_CTRL_LEFT:
      if(menu->type != MENUTYPE_MULTISELECT) break;
      // else fallthrough
    case KEY_CTRL_DEL:
      if (strlen(keyword))
	keyword[strlen(keyword)-1]=0;
      else {
	if (strncmp(menu->title,"VARS",4)==0)
	  return key;
      }
      break;
    case KEY_CTRL_AC:
      if (strlen(keyword)){
	keyword[0]=0;
	SetSetupSetting( (unsigned int)0x14, 0x88);	
	//DisplayStatusArea();
	break;
      }
    case KEY_CTRL_EXIT: 
      return MENU_RETURN_EXIT;
      break;
    case KEY_CHAR_1:
    case KEY_CHAR_2:
    case KEY_CHAR_3:
    case KEY_CHAR_4:
    case KEY_CHAR_5:
    case KEY_CHAR_6:
    case KEY_CHAR_7:
    case KEY_CHAR_8:
    case KEY_CHAR_9:
      if(menu->numitems>=(key-0x30)) {
	menu->selection = (key-0x30);
	if (menu->type != MENUTYPE_FKEYS) return MENU_RETURN_SELECTION;
      }
      break;
    case KEY_CHAR_0:
      if(menu->numitems>=10) {
	menu->selection = 10;
	if (menu->type != MENUTYPE_FKEYS)  return MENU_RETURN_SELECTION;
      }
      break;
    case KEY_CTRL_XTT:
      if(menu->numitems>=11) {
	menu->selection = 11;
	if (menu->type != MENUTYPE_FKEYS)  return MENU_RETURN_SELECTION;
      }
      break;
    case KEY_CHAR_LOG:
      if(menu->numitems>=12) {
	menu->selection = 12;
	if (menu->type != MENUTYPE_FKEYS)  return MENU_RETURN_SELECTION;
      }
      break;
    case KEY_CHAR_LN:
      if(menu->numitems>=13) {
	menu->selection = 13;
	if (menu->type != MENUTYPE_FKEYS)  return MENU_RETURN_SELECTION;
      }
      break;
    case KEY_CHAR_SIN:
    case KEY_CHAR_COS:
    case KEY_CHAR_TAN:
      if(menu->numitems>=(key-115)) {
	menu->selection = (key-115);
	if (menu->type != MENUTYPE_FKEYS)  return MENU_RETURN_SELECTION;
      }
      break;
    case KEY_CHAR_FRAC:
      if(menu->numitems>=17) {
	menu->selection = 17;
	if (menu->type != MENUTYPE_FKEYS)  return MENU_RETURN_SELECTION;
      }
      break;
    case KEY_CTRL_FD:
      if(menu->numitems>=18) {
	menu->selection = 18;
	if (menu->type != MENUTYPE_FKEYS)  return MENU_RETURN_SELECTION;
      }
      break;
    case KEY_CHAR_LPAR:
    case KEY_CHAR_RPAR:
      if(menu->numitems>=(key-21)) {
	menu->selection = (key-21);
	if (menu->type != MENUTYPE_FKEYS)  return MENU_RETURN_SELECTION;
      }
      break;
    case KEY_CHAR_COMMA:
      if(menu->numitems>=21) {
	menu->selection = 21;
	if (menu->type != MENUTYPE_FKEYS)  return MENU_RETURN_SELECTION;
      }
      break;
    case KEY_CHAR_STORE:
      if(menu->numitems>=22) {
	menu->selection = 22;
	if (menu->type != MENUTYPE_FKEYS)  return MENU_RETURN_SELECTION;
      }
      break;
    }
  }
  return MENU_RETURN_EXIT;
}

void reset_alpha(){
  SetSetupSetting( (unsigned int)0x14, 0);	
  //DisplayStatusArea();
}

#define CAT_CATEGORY_ALL 0
#define CAT_CATEGORY_ARIT 1
#define CAT_CATEGORY_REAL 2
#define CAT_CATEGORY_COMPLEXNUM 3
#define CAT_CATEGORY_PROBA 4
#define CAT_CATEGORY_MATRIX 5
#define CAT_CATEGORY_LOGO 6
#define CAT_CATEGORY_PLOT 7
#define CAT_CATEGORY_GRAPHIC 8
#define CAT_CATEGORY_LIST 9
#define CAT_CATEGORY_IO 10
#define CAT_CATEGORY_PROG 11
#define CAT_CATEGORY_N 11 // should be the max

void init_locale(){
  lang=0;
}

const catalogFunc completeCat[] = { // list of all functions (including some not in any category)
  // {"blue", "blue", "Display option", 0, 0, CAT_CATEGORY_GRAPHIC},
  // {"cyan", "cyan", "Display option", 0, 0, CAT_CATEGORY_GRAPHIC},
  // {"filled", "filled", "Display option", 0, 0, CAT_CATEGORY_GRAPHIC},
  // {"iquo(a,b)", 0, "Euclidean quotient of two integers.", "23,13", 0, CAT_CATEGORY_ARIT},
  // {"irem(a,b)", 0,"Euclidean remainder of two integers", "23,13", 0, CAT_CATEGORY_ARIT},
  // {"magenta", "magenta", "Display option", "#display=magenta", 0, CAT_CATEGORY_GRAPHIC},
  //{"green", "green", "Display option", "#display=green", 0, CAT_CATEGORY_GRAPHIC},
  //{"red", "red", "Display option", "#display=red", 0, CAT_CATEGORY_GRAPHIC},
  //{"yellow", "yellow", "Display option", "#display=yellow", 0, CAT_CATEGORY_GRAPHIC},
  //{"isdown()", "isdown()", "Indicates if the turtle's pen is down.", "isdown()", 0, CAT_CATEGORY_LOGO},
  {" loop for", "for ", "Defined loop.", "#\nfor ", 0, CAT_CATEGORY_PROG},
  {" loop in list", "for in", "Loop on all elements of a list.", "#\nfor in", 0, CAT_CATEGORY_PROG},
  {" loop while", "while ", "Undefined loop.", "#\nwhile ", 0, CAT_CATEGORY_PROG},
  {" test if", "if ", "Test", "#\nif ", 0, CAT_CATEGORY_PROG},
  {" test else", "else ", "Test false case", 0, 0, CAT_CATEGORY_PROG},
  {" function def", "f(x):=", "Definition of function.", "#\nf(x):=", 0, CAT_CATEGORY_PROG},
  {" range(a,b)", 0, "In range [a,b) (a included, b excluded)", "# in range(1,10)", 0, CAT_CATEGORY_PROG},
  {" return res", "return ", "Leaves current function and returns res.", 0, 0, CAT_CATEGORY_PROG},
  {" test if then", "if ", "Test", "#\nif", 0, CAT_CATEGORY_PROG},
  {" test else", "else ", "Test false case", "#else", 0, CAT_CATEGORY_PROG},
  {"!", "!", "Logical not (prefix) or factorial of n (suffix).", "#7!", "~!b", CAT_CATEGORY_PROG},
  {"#", "#", "Python comment, for Xcas comment type //. Shortcut ALPHA F2", 0, 0, CAT_CATEGORY_PROG},
  {"%", "%", "a % b means a modulo b", 0, 0, CAT_CATEGORY_ARIT | (CAT_CATEGORY_PROG << 8)},
  {"&", "&", "Logical and or +", "#1&2", 0, CAT_CATEGORY_PROG},
  {".append(x)", 0, "Adds an element at the end of a list","#l.append(x)", 0, CAT_CATEGORY_LIST},
  {".clear()", ".clear()", "Empty list l","#l.clear()", 0, CAT_CATEGORY_LIST},
  {".count(x)", 0, "Number of x in list l","#l.count(2)", 0, CAT_CATEGORY_LIST},
  {".imag", 0, "Imaginary part.", "1+i", 0, CAT_CATEGORY_COMPLEXNUM},
  {".index(x)", 0, "First occurence of x in list l","#l.index(2)", 0, CAT_CATEGORY_LIST},
  {".insert(i,x)", 0, "Insert x in list l at position i","#l.index(2,pi)", 0, CAT_CATEGORY_LIST},
  {".pop()", ".pop()", "Remove last element of list l","#l.pop()", 0, CAT_CATEGORY_LIST},
  {".real", 0, "Real part.", "1+i", 0, CAT_CATEGORY_COMPLEXNUM},
  {".remove(x)", 0, "Remove first occurence of x in list l","#l.remove(pi)", 0, CAT_CATEGORY_LIST},
  {".reverse()", ".reverse()", "List l in reverse order","#l.reverse()", 0, CAT_CATEGORY_LIST},
  {".sort()", ".sort()", "Sort list l","#l.sort()", 0, CAT_CATEGORY_LIST},
  {"//", "//", "a // b = euclidean quotient of a by b", "#25 // 7", 0, CAT_CATEGORY_ARIT | (CAT_CATEGORY_PROG << 8)},
  {"KEY_BACK", 0, "EXIT keycode", 0, 0, CAT_CATEGORY_IO},
  {"KEY_DOWN", 0, "Down cursor keycode", 0, 0, CAT_CATEGORY_IO},
  {"KEY_LEFT", 0, "Left cursor keycode", 0, 0, CAT_CATEGORY_IO},
  {"KEY_OK", 0, "EXE keycode", 0, 0, CAT_CATEGORY_IO},
  {"KEY_RIGHT", 0, "Right cursor keycode", 0, 0, CAT_CATEGORY_IO},
  {"KEY_UP", 0, "Up cursor keycode", 0, 0, CAT_CATEGORY_IO},
  {"a and b", " and ", "Logical and", 0, 0, CAT_CATEGORY_PROG},
  {"abs(x)", 0, "Absolute value or modulus of x", "-3", "1+2j", CAT_CATEGORY_COMPLEXNUM | (CAT_CATEGORY_REAL<<8)},
  {"acos(x)", 0, "Arccosinus of x (radian)", "0.5", 0, CAT_CATEGORY_COMPLEXNUM | (CAT_CATEGORY_REAL<<8)},
  {"add(A,B)", 0, "Addition of matrices encoded as lists of lists. Use a numpy array for + operator support", "[[1,2],[3,4]],[[5,6],[7,8]]", 0, CAT_CATEGORY_MATRIX},
  {"arange(begin,end,step)", 0, "Returns a numpy array from begin to end step step (generalization of range)", "1,5,.5", 0, CAT_CATEGORY_MATRIX},
  {"array(A)", 0, "Create a numpy array from a list of lists of same sizes. Numpy array support operator + - * notation", "[[1,2],[3,4]]", 0, CAT_CATEGORY_MATRIX},
  {"arrow(x,y,dx,dy)", 0, "Vector of origin point (x,y) and direction [dx,dy]", "0.1,0.2,0.3,0.5", 0, CAT_CATEGORY_PLOT},
  {"asc(string)", 0, "List of ASCII codes from a string", "\"Hello\"", 0, CAT_CATEGORY_ARIT},
  {"asin(x)", 0, "Arcsinus of x (radian)", "0.5", 0, CAT_CATEGORY_COMPLEXNUM | (CAT_CATEGORY_REAL<<8)},
  {"atan(x)", 0, "Arctangent of x (radian)", "0.5", 0, CAT_CATEGORY_COMPLEXNUM | (CAT_CATEGORY_REAL<<8)},
  {"atan2(x,y)", 0, "Argument of x+i*y", "1,2", 0, CAT_CATEGORY_COMPLEXNUM | (CAT_CATEGORY_REAL<<8)},
  {"axis(xmin,xmax,ymin,ymax)", 0, "In matplotl, defines current graphic windows x=xmin..xmax, y=ymin..ymax. Without argument, returns current window.", "-3,3,-2,2", "#axes()", CAT_CATEGORY_PLOT << 8},
  {"backward(n)", "backward(", "Turtle backward n step", "30", 0, CAT_CATEGORY_LOGO},
  {"bar(x,h,w)", 0, "Rectangle of basis Ox axis, centered at x height h and width w", "2.5,1,1.5", 0, CAT_CATEGORY_PLOT},
  {"black", "black", "Display option", "#display=black", 0, CAT_CATEGORY_GRAPHIC},
  {"boxplot(l)", 0, "Stat series boxplot diagram", "[[1,2,2,2,3,-1,5,2],[2,3,6,7,0,0,0]]", 0, CAT_CATEGORY_PLOT},
  {"char(liste)", 0, "String from ASCII codes list", "[97,98,99]", 0, CAT_CATEGORY_ARIT},
  {"choice(l)", 0, "Random element in a list", "[1.2,3,\"ab\"]", 0, CAT_CATEGORY_PROBA},
  {"circle(n)", 0, "Turtle draws a circle of radius n tangent to its position", "left(45)", 0, CAT_CATEGORY_LOGO},
  {"conj(", 0, "Complex conjugate of z is not defined in cmaths. Type F2 and copy the function of example 1", "#def conj(z): return z.real-z.imag*1j", "1+2j", CAT_CATEGORY_COMPLEXNUM},
  {"copysign(x,y)", 0, "Copy sign of y in x", "-5,pi", 0, CAT_CATEGORY_REAL},
  {"cos(x)", 0, "Cosine of x (radian)", "-3", "1+2j", CAT_CATEGORY_COMPLEXNUM | (CAT_CATEGORY_REAL<<8)},
  {"degrees(x)", 0, "Conversion radians => degrees", "pi", 0, CAT_CATEGORY_REAL},
  {"del x", 0, "Purge variable x. Shortcut SHIFT-FORMAT", 0, 0, CAT_CATEGORY_PROG },
  {"divmod(a,b)", 0, "Returns euclidean quotient and remainder of a by b", "25,7", 0, CAT_CATEGORY_ARIT},
  {"draw_arc(x1,y1,rx,ry,theta1,theta2)", 0, "Pixelated elliptical arc. theta1 and theta2 are optional, default value 0 and 2*pi", "10,10,60,80", "100,100,60,80,0,3.14", CAT_CATEGORY_GRAPHIC},
  {"draw_circle(x1,y1,r)", 0, "Pixelated circle.", "30,30,60", 0, CAT_CATEGORY_GRAPHIC},
  {"draw_filled_arc(x1,y1,rx,ry,theta1,theta2)", 0, "Pixelated filled elliptical arc. theta1 and theta2 are optional, default value 0 and 2*pi", "10,10,60,80", "100,100,60,80,0,3.14", CAT_CATEGORY_GRAPHIC},
  {"draw_filled_circle(x1,y1,r)", 0, "Pixelated filled circle.", "30,40,20", 0, CAT_CATEGORY_GRAPHIC},
  {"draw_filled_rectangle(x,y,w,h)", 0, "Pixelated filled rectangle.", "80,20,30,20", 0, CAT_CATEGORY_GRAPHIC},
  {"draw_line(x1,y1,x2,y2)", 0, "Pixelated segment.", "10,50,30,20", 0, CAT_CATEGORY_GRAPHIC},
  {"draw_pixel(x,y,color)", 0, "Draw colored pixel x,y. Run draw_pixel() for screen synchronization.", 0, 0, CAT_CATEGORY_GRAPHIC},
  {"draw_polygon([[x1,y1],...])", 0, "Pixelated polygon.", "[[100,50],[30,20],[60,70]]", 0, CAT_CATEGORY_GRAPHIC},
  {"draw_rectangle(x,y,w,h)", 0, "Pixelated rectangle.", "80,40,30,20", 0, CAT_CATEGORY_GRAPHIC},
  {"draw_string(x,y,s)", 0, "Display string s at x,y", "80,20,\"Hello\"", 0, CAT_CATEGORY_GRAPHIC},
  {"egv(A)", 0, "Returns eigenvectors of A", "[[1,2],[3,4]]", 0, CAT_CATEGORY_MATRIX},
  {"eig(A)", 0, "Returns P and D such that inv(P)*A*P=D", "[[1,2],[3,4]]", "#P,D=eig([[1,2],[3,4]])", CAT_CATEGORY_MATRIX},
  {"erf(x)", 0, "Error function at x", "2", 0, CAT_CATEGORY_REAL},
  {"erfc(x)", 0, "Complementary error function at x", "2", 0, CAT_CATEGORY_REAL},
  {"eval(f)", 0, "Eval a string", "\"1+2\"", 0, CAT_CATEGORY_PROG},
  {"exp(x)", 0, "Exponential of x", "3", "1+2j", CAT_CATEGORY_COMPLEXNUM | (CAT_CATEGORY_REAL<<8)},
  {"extend", 0, "Concatenation of 2 lists. ","#l1.extend(l2)", 0, CAT_CATEGORY_LIST},
  {"factorial(x)", 0, "Factorial of x", "12", 0, (CAT_CATEGORY_REAL<<8)},
  {"float(s)", 0, "Convert a string to a float", "\"123.4\"", 0, CAT_CATEGORY_PROG},
  {"floor(x)", 0, "Round to integer <=", "pi", 0, CAT_CATEGORY_REAL},
  {"fmod(a,b)", 0, "a mod b", "12.3,3.2", 0, CAT_CATEGORY_REAL},
  {"forward(n)", 0, "Turtle forward n pixels", "forward(20)", 0, CAT_CATEGORY_LOGO},
  {"frexp(x)", 0, "Mantissa and exponent of x", "pi", 0, CAT_CATEGORY_REAL},
  {"from arit import *", "from arit import *", "Arithmetic module", 0, 0, CAT_CATEGORY_ARIT},
  {"from cmath import *", "from cmath import *", "Complex number module ", 0, 0, CAT_CATEGORY_COMPLEXNUM},
  {"from ion import *", 0, "Import instructions monotonic, sleep and getkey", 0, 0, CAT_CATEGORY_IO},
  {"from linalg import *", "from linalg import *", "Import commands to handle matrices as list of lists", 0, 0, CAT_CATEGORY_MATRIX},
  {"from math import *", "from math import *", "Import math commands (trig, exp, log, etc.)", 0, 0, CAT_CATEGORY_REAL},
  {"from matplotl import *", "from math import *", "Import graphing commands. File matplotl.py must be available in storage.", 0, 0, CAT_CATEGORY_PLOT},
  {"from numpy import *", "from numpy import *", "Import commands to handle matrices (with + - * ...)", 0, 0, CAT_CATEGORY_MATRIX},
  {"from random import *", "from random import *", "Import commands related to random", 0, 0, CAT_CATEGORY_PROBA},
  {"from turtle import *", "from turtle import *", "Import logo turtle commands", 0, 0, CAT_CATEGORY_LOGO},
  {"gamma(x)", 0, "Gamma function at x", "2.5", 0, CAT_CATEGORY_REAL},
  {"getkey()", 0, "getkey() wait for a key and return keycode. getkey(-1) is identical but non blocking.", 0, 0, CAT_CATEGORY_IO},
  {"getrandbits(k)", 0, "Random integer on k bits", "6", 0, CAT_CATEGORY_PROBA},
  {"goto(x,y)", 0, "Turtle moves to x,y", "10,20", 0, CAT_CATEGORY_LOGO},
  {"heading()", "heading()", "Turtle heading", "heading()", 0, CAT_CATEGORY_LOGO},
  {"hex(x)", 0, "x written in base 16", "123", 0, CAT_CATEGORY_ARIT},
  {"hide_turtle()", 0, "Hide turtle (after drawing).", 0, 0, CAT_CATEGORY_LOGO},
  {"id(x)", 0, "Memory address of x", "1+2j", "#hex(id(1+2j))", CAT_CATEGORY_ARIT},
  {"iegcd(a,b)", 0, "Find integers u,v,d such that a*u+b*v=d=gcd(a,b)","23,13", 0, CAT_CATEGORY_ARIT},
  {"ifactor(n)", 0, "Integer factorization (not too large!). Shortcut n=>*", "1234", 0, CAT_CATEGORY_ARIT},
  {"import \"filename\"", "import ", "Read a file. See also write", 0, 0, CAT_CATEGORY_PROG},
  {"input()", "input()", "Read a string from keyboard", "\"Value?\"", 0, CAT_CATEGORY_PROG},
  {"int(s)", 0, "Convert a string to an integer", "\"123\"", 0, CAT_CATEGORY_PROG},
  {"inv(A)", 0, "Inverse of matrix A", "[[1,2],[3,4]]", 0, CAT_CATEGORY_MATRIX},
  {"isfinite(x)", 0, "Tests if x is finite", "pi", 0, CAT_CATEGORY_REAL},
  {"isinf(x)", 0, "Tests if x is infinite", "pi", 0, CAT_CATEGORY_REAL},
  {"isnan(x)", 0, "Tests if x is NaN (not a number)", "pi", 0, CAT_CATEGORY_REAL},
  {"isprime(n)", 0, "Returns 1 if n is prime, 0 otherwise.", "11", "10", CAT_CATEGORY_ARIT},
  {"ldexp(m,e)", 0, "Inverse of frexp: m*2^e", "123,4", 0, CAT_CATEGORY_REAL},
  {"left(n)", 0, "Turtle turns n degrees, default n=90", "left(45)", 0, CAT_CATEGORY_LOGO},
  {"len(l)", "len(", "Length of list l.","[1,2,3]", 0, CAT_CATEGORY_LIST},
  {"lgamma(x)", 0, "Logarithm of the gamma function of x", "100", 0, CAT_CATEGORY_REAL},
  {"linspace(start,end,n)", 0, "Returns a numpy array of n reals between start and end with step (end-start)/(n-1), generalizes the range command", "1,5,5", 0, CAT_CATEGORY_MATRIX},
  {"list(obj)", 0, "Converts obj to a list","range(1,3)", 0, CAT_CATEGORY_LIST},
  {"log(x)", 0, "Natural logarithm of x (keyboard ln key)", "3", "1+2j", CAT_CATEGORY_COMPLEXNUM | (CAT_CATEGORY_REAL<<8)},
  {"log10(x)", 0, "Logarithm of x base 10 (keyboard log key)", "3", "1+2j", CAT_CATEGORY_COMPLEXNUM | (CAT_CATEGORY_REAL<<8)},
  {"map(f,l)", 0, "Applies f to elements of list l.","f,[1,2,3]", 0, CAT_CATEGORY_LIST},
  {"modf(x)", 0, "Fractional and integer part of x", "pi", 0, CAT_CATEGORY_REAL},
  {"monotonic()", 0, "Returns the integer value of the calculator's real-time clock", 0, 0, CAT_CATEGORY_IO},
  {"mul(A,B)", 0, "Multiplication of matrices represented by lists of lists. Use a numpy array to use * operator", "[[1,2],[3,4]],[[5,6],[7,8]]", 0, CAT_CATEGORY_MATRIX},
  {"not(x)", 0, "Logical not.", 0, 0, CAT_CATEGORY_PROG},
  {"o or p", " or ", "Logical or", 0, 0, CAT_CATEGORY_PROG},
  {"pencolor()", 0, "Turtle pen color", "#red pen", 0, CAT_CATEGORY_LOGO},
  {"pendown()", "pendown()", "Turtle moves while drawing.", 0, 0, CAT_CATEGORY_LOGO},
  {"pensize(n)", 0, "Turtle pen thickness.", "2", 0, CAT_CATEGORY_LOGO},
  {"penup()", "penup()", "Turtle moves without drawing", 0, 0, CAT_CATEGORY_LOGO},
  {"phase(z)", 0, "Argument of complex z.", "1+i", 0, CAT_CATEGORY_COMPLEXNUM},
  {"plot(xlist,ylist)", 0, "Polygonal line connecting points defined by x-list and y-list", "[1,2,3],[4,0,-1]", 0,CAT_CATEGORY_PLOT },
  {"position()", "position()", "Turtle position", "position()", 0, CAT_CATEGORY_LOGO},
  {"powmod(a,n,p)", 0, "Returns a^n mod p if a is an integer or the list of a^n mod p if a is a list of integers","123,456,789", "[12,34],456,789", CAT_CATEGORY_ARIT},
  {"print(expr)", 0, "Print to console", 0, 0, CAT_CATEGORY_PROG},
  {"radians(x)", 0, "Conversion degrees to radians", "180", 0, CAT_CATEGORY_REAL},
  {"randint(a,b)", 0, "Random integer between a and b included", "5,20", 0,CAT_CATEGORY_PROBA},
  {"random()", 0, "Random real between 0 and 1", 0, 0, CAT_CATEGORY_PROBA},
  {"randrange(a,b)", 0, "Random integer between a included and b excluded", "5,20", 0,CAT_CATEGORY_PROBA},
  {"range(a,b)", "in range(", "In range [a,b[ (a included, b excluded)", "# in range(1,10)", 0, CAT_CATEGORY_LIST | (CAT_CATEGORY_PROG<<8)},
  {"reset()", 0, "Reset turtle", 0, 0, CAT_CATEGORY_LOGO},
  {"reshape(A,r,c)", 0, "Reshapes a matrix into r rows and c columns", "[[1,2],[3,4]],3,3", 0, CAT_CATEGORY_MATRIX},
  {"reversed(l)", 0, "Reverse order","[3,2,0,5]", 0, CAT_CATEGORY_LIST},
  {"rgb(r,g,b)", 0, "Color defined by red, green, blue levels between 0 and 255", "255,0,255", 0, CAT_CATEGORY_GRAPHIC},
  {"right(n)", 0, "Turtle turns n degrees, default n=90", "right(45)", 0, CAT_CATEGORY_LOGO},
  {"round(x,n)", 0, "Round x to n digits", "pi,3", 0, CAT_CATEGORY_REAL},
  {"rref(A)", 0, "Reduced Row Echelon Form of matrix A", "[[1,2,3],[3,4,5]]", 0, CAT_CATEGORY_MATRIX},
  {"scatter(xlist,ylist)", 0, "Scatter plot defined by x-list and y-list", "[1,2,3],[4,0,-1]", 0, CAT_CATEGORY_PLOT },
  {"seed(u0)", 0, "Initialize the pseudo-random generator with u0", "6", 0, CAT_CATEGORY_PROBA},
  {"show()", 0, "Displays matplotl graph.", 0, 0, CAT_CATEGORY_PLOT},
  {"show_turtle()", 0, "Shows turtle after drawing.", 0, 0, CAT_CATEGORY_LOGO},
  {"sign(x)", 0, "Returns -1 if x is negative, 0 if x is zero and 1 if x is positive.", 0, 0, CAT_CATEGORY_REAL},
  {"sin(x)", 0, "Sine of x (radian)", "-3", "1+2j", CAT_CATEGORY_COMPLEXNUM | (CAT_CATEGORY_REAL<<8)},
  {"sleep(ms)", 0, "Wait for ms milliseconds", 0, 0, CAT_CATEGORY_IO},
  {"solve(A,b)", 0, "Solve A*x=b for invertible matrix A and vector b", "[[1,2],[3,4]],[5,6]", 0, CAT_CATEGORY_MATRIX},
  {"sorted(l)", 0, "Sort list l.","[3/2,2,1,1/2,3,2,3/2]", 0, CAT_CATEGORY_LIST},
  {"sqrt(x)", 0, "Square root of x", "3", "1+2j", CAT_CATEGORY_COMPLEXNUM | (CAT_CATEGORY_REAL<<8)},
  {"sub(A,B)", 0, "Subtraction of matrices represented by lists of lists. Use a numpy array to use - operator", "[[1,2],[3,4]],[[5,6],[7,8]]", 0, CAT_CATEGORY_MATRIX},
  {"sum(l)", 0, "Sum of elements of list l.","[3,2,0,5]", 0, CAT_CATEGORY_LIST},
  {"tan(x)", 0, "Tangent of x (radian)", "-3", "1+2j", CAT_CATEGORY_COMPLEXNUM | (CAT_CATEGORY_REAL<<8)},
  {"text(x,y,s)", 0, "Text s positioned at coordinates (x,y)", "0.1,0.0,\"legend\"", 0, CAT_CATEGORY_PLOT},
  {"trace(A)", 0, "Trace of matrix A.", "[[1,2],[3,4]]", 0, CAT_CATEGORY_MATRIX},
  {"trn(A)", 0, "Transpose-conjugate of matrix A.", "[[1,2],[3,4]]", 0, CAT_CATEGORY_MATRIX },
  {"trunc(x)", 0, "Integer truncation of x", "pi", 0, CAT_CATEGORY_REAL},
  {"uniform(a,b)", 0, "Random real between a and b", "2,4", 0, CAT_CATEGORY_PROBA},
  {"zip(l1,l2)", 0, "Returns a sequence of tuples from l1 and l2 (zipper effect applied to 2 lists)","[1,2],[3,4]", "#list(zip([1,2],[3,4]))", CAT_CATEGORY_LIST},
  {"|", "|", "Logical or", "#1|2", 0, CAT_CATEGORY_PROG},
  {"~", "~", "Complement", "#~7", 0, CAT_CATEGORY_PROG},
};
const char aide_khicas_string[]="MicroPython help";
const char shortcuts_string[]="Clock setup: type shift-SETUP\n\nKeyboard shortcuts (shell & editor)\nF1-F3: see legends\nF4: catalog\nF5: alpha low lock or low/upper switch\nF6: file menu, cfg\nshift-F7 to shift-F12: fast menus\nshift-FRAC: help/completion\nshift-PRGM: chars for programing\nS<>D: turtle\n\nOPTN: options\nshift-QUIT: turtle\nshift-Lst: lists\nshift-Mtr: matrices\nVARS: list of variables\n\nScript editor\nFRAC: indent\nshift-CLIP: mark selection begin then move cursor to end selection then press DEL to erase or shift-CLIP to copy without erasing. shift-PASTE paste.\nF6-6 search only: enter a word then EXE, EXIT. Type EXE for next occurence, AC to cancel.\nF6-6 replace: enter then EXE new word then EXE. Type EXE or EXIT to replace or skip w/o replace to next occurence, AC to cancel\nshift-Ans: test syntax\n\nGraph shortcuts:\n+ - zoom\n(-): zoomout in y\n*: autoscale\n/: orthonormalize\nOPTN: axes on/off";
const char apropos_string[]="MicroPython, (c) Damien George et al,\nUI, arit, linalg, turtle modules (c) 2022 B. Parisse et al. www-fourier.univ-grenoble-alpes.fr/~parisse.\nLicense GPL version 2.\nUI adapted from Eigenmath for Casio, G. Maia (http://gbl08ma.com), Mike Smith, Nemhardy, LePhenixNoir, ...";

int CAT_COMPLETE_COUNT=sizeof(completeCat)/sizeof(catalogFunc);

ustl::string insert_string(int index){
  ustl::string s;
  if (completeCat[index].insert)
    s=completeCat[index].insert;
  else {
    s=completeCat[index].name;
    int pos=s.find('(');
    if (pos>=0 && pos<s.size())
      s=s.substr(0,pos+1);
  }
  return s;//s+' ';
}

int showCatalog(char* insertText,int preselect,int menupos) {
  // returns 0 on failure (user exit) and 1 on success (user chose a option)
  MenuItem menuitems[CAT_CATEGORY_N+1];
  menuitems[CAT_CATEGORY_ALL].text = (char*)"All";
  menuitems[CAT_CATEGORY_ARIT].text = (char*)"arit: arithmetic";
  menuitems[CAT_CATEGORY_REAL].text = (char*)"math: Reals";
  menuitems[CAT_CATEGORY_COMPLEXNUM].text = (char*)"cmath: complexes";
  menuitems[CAT_CATEGORY_PROBA].text = (char*)"random";
  menuitems[CAT_CATEGORY_MATRIX].text = (char*)"Matrices";
  menuitems[CAT_CATEGORY_LOGO].text = (char*)"turtle (S<>D)";
  menuitems[CAT_CATEGORY_PLOT].text = (char*)"matplotl: graphs";
  menuitems[CAT_CATEGORY_GRAPHIC].text = (char*)"graphic: pixels";
  menuitems[CAT_CATEGORY_LIST].text = (char*)"Lists";
  menuitems[CAT_CATEGORY_IO].text = (char*)"time, getkey";
  menuitems[CAT_CATEGORY_PROG].text = (char*)"Prog (PRGM)";
  
  Menu menu;
  menu.items=menuitems;
  menu.numitems=sizeof(menuitems)/sizeof(MenuItem);
  menu.scrollout=1;
  menu.title = (char*)"Liste de commandes";
  //puts("catalog 1");
  while(1) {
    if (preselect)
      menu.selection=preselect;
    else {
      if (menupos>0)
	menu.selection=menupos;
      int sres = doMenu(&menu);
      if (sres != MENU_RETURN_SELECTION)
	return 0;
    }
    // puts("catalog 3");
    if(doCatalogMenu(insertText, menuitems[menu.selection-1].text, menu.selection-1)) {
      const char * ptr=0;
      if (strcmp("matrix ",insertText)==0 && (ptr=input_matrix(false)) )
	return 0;
      if (strcmp("list ",insertText)==0 && (ptr=input_matrix(true)) )
	return 0;
      return 1;
    }
    if (preselect)
      return 0;
  }
  return 0;
}


// 0 on exit, 1 on success
int doCatalogMenu(char* insertText, const char* title, int category,const char * cmdname) {
  for (;;){
    int allcmds=CAT_COMPLETE_COUNT;//builtin_lexer_functions_end()-builtin_lexer_functions_begin();
    bool isall=category==CAT_CATEGORY_ALL; 
    bool isopt=false;//category==CAT_CATEGORY_OPTIONS;
    int nitems = CAT_COMPLETE_COUNT;
    MenuItem menuitems[nitems];
    int cur = 0,curmi = 0,i=0,menusel=-1,cmdl=cmdname?strlen(cmdname):0;
    while(cur<nitems) {
      if (menusel<0 && cmdname && !strncmp(cmdname,completeCat[cur].name,cmdl))
	menusel=curmi;
      menuitems[curmi].type = MENUITEM_NORMAL;
      menuitems[curmi].color = _BLACK;    
      int cat=completeCat[cur].category;
      if ( isall ||
	   (cat & 0xff) == category ||
	   (cat & 0xff00) == (category<<8) ||
	   (cat & 0xff0000) == (category <<16)
	   ){
	menuitems[curmi].isfolder = cur; // little hack: store index of the command in the full list in the isfolder property (unused by the menu system in this case)
	menuitems[curmi].text = (char *) completeCat[cur].name;
	curmi++;
      }
      cur++;
    }
  
    Menu menu;
    if (menusel>=0)
      menu.selection=menusel+1;
    menu.items=menuitems;
    menu.numitems=curmi;
    if (isopt){ menu.selection=5; menu.scroll=4; }
    if (curmi>=100)
      SetSetupSetting( (unsigned int)0x14, 0x88);	
    // DisplayStatusArea();
    menu.scrollout=1;
    menu.title = (char *) title;
    menu.type = MENUTYPE_FKEYS;
    menu.height = 7;
    while(1) {
#ifdef FX
      drawRectangle(0,58,LCD_WIDTH_PX,C24,_BLACK);
      Printmini(0,58,(category==CAT_CATEGORY_ALL?"input| ex1 | ex2 |     |help |     ":"input| ex1 | ex2 |cmds |help |    "),MINI_REV);
#else
      drawRectangle(0,58*3,LCD_WIDTH_PX,C24,_BLACK);
      Printmini(0,58*3,(category==CAT_CATEGORY_ALL?"input |exmpl1|exmpl2 |       | help |          ":"input |exmpl1|exmpl2| cmds | help |         "),MINI_REV);
#endif
      int sres = doMenu(&menu);
      if (sres==KEY_CTRL_F4 && category!=CAT_CATEGORY_ALL){
	break;
      }
      if(sres == MENU_RETURN_EXIT){
	reset_alpha();
	return sres;
      }
      int index=menuitems[menu.selection-1].isfolder;
      if(sres == KEY_CTRL_F5) {
	const char * example=index<allcmds?completeCat[index].example:0;
	const char * example2=index<allcmds?completeCat[index].example2:0;
	textArea text;
	text.editable=false;
	text.clipline=-1;
	text.title = (char*)"Help on command";
	text.allowF1=true;
	text.python=true;
	ustl::vector<textElement> & elem=text.elements;
	elem = ustl::vector<textElement> (example2?4:3);
	elem[0].s = index<allcmds?completeCat[index].name:menuitems[menu.selection-1].text;
	elem[0].newLine = 0;
	//elem[0].color = COLOR_BLUE;
	elem[1].newLine = 1;
	elem[1].lineSpacing = 1;
	elem[1].minimini=1;
	ustl::string autoexample;
	if (index<allcmds)
	  elem[1].s = completeCat[index].desc;
	else {
	  int token=menuitems[menu.selection-1].token;
	  elem[1].s="Sorry, no help available...";
	  // *logptr(contextptr) << token << endl;
	  if (isopt){
	  }
	  if (isall){
	  }
	}
	ustl::string ex("F2: ");
	elem[2].newLine = 1;
	elem[2].lineSpacing = 0;
	//elem[2].minimini=1;
	if (example){
	  if (example[0]=='#')
	    ex += example+1;
	  else {
	    ex += insert_string(index);
	    ex += example;
	    ex += ")";
	  }
	  elem[2].s = ex;
	  if (example2){
	    string ex2="F3: ";
	    if (example2[0]=='#')
	      ex2 += example2+1;
	    else {
	      ex2 += insert_string(index);
	      ex2 += example2;
	      ex2 += ")";
	    }
	    elem[3].newLine = 1;
	    // elem[3].lineSpacing = 0;
	    //elem[3].minimini=1;
	    elem[3].s=ex2;
	  }
	}
	else {
	  if (autoexample.size())
	    elem[2].s=ex+autoexample;
	  else
	    elem.pop_back();
	}
	sres=doTextArea(&text);
      }
      if (sres == KEY_CTRL_F2 || sres==KEY_CTRL_F3 ||
	  sres == KEY_CTRL_F8 || sres==KEY_CTRL_F9 ||
	  sres == KEY_CTRL_F14 || sres==KEY_CTRL_F15
	  ) {
	reset_alpha();
	if (index<allcmds && completeCat[index].example){
	  ustl::string s(insert_string(index));
	  const char * example=0;
	  if (sres==KEY_CTRL_F2 || sres == KEY_CTRL_F8 || sres == KEY_CTRL_F14)
	    example=completeCat[index].example;
	  else
	    example=completeCat[index].example2;
	  if (example){
	    if (example[0]=='#')
	      s=example+1;
	    else {
	      s += example;
	      s += ")";
	    }
	  }
	  strcpy(insertText, s.c_str());
	  return 1;
	}
	if (isopt){
	  int token=menuitems[menu.selection-1].token;
	  *insertText=0;
	  strcat(insertText,menuitems[menu.selection-1].text);
	  return 1;
	}
	sres=KEY_CTRL_F1;
      }
      if(sres == MENU_RETURN_SELECTION || sres == KEY_CTRL_F1 || sres == KEY_CTRL_F7 || sres == KEY_CTRL_F13) {
	reset_alpha();
	strcpy(insertText,index<allcmds?insert_string(index).c_str():menuitems[menu.selection-1].text);
	return 1;
      }
    }
    title="CATALOG";
    category=0;
  } // end endless for
}
