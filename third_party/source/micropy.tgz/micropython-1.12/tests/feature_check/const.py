x = const(1)
