print('foo')
