print('y')
