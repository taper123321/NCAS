################ Build options #######################################

NAME		:= ustl
MAJOR		:= 1
MINOR		:= 6

#DEBUG		:= 1
#BUILD_SHARED	:= 1
BUILD_STATIC	:= 1
NOLIBSTDCPP	:= 1

################ Programs ############################################

CXX		:= sh3eb-elf-g++
LD		:= sh3eb-elf-ld
AR		:= sh3eb-elf-ar
RANLIB		:= sh3eb-elf-ranlib
DOXYGEN		:= doxygen
INSTALL		:= install

INSTALLDATA	:= ${INSTALL} -D -p -m 644
INSTALLLIB	:= ${INSTALLDATA}

################ Destination #########################################

prefix		:= /home/parisse/opt/local
exec_prefix	:= /home/parisse/opt/local
BINDIR		:= /home/parisse/opt/local/bin
INCDIR		:= /home/parisse/opt/local/include
LIBDIR		:= /home/parisse/opt/local/lib

################ Compiler options ####################################

WARNOPTS	:= -Wall -Wextra -Woverloaded-virtual -Wpointer-arith\
		-Wshadow -Wredundant-decls -Wcast-qual
TGTOPTS		:= -Os -mb -m4a-nofpu -mhitachi -nostdlib  -ffreestanding -fno-strict-aliasing  -std=c++98 -fno-exceptions -fno-rtti
INLINEOPTS	:= -fvisibility-inlines-hidden -fno-threadsafe-statics -fno-enforce-eh-specs

CXXFLAGS	:= ${WARNOPTS} ${TGTOPTS} -ffunction-sections -fdata-sections
LDFLAGS		:=
LIBS		:=
ifdef DEBUG
    CXXFLAGS	+= -O0 -g
else
    CXXFLAGS	+= -Os -g0 -DNDEBUG=1 -fomit-frame-pointer ${INLINEOPTS}
    LDFLAGS	+= -s -Wl,-gc-sections -lgcc
endif
ifdef NOLIBSTDCPP
    LD		:= /usr/bin/gcc
    STAL_LIBS	:= -lsupc++
    LIBS	:= ${STAL_LIBS}
endif
O		:= .o/

slib_lnk	= lib$1.so
slib_son	= lib$1.so.${MAJOR}
slib_tgt	= lib$1.so.${MAJOR}.${MINOR}
slib_flags	= -shared -Wl,-soname=$1
