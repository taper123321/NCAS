#include "iostream"
stdostream cout;
